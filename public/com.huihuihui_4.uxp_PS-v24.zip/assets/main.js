//* HTMLMediaElement blank polyfill for UXP
try{window.HTMLMediaElement = function() {};}catch(e){}
//* Microtask polyfill for UXP
if (typeof queueMicrotask !== "function") { window.queueMicrotask = function (fn) { Promise.resolve().then(fn).catch((err) => setTimeout(() => { throw err; }));  }; }
//* Template polyfill for UXP
(function () {
  if ("content" in document.createElement("template")) return;
  const origCreateElement = document.createElement;
  document.createElement = function (tagName, ...args) {
    const lowerTag = tagName.toLowerCase();
    if (lowerTag === "template") {
      const fakeTemplate = origCreateElement.call(document, "div");
      const content = document.createDocumentFragment();
      Object.defineProperty(fakeTemplate, "content", {
        get() { return content; },
      });
      Object.defineProperty(fakeTemplate, "innerHTML", {
        set(html) {
          const tempDiv = origCreateElement.call(document, "div");
          tempDiv.innerHTML = html;
          // Clear previous content
          while (content.firstChild) content.removeChild(content.firstChild);
          // Move parsed nodes into the content fragment
          while (tempDiv.firstChild) {
            content.appendChild(tempDiv.firstChild);
          }
        },
        get() { return ""; },
      });
      return fakeTemplate;
    }
    return origCreateElement.call(document, tagName, ...args);
  };
})();

//* MutationObserver for Vite to work correctly in UXP
(function(){var t;null==window.MutationObserver&&(t=function(){function t(t){this.callBack=t}return t.prototype.observe=function(t,n){var e;return this.element=t,this.interval=setInterval((e=this,function(){var t;if((t=e.element.innerHTML)!==e.oldHtml)return e.oldHtml=t,e.callBack.apply(null)}),200)},t.prototype.disconnect=function(){return window.clearInterval(this.interval)},t}(),window.MutationObserver=t)}).call(this);

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(function() {
  "use strict";
  var _a, _b, _c, _d;
  var __vite_style__ = document.createElement("style");
  __vite_style__.textContent = '@charset "UTF-8";#app {\r\n  font-family: Inter, system-ui, Avenir, Helvetica, Arial, sans-serif;\r\n  line-height: 1.5;\r\n  font-weight: 400;\r\n  color-scheme: light dark;\r\n  color: rgba(255, 255, 255, 0.87);\r\n  font-synthesis: none;\r\n  text-rendering: optimizeLegibility;\r\n  -webkit-font-smoothing: antialiased;\r\n  -moz-osx-font-smoothing: grayscale;\r\n  -webkit-text-size-adjust: 100%;\r\n}\r\n@media (prefers-color-scheme: dark) {\n  :root {\n    --uxp-host-background-color: #535353;\n    --uxp-host-text-color: #ffffff;\n    --uxp-host-border-color: #454545;\n    --uxp-host-link-text-color: #4b9cf5;\n    --uxp-host-widget-hover-background-color: #5b5b5b;\n    --uxp-host-widget-hover-text-color: #ffffff;\n    --uxp-host-widget-hover-border-color: #5b5b5b;\n    --uxp-host-text-color-secondary: #e5e5e5;\n    --uxp-host-link-hover-text-color: #ffffff;\n    --uxp-host-label-text-color: #ffffff;\n  }\n}\n@media (prefers-color-scheme: darkest) {\n  :root {\n    --uxp-host-background-color: #323232;\n    --uxp-host-text-color: #ffffff;\n    --uxp-host-border-color: #292929;\n    --uxp-host-link-text-color: #4b9cf5;\n    --uxp-host-widget-hover-background-color: #3d3d3d;\n    --uxp-host-widget-hover-text-color: #ffffff;\n    --uxp-host-widget-hover-border-color: #3d3d3d;\n    --uxp-host-text-color-secondary: #9b9b9b;\n    --uxp-host-link-hover-text-color: #ffffff;\n    --uxp-host-label-text-color: #ffffff;\n  }\n}\n@media (prefers-color-scheme: light) {\n  :root {\n    --uxp-host-background-color: #b8b8b8;\n    --uxp-host-text-color: #424242;\n    --uxp-host-border-color: #9c9c9c;\n    --uxp-host-link-text-color: #4b9cf5;\n    --uxp-host-widget-hover-background-color: #9d9d9d;\n    --uxp-host-widget-hover-text-color: #424242;\n    --uxp-host-widget-hover-border-color: #9d9d9d;\n    --uxp-host-text-color-secondary: #424242;\n    --uxp-host-link-hover-text-color: #424242;\n    --uxp-host-label-text-color: #424242;\n  }\n}\n@media (prefers-color-scheme: lightest) {\n  :root {\n    --uxp-host-background-color: #f0f0f0;\n    --uxp-host-text-color: #4b4b4b;\n    --uxp-host-border-color: #d1d1d1;\n    --uxp-host-link-text-color: #4b9cf5;\n    --uxp-host-widget-hover-background-color: #cecece;\n    --uxp-host-widget-hover-text-color: #4b4b4b;\n    --uxp-host-widget-hover-border-color: #cecece;\n    --uxp-host-text-color-secondary: #606060;\n    --uxp-host-link-hover-text-color: #4b4b4b;\n    --uxp-host-label-text-color: #4b4b4b;\n  }\n}\n\n#app {\n  width: 100%;\n  height: 100%;\n  background-color: transparent;\n  overflow: hidden;\n  font-size: 12px;\n}\n\n.error-boundary {\n  padding: 12px;\n  color: #fff;\n  background: #242424;\n  font-family: sans-serif;\n  font-size: 12px;\n}\n\n.error-boundary-title {\n  color: #ff4444;\n  font-weight: bold;\n  margin-bottom: 8px;\n}\n\n.error-boundary-message {\n  color: #aaa;\n  word-break: break-all;\n}\nhtml, body {\n  overflow: visible !important;\n}\n\n#gallery-root {\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  overflow: visible;\n  background-color: transparent;\n  font-size: 12px;\n  position: relative;\n  isolation: isolate;\n  --gallery-scale-default: 1.0;\n  --gallery-transition-duration: 0.6s;\n  --gallery-jelly-curve: ease;\n  --gallery-scale: var(--gallery-scale-default);\n  --gallery-min-width: 383px;\n  --gallery-min-height: 480px;\n  --gallery-padding: 10px;\n  --gallery-bg-primary: var(--uxp-host-background-color, #1a1a1a);\n  --gallery-bg-secondary: #2a2a2a;\n  --gallery-bg-hover: #3a3a3a;\n  --gallery-bg-active: #404040;\n  --gallery-border-color: rgba(255, 255, 255, 0.1);\n  --gallery-border-hover: rgba(255, 255, 255, 0.2);\n  --gallery-shadow-lg: 0 8px 16px rgba(0, 0, 0, 0.5);\n  --gallery-text-primary: var(--uxp-host-text-color, rgba(255, 255, 255, 0.75));\n  --history-image-size: 80px;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  text-rendering: optimizeLegibility;\n}\n#gallery-root .gallery {\n  width: 100%;\n  height: 100%;\n  background-color: var(--gallery-bg-primary);\n  display: flex;\n  flex-direction: column;\n  overflow: visible;\n  border-radius: 0;\n  pointer-events: auto;\n  padding: 0 0 0 0;\n  box-sizing: border-box;\n  position: relative;\n  /* Unified Hover Trigger */\n}\n#gallery-root .gallery.canvas-hovered .lightning-toggle-button,\n#gallery-root .gallery.canvas-hovered .sentiment-slider-container {\n  opacity: 1;\n  visibility: visible;\n}\n#gallery-root .gallery.canvas-hovered .lightning-toggle-button {\n  transform: translateZ(0) scale(1);\n}\n#gallery-root .gallery.canvas-hovered .sentiment-slider-container {\n  transform: translateY(-50%) scale(1) translateX(0);\n}\n#gallery-root .gallery-nav {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 20px 8px;\n  position: relative;\n  z-index: 10;\n}\n#gallery-root .gallery-nav > * + * {\n  margin-left: 4px;\n}\n#gallery-root .nav-item {\n  padding: 8px 2px 6px;\n  cursor: pointer;\n  color: #888888;\n  font-size: 13px;\n  font-weight: 400;\n  position: relative;\n  transition: color 0.25s ease;\n  pointer-events: auto;\n  text-align: center;\n  flex: 1;\n  box-sizing: border-box;\n  -webkit-user-select: none;\n  user-select: none;\n}\n#gallery-root .nav-item:hover {\n  color: #aaaaaa;\n}\n#gallery-root .nav-item.active {\n  color: #ffffff;\n  font-weight: 600;\n}\n#gallery-root .nav-item.active::after {\n  content: "";\n  position: absolute;\n  bottom: 0;\n  left: 50%;\n  transform: translateX(-50%);\n  width: 20px;\n  height: 2px;\n  background: #ffffff;\n  border-radius: 1px;\n}\n#gallery-root .gallery-main-view {\n  flex: 1;\n  position: relative;\n  overflow: visible;\n}\n#gallery-root .view-live, #gallery-root .view-history, #gallery-root .view-presets, #gallery-root .view-generation {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  transition: opacity 0.3s ease;\n  display: flex;\n  flex-direction: column;\n  box-sizing: border-box;\n  overflow-y: auto;\n  overflow-x: hidden;\n}\n#gallery-root .view-live.active,\n#gallery-root .view-generation.active {\n  opacity: 1;\n  pointer-events: auto;\n}\n#gallery-root .view-live:not(.active),\n#gallery-root .view-history:not(.active),\n#gallery-root .view-presets:not(.active),\n#gallery-root .view-generation:not(.active) {\n  opacity: 0;\n  pointer-events: none;\n}\n#gallery-root .gallery-content {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  padding: 0;\n  box-sizing: border-box;\n  overflow-y: auto;\n  overflow-x: hidden;\n  width: 100%;\n  height: 100%;\n  border-radius: 8px;\n  background-color: var(--uxp-host-background-color, #252525);\n  pointer-events: auto;\n  position: relative;\n}\n#gallery-root .gc-preview-placeholder {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  color: #777;\n  border: 1px dashed rgba(255, 255, 255, 0.15);\n  border-radius: 6px;\n  box-sizing: border-box;\n}\n#gallery-root .gc-preview-wrapper {\n  position: relative;\n  width: 100%;\n  height: 100%;\n}\n#gallery-root .gc-preview-thumb {\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  margin: 0;\n  border: none;\n  background-size: contain;\n  background-position: center center;\n  background-repeat: no-repeat;\n  cursor: pointer;\n}\n#gallery-root .gc-preview-nav {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 6px 0;\n}\n#gallery-root .gc-preview-nav > * + * {\n  margin-left: 8px;\n}\n#gallery-root .gc-preview-icon {\n  width: 48px;\n  height: 40px;\n  border: 2px solid #777;\n  border-radius: 8px;\n  position: relative;\n  box-sizing: border-box;\n  margin-bottom: 12px;\n}\n#gallery-root .gc-preview-icon::before {\n  content: "";\n  position: absolute;\n  top: 6px;\n  left: 6px;\n  width: 6px;\n  height: 6px;\n  border-radius: 50%;\n  background: #777;\n}\n#gallery-root .gc-preview-icon::after {\n  content: "";\n  position: absolute;\n  bottom: 6px;\n  right: 6px;\n  width: 14px;\n  height: 14px;\n  border: 2px solid #777;\n  border-radius: 3px;\n  transform: rotate(45deg);\n  background: transparent;\n}\n#gallery-root .gc-preview-text {\n  font-size: 12px;\n  color: #555;\n}\n#gallery-root .lightning-toggle-button {\n  position: absolute;\n  top: 12px;\n  left: 12px;\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background-color: rgba(0, 0, 0, 0.4);\n  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.25), 0 2px 8px rgba(0, 0, 0, 0.3);\n  color: rgba(255, 255, 255, 0.75);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  z-index: 500;\n  backdrop-filter: blur(4px);\n  pointer-events: auto;\n  user-select: none;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n  margin: 0;\n  padding: 0;\n  box-sizing: border-box;\n  /* Hover Interaction Requirements - Jelly Animation */\n  opacity: 0;\n  visibility: hidden;\n  transform: translateZ(0) scale(0.6);\n  transform-origin: center center;\n  transition: opacity 0.5s ease-in-out, visibility 0.5s ease-in-out, transform var(--gallery-transition-duration) var(--gallery-jelly-curve), background-color 0.2s ease, box-shadow 0.2s ease, color 0.2s ease;\n  /* 扩大热区：32px + 9px*2 = 50px，确保完全对称且中心对齐 */\n}\n#gallery-root .lightning-toggle-button:hover {\n  background-color: rgba(255, 255, 255, 0.15);\n  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.5), 0 4px 12px rgba(0, 0, 0, 0.4);\n  color: #ffffff;\n  transform: scale(1.05) translateZ(0);\n}\n#gallery-root .lightning-toggle-button:active {\n  transform: scale(0.95) translateZ(0);\n  background-color: rgba(255, 255, 255, 0.1);\n}\n#gallery-root .lightning-toggle-button.active {\n  background-color: #378EF0;\n  box-shadow: 0 0 0 1px #378EF0, 0 0 12px rgba(55, 142, 240, 0.4);\n  color: #ffffff;\n}\n#gallery-root .lightning-toggle-button.active:hover {\n  background-color: #4a9eff;\n  box-shadow: 0 0 0 1px #4a9eff, 0 0 16px rgba(55, 142, 240, 0.6);\n}\n#gallery-root .lightning-toggle-button svg {\n  display: block;\n  transition: transform 0.3s ease;\n  pointer-events: none;\n  position: relative;\n  z-index: 1;\n}\n#gallery-root .lightning-toggle-button.active svg {\n  transform: scale(1.1);\n}\n#gallery-root .lightning-toggle-button::after {\n  content: "";\n  position: absolute;\n  top: -9px;\n  left: -9px;\n  right: -9px;\n  bottom: -9px;\n  border-radius: 50%;\n  pointer-events: auto;\n  z-index: 0;\n}\n#gallery-root .gallery-grid {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  padding: 0;\n  box-sizing: border-box;\n  overflow: auto;\n  overflow-x: hidden;\n  overflow-y: auto;\n  transform-origin: center center;\n  transform: scale(var(--gallery-scale, 1));\n  transition: transform var(--gallery-transition-duration) ease;\n  will-change: transform;\n  backface-visibility: hidden;\n  transform-style: flat;\n  min-width: var(--gallery-min-width);\n  min-height: var(--gallery-min-height);\n  pointer-events: auto;\n  -webkit-overflow-scrolling: touch;\n  scroll-behavior: smooth;\n}\n#gallery-root .gallery-grid::-webkit-scrollbar {\n  width: 8px;\n}\n#gallery-root .gallery-grid::-webkit-scrollbar-track {\n  background: transparent;\n}\n#gallery-root .gallery-grid::-webkit-scrollbar-thumb {\n  background: rgba(255, 255, 255, 0.2);\n  border-radius: 4px;\n}\n#gallery-root .gallery-grid::-webkit-scrollbar-thumb:hover {\n  background: rgba(255, 255, 255, 0.3);\n}\n#gallery-root .gallery-thumb {\n  border: 1px solid var(--gallery-border-color);\n  outline: none;\n  border-radius: 8px;\n  background: var(--gallery-bg-secondary);\n  padding: var(--gallery-padding);\n  margin: 0;\n  cursor: pointer;\n  overflow: hidden;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  height: 100%;\n  box-sizing: border-box;\n  will-change: background-image, background-size, transform;\n  transition: all 0.3s ease;\n  pointer-events: auto;\n  position: relative;\n  z-index: 10;\n  -webkit-border-radius: 8px;\n  transform: translateZ(0);\n}\n#gallery-root .gallery-thumb:hover {\n  background: var(--gallery-bg-hover);\n  border-color: var(--gallery-border-hover);\n  transform: translateZ(0) translateY(-2px);\n}\n#gallery-root .gallery-thumb:active {\n  background: var(--gallery-bg-active);\n  transform: translateZ(0) translateY(0) scale(0.98);\n}\n#gallery-root .gallery-thumb::before {\n  content: "";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: linear-gradient(135deg, rgba(255, 255, 255, 0.05) 0%, transparent 50%);\n  opacity: 0;\n  transition: opacity 0.3s ease;\n  pointer-events: none;\n  z-index: 1;\n}\n#gallery-root .gallery-thumb:hover::before {\n  opacity: 1;\n}\n#gallery-root .gallery-thumb::after {\n  content: "Click to add to canvas";\n  position: absolute;\n  bottom: 20px;\n  left: 50%;\n  transform: translateX(-50%) translateY(10px);\n  background: rgba(0, 0, 0, 0.8);\n  color: var(--gallery-text-primary);\n  padding: 8px 16px;\n  border-radius: 20px;\n  font-size: 12px;\n  font-weight: 500;\n  opacity: 0;\n  transition: all 0.3s ease;\n  pointer-events: none;\n  z-index: 2;\n  white-space: nowrap;\n  backdrop-filter: blur(8px);\n}\n#gallery-root .gallery-thumb:hover::after {\n  opacity: 1;\n  transform: translateX(-50%) translateY(0);\n}\n#gallery-root .gallery-nav-button {\n  position: absolute;\n  top: 50%;\n  transform: translateY(-50%);\n  width: 64px;\n  height: 64px;\n  border-radius: 50%;\n  background-color: rgba(0, 0, 0, 0.5);\n  border: 1px solid rgba(255, 255, 255, 0.25);\n  color: rgba(255, 255, 255, 0.85);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  z-index: 20;\n  pointer-events: auto;\n  backdrop-filter: blur(4px);\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.1);\n  transition: all 0.3s ease;\n  opacity: 0.7;\n  -webkit-backface-visibility: hidden;\n  backface-visibility: hidden;\n  box-sizing: border-box;\n}\n#gallery-root .gallery-nav-button:hover {\n  background-color: rgba(255, 255, 255, 0.15);\n  border-color: rgba(255, 255, 255, 0.5);\n  color: #ffffff;\n  opacity: 1;\n  transform: translateY(-50%) scale(1.08);\n  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.3);\n}\n#gallery-root .gallery-nav-button:active {\n  transform: translateY(-50%) scale(0.95);\n  background-color: rgba(255, 255, 255, 0.1);\n}\n#gallery-root .gallery-nav-prev {\n  left: 16px;\n}\n#gallery-root .gallery-nav-next {\n  right: 16px;\n}\n#gallery-root .gallery-nav-button svg {\n  display: block;\n  pointer-events: none;\n}\n@media (max-width: 500px) {\n  #gallery-root .gallery-nav-button {\n    width: 48px;\n    height: 48px;\n    opacity: 0.6;\n  }\n  #gallery-root .gallery-nav-prev {\n    left: 8px;\n  }\n  #gallery-root .gallery-nav-next {\n    right: 8px;\n  }\n  #gallery-root .gallery-nav-button svg {\n    width: 20px;\n    height: 20px;\n  }\n}\n@media (max-width: 350px) {\n  #gallery-root .gallery-nav-button {\n    width: 40px;\n    height: 40px;\n  }\n  #gallery-root .gallery-nav-button svg {\n    width: 18px;\n    height: 18px;\n  }\n}\n#gallery-root .gallery-upload-box {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  min-width: var(--gallery-min-width);\n  min-height: var(--gallery-min-height);\n  box-sizing: border-box;\n}\n#gallery-root .gallery-upload-container {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n@media (max-width: 400px) {\n  #gallery-root .gallery-thumb::after {\n    font-size: 11px;\n    padding: 6px 12px;\n    bottom: 15px;\n  }\n}\n@media (max-width: 300px) {\n  #gallery-root {\n    --gallery-scale: 0.5;\n  }\n}\n@media (min-width: 301px) and (max-width: 350px) {\n  #gallery-root {\n    --gallery-scale: 0.55;\n  }\n}\n@media (min-width: 351px) and (max-width: 383px) {\n  #gallery-root {\n    --gallery-scale: 0.65;\n  }\n}\n@media (min-width: 384px) and (max-width: 500px) {\n  #gallery-root {\n    --gallery-scale: 0.75;\n  }\n}\n@media (min-width: 501px) and (max-width: 600px) {\n  #gallery-root {\n    --gallery-scale: 0.85;\n  }\n}\n@media (min-width: 601px) and (max-width: 800px) {\n  #gallery-root {\n    --gallery-scale: 0.95;\n  }\n}\n@media (min-width: 801px) {\n  #gallery-root {\n    --gallery-scale: 1.0;\n  }\n}\n#gallery-root .isolation-test {\n  color: rgb(0, 128, 255);\n}\n#gallery-root .gallery-progress-bar-container {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  height: 2px;\n  background-color: transparent;\n  overflow: hidden;\n  z-index: 300;\n  pointer-events: none; /* 防止拦截顶部边缘的鼠标事件 */\n}\n#gallery-root .gallery-progress-bar {\n  width: 0%;\n  height: 100%;\n  background-color: #378EF0;\n  opacity: 0;\n  transition: width 0.3s ease, opacity 0.3s ease;\n}\n#gallery-root .gallery-progress-bar.active {\n  opacity: 1;\n}\n#gallery-root .sentiment-slider-container {\n  position: absolute;\n  right: 12px;\n  top: 38%;\n  width: 48px;\n  height: 184px;\n  background-color: #2B2B2B;\n  border-radius: 2px;\n  padding: 8px 6px;\n  z-index: 50;\n  pointer-events: auto;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  box-sizing: border-box;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);\n  /* Hover Interaction Requirements - Jelly Animation */\n  opacity: 0;\n  visibility: hidden;\n  transform: translateY(-50%) scale(0.9) translateX(15px);\n  transition: opacity 0.5s ease-in-out, visibility 0.5s ease-in-out, transform var(--gallery-transition-duration) var(--gallery-jelly-curve), box-shadow 0.2s ease;\n}\n#gallery-root .sentiment-slider-container:hover {\n  transform: translateY(-50%) scale(1.05) translateX(0);\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);\n}\n#gallery-root .sentiment-slider-track {\n  width: 39px;\n  height: 134px;\n  background-color: #7C7C7C;\n  border-radius: 2px;\n  position: relative;\n  overflow: hidden;\n  cursor: pointer;\n  transition: background-color 0.2s ease;\n}\n#gallery-root .sentiment-slider-track:hover {\n  background-color: #8C8C8C;\n}\n#gallery-root .sentiment-slider-track:active {\n  background-color: #6C6C6C;\n}\n#gallery-root .sentiment-slider-fill {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 39px;\n  background-color: #CACACA;\n  border-radius: 2px;\n  transition: height 0.1s ease, background-color 0.2s ease;\n}\n#gallery-root .sentiment-slider-track:hover .sentiment-slider-fill {\n  background-color: #dadada;\n}\n#gallery-root .sentiment-slider-track:active .sentiment-slider-fill {\n  background-color: #bababa;\n}\n#gallery-root .sentiment-value-display {\n  margin-top: 2px;\n  font-size: 12px;\n  color: rgba(255, 255, 255, 0.75);\n  font-weight: 500;\n  text-align: center;\n  line-height: 1;\n  min-height: 14px;\n}\n#gallery-root .sentiment-label {\n  margin-top: 2px;\n  font-size: 10px;\n  color: rgba(255, 255, 255, 0.5);\n  font-weight: 400;\n  text-align: center;\n  line-height: 1;\n  min-height: 12px;\n}\n#gallery-root .history-view {\n  width: 100%;\n  height: 100%;\n  overflow-y: auto;\n  overflow-x: hidden;\n  padding: 12px 0;\n  box-sizing: border-box;\n}\n#gallery-root .history-view::-webkit-scrollbar {\n  width: 8px;\n}\n#gallery-root .history-view::-webkit-scrollbar-track {\n  background: transparent;\n}\n#gallery-root .history-view::-webkit-scrollbar-thumb {\n  background: rgba(255, 255, 255, 0.2);\n  border-radius: 4px;\n}\n#gallery-root .history-view::-webkit-scrollbar-thumb:hover {\n  background: rgba(255, 255, 255, 0.3);\n}\n#gallery-root .history-toolbar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  min-height: 40px;\n  padding: 10px;\n  box-sizing: border-box;\n  position: relative;\n  flex-wrap: wrap;\n}\n#gallery-root .history-toolbar-left {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n#gallery-root .history-toolbar-right {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n#gallery-root .history-select-folder-btn {\n  font-size: 12px !important;\n  padding: 4px 10px !important;\n  height: 28px !important;\n  background: rgba(255, 255, 255, 0.12) !important;\n  border: 1px solid rgba(255, 255, 255, 0.25) !important;\n  border-radius: 4px !important;\n  color: rgba(255, 255, 255, 0.9) !important;\n}\n#gallery-root .history-select-folder-btn:hover {\n  background: rgba(255, 255, 255, 0.22) !important;\n  border-color: rgba(255, 255, 255, 0.45) !important;\n}\n#gallery-root .history-error {\n  padding: 8px 12px;\n  margin: 0 10px 10px;\n  background: rgba(244, 67, 54, 0.2);\n  border-radius: 4px;\n}\n#gallery-root .history-empty {\n  padding: 40px 20px;\n  text-align: center;\n  opacity: 0.5;\n}\n#gallery-root .history-group {\n  margin-bottom: 4px;\n}\n#gallery-root .history-group-header {\n  width: 100%;\n  justify-content: flex-start;\n  box-sizing: border-box;\n}\n#gallery-root .history-group-arrow {\n  display: inline-block;\n  font-size: 10px;\n  color: rgba(255, 255, 255, 0.6);\n}\n#gallery-root .history-group-count {\n  margin-left: auto;\n  color: rgba(255, 255, 255, 0.4);\n}\n#gallery-root .history-images-grid {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  padding: 0 10px 16px 10px;\n  justify-content: flex-start;\n  align-items: flex-start;\n}\n#gallery-root .history-image-item {\n  width: var(--image-size, 80px);\n  height: var(--image-size, 80px);\n  position: relative;\n  border-radius: 8px;\n  background-color: rgba(255, 255, 255, 0.05);\n  cursor: pointer;\n  border: 1px solid transparent;\n  flex-shrink: 0;\n  box-sizing: border-box;\n  overflow: hidden;\n  transition: border-color 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease;\n}\n#gallery-root .history-image-item img,\n#gallery-root .history-image-img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  object-position: center;\n  display: block;\n  border-radius: 8px;\n  transition: opacity 0.2s ease;\n}\n#gallery-root .history-image-item:hover {\n  border-color: rgba(255, 255, 255, 0.45);\n  background-color: rgba(255, 255, 255, 0.14);\n  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(255, 255, 255, 0.1);\n}\n#gallery-root .history-image-item:hover .history-image-img {\n  opacity: 0.9;\n}\n#gallery-root .history-image-item:active {\n  background-color: rgba(255, 255, 255, 0.08);\n  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.4);\n  border-color: rgba(255, 255, 255, 0.25);\n}\n#gallery-root .history-image-item.feedback-active {\n  border-color: #4CAF50;\n  box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.3);\n}\n#gallery-root .history-image-item.selection-mode {\n  cursor: pointer;\n}\n#gallery-root .history-image-item.selected {\n  border-color: #2196F3;\n  box-shadow: 0 0 0 2px rgba(33, 150, 243, 0.4);\n}\n#gallery-root .history-image-item.selection-mode:hover {\n  border-color: rgba(255, 255, 255, 0.45);\n  background-color: rgba(255, 255, 255, 0.14);\n  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(255, 255, 255, 0.1);\n}\n#gallery-root .history-image-item.loading {\n  background-color: rgba(255, 255, 255, 0.05);\n}\n#gallery-root .history-image-checkbox {\n  position: absolute;\n  top: 4px;\n  left: 4px;\n  width: 20px;\n  height: 20px;\n  border-radius: 50%;\n  border: 2px solid rgba(255, 255, 255, 0.5);\n  background: rgba(0, 0, 0, 0.3);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 2;\n  cursor: pointer;\n  box-sizing: border-box;\n  transition: border-color 0.2s ease, background-color 0.2s ease, box-shadow 0.2s ease;\n}\n#gallery-root .history-image-item:hover .history-image-checkbox {\n  border-color: rgba(255, 255, 255, 0.85);\n  box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.4);\n}\n#gallery-root .history-image-checkbox.checked {\n  border-color: #2196F3;\n  background: #2196F3;\n}\n#gallery-root .history-image-item:hover .history-image-checkbox.checked {\n  border-color: #42A5F5;\n  background: #42A5F5;\n  box-shadow: 0 0 0 2px rgba(33, 150, 243, 0.3);\n}\n#gallery-root .history-image-img.dimmed {\n  opacity: 0.6;\n}\n#gallery-root .history-image-placeholder {\n  width: 100%;\n  height: 100%;\n  background: rgba(255, 255, 255, 0.06);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n#gallery-root .history-image-spinner {\n  width: 20px;\n  height: 20px;\n  border-radius: 50%;\n  border: 2px solid rgba(255, 255, 255, 0.15);\n  border-top-color: rgba(255, 255, 255, 0.5);\n}\n#gallery-root .history-image-feedback {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background-color: rgba(0, 0, 0, 0.7);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n#gallery-root .history-image-feedback span {\n  color: #4CAF50;\n  font-size: 11px;\n  font-weight: 500;\n  text-align: center;\n  padding: 4px 8px;\n  background-color: rgba(255, 255, 255, 0.95);\n  border-radius: 4px;\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);\n}\n#gallery-root .history-images-grid:hover .history-image-item:not(:hover) {\n  opacity: 0.65;\n}\n#gallery-root .history-images-grid:hover .history-image-item:hover {\n  opacity: 1;\n}.error-notification-container {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: 10000;\n  padding: 8px;\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  pointer-events: none;\n}\n.error-notification-container.bottom {\n  top: auto;\n  bottom: 0;\n}\n\n.gallery .error-notification-container {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: 100;\n  pointer-events: none;\n  padding: 8px 12px;\n}\n\n.gallery .error-notification {\n  background: rgba(254, 226, 226, 0.95);\n  backdrop-filter: blur(8px);\n}\n\n.error-notification {\n  background: #fee2e2;\n  border: 1px solid #ef4444;\n  border-radius: 6px;\n  padding: 12px;\n  box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);\n  pointer-events: auto;\n}\n.error-notification-header {\n  display: flex;\n  align-items: flex-start;\n  gap: 12px;\n}\n.error-notification-icon {\n  color: #ef4444;\n  flex-shrink: 0;\n}\n.error-notification-content {\n  flex: 1;\n  min-width: 0;\n}\n.error-notification-title {\n  font-weight: 600;\n  color: #991b1b;\n  font-size: 14px;\n  margin-bottom: 4px;\n}\n.error-notification-suggestion {\n  color: #b91c1c;\n  font-size: 12px;\n  line-height: 1.4;\n}\n.error-notification-actions {\n  display: flex;\n  gap: 8px;\n  margin-top: 12px;\n  flex-wrap: wrap;\n}\n.error-notification-details {\n  margin-top: 12px;\n  padding-top: 12px;\n  border-top: 1px solid #fecaca;\n  font-size: 12px;\n}\n\n.error-detail-row {\n  display: flex;\n  gap: 8px;\n  margin-bottom: 6px;\n}\n\n.error-detail-stack {\n  margin-top: 8px;\n  padding: 8px;\n  background: #fef2f2;\n  border-radius: 4px;\n  overflow-x: auto;\n}\n.error-detail-stack pre {\n  margin: 0;\n  font-size: 11px;\n  color: #7f1d1d;\n  white-space: pre-wrap;\n  word-break: break-all;\n}\n\n.error-toast {\n  position: fixed;\n  bottom: 20px;\n  left: 50%;\n  transform: translateX(-50%);\n  background: #fee2e2;\n  border: 1px solid #ef4444;\n  border-radius: 6px;\n  padding: 12px 16px;\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);\n  z-index: 10001;\n}\n.error-toast span {\n  color: #991b1b;\n  font-size: 14px;\n}\n.error-toast-close {\n  flex-shrink: 0;\n}\n\n.error-panel {\n  background: white;\n  border-radius: 8px;\n  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);\n  overflow: hidden;\n}\n.error-panel-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 12px 16px;\n  background: #fee2e2;\n  border-bottom: 1px solid #fecaca;\n}\n.error-panel-header h3 {\n  margin: 0;\n  color: #991b1b;\n  font-size: 16px;\n}\n.error-panel-clear {\n  background: none;\n  border: 1px solid #ef4444;\n  color: #991b1b;\n  padding: 4px 8px;\n  border-radius: 4px;\n  font-size: 12px;\n  cursor: pointer;\n}\n.error-panel-clear:hover {\n  background: #fef2f2;\n}\n.error-panel-list {\n  max-height: 300px;\n  overflow-y: auto;\n}\n.error-panel-empty {\n  padding: 24px;\n  text-align: center;\n  color: #6b7280;\n}\n.error-panel-item {\n  padding: 12px 16px;\n  border-bottom: 1px solid #f3f4f6;\n  cursor: pointer;\n  transition: background 0.2s;\n}\n.error-panel-item:hover {\n  background: #fef2f2;\n}\n.error-panel-item:last-child {\n  border-bottom: none;\n}\n.error-panel-item-header {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 4px;\n}\n.error-panel-item-code {\n  font-weight: 600;\n  color: #991b1b;\n  font-size: 12px;\n}\n.error-panel-item-time {\n  color: #6b7280;\n  font-size: 11px;\n}\n.error-panel-item-message {\n  color: #7f1d1d;\n  font-size: 13px;\n}.generation-control {\n  display: flex;\n  flex-direction: column;\n  padding: 14px 14px;\n  box-sizing: border-box;\n}\n.generation-control > * + * {\n  margin-top: 14px;\n}\n\n.gc-section {\n  display: flex;\n  flex-direction: column;\n  flex-shrink: 0;\n}\n.gc-section > * + * {\n  margin-top: 10px;\n}\n\n.gc-row {\n  display: flex;\n  flex-shrink: 0;\n  align-items: stretch;\n}\n.gc-row > * + * {\n  margin-left: 16px;\n}\n\n.gc-col {\n  display: flex;\n  flex-direction: column;\n  flex: 1;\n  justify-content: flex-start;\n}\n.gc-col > * + * {\n  margin-top: 4px;\n}\n.gc-col > sp-label,\n.gc-col > sp-picker,\n.gc-col > .gc-seed-control {\n  flex-shrink: 0;\n}\n\n.gc-fullwidth {\n  width: 100%;\n}\n\n.gc-prompt-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.gc-prompt-title-wrap {\n  display: flex;\n  align-items: center;\n}\n.gc-prompt-title-wrap > * + * {\n  margin-left: 8px;\n}\n\n.gc-prompt-counter {\n  color: rgba(255, 255, 255, 0.5);\n}\n\n.gc-prompt-actions {\n  display: flex;\n  align-items: center;\n}\n.gc-prompt-actions > * + * {\n  margin-left: 6px;\n}\n\n.gc-history-group {\n  display: flex;\n  align-items: center;\n}\n.gc-history-group > * + * {\n  margin-left: 2px;\n}\n\n.gc-prompt-textarea {\n  display: block;\n  width: 100%;\n  height: 120px;\n}\n\n.gc-seed-control {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: rgba(255, 255, 255, 0.05);\n  border: 1px solid rgba(255, 255, 255, 0.1);\n  border-radius: 4px;\n  padding: 4px 8px;\n  box-sizing: border-box;\n  height: 32px;\n}\n.gc-seed-control > * + * {\n  margin-left: 6px;\n}\n\n.gc-seed-value {\n  font-size: 11px;\n  color: rgba(255, 255, 255, 0.8);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  flex: 1;\n  text-align: center;\n  display: block;\n}\n\n.gc-seed-random {\n  font-size: 12px !important;\n  padding: 0 4px !important;\n  min-width: 24px !important;\n  height: 24px !important;\n}\n\n.gc-stepper {\n  display: flex;\n  align-items: center;\n  justify-content: flex-start;\n}\n.gc-stepper > * + * {\n  margin-left: 4px;\n}\n\n.gc-stepper-btn {\n  font-size: 12px !important;\n  padding: 0 4px !important;\n  min-width: 24px !important;\n  height: 24px !important;\n}\n\n.gc-stepper-value {\n  min-width: 16px;\n  text-align: center;\n}\n\n.gc-translate-btn {\n  font-size: 10px !important;\n  padding: 0 6px !important;\n  min-width: auto !important;\n  height: 22px !important;\n  color: rgba(255, 255, 255, 0.9) !important;\n  background: rgba(255, 255, 255, 0.12) !important;\n  border: 1px solid rgba(255, 255, 255, 0.25) !important;\n  border-radius: 4px !important;\n}\n.gc-translate-btn:hover {\n  background: rgba(255, 255, 255, 0.22) !important;\n  border-color: rgba(255, 255, 255, 0.45) !important;\n}\n\n.gc-slider-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.gc-slider-labels {\n  display: flex;\n  justify-content: space-between;\n}\n\n.gc-slider {\n  width: 100%;\n}\n\n.gc-preview-container {\n  width: 100%;\n  height: 180px;\n  min-height: 180px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-sizing: border-box;\n}\n.gc-preview-container > * {\n  width: 100%;\n  height: 100%;\n}\n\nsp-label {\n  flex-wrap: nowrap;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\nsp-picker {\n  min-height: 32px;\n  flex-shrink: 0;\n}\n\n.gc-generate-btn {\n  width: 100%;\n  border-radius: 0;\n  min-height: 52px;\n}\n\n.gc-generating {\n  background-color: #f44336 !important;\n  border-color: #f44336 !important;\n}\n\n.gc-progress-wrap {\n  width: 100%;\n}\n\n.gc-progress {\n  width: 100%;\n}\n\n.gc-alert {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 8px 12px;\n  border-radius: 6px;\n  flex-shrink: 0;\n}\n.gc-alert > * + * {\n  margin-left: 8px;\n}\n.gc-alert.gc-alert-error {\n  background: rgba(244, 67, 54, 0.12);\n  border: 1px solid rgba(244, 67, 54, 0.5);\n}\n.gc-alert.gc-alert-success {\n  background: rgba(76, 175, 80, 0.12);\n}\n\n.gc-alert-close {\n  flex-shrink: 0;\n  font-size: 10px !important;\n  padding: 0 4px !important;\n  min-width: auto !important;\n  height: 20px !important;\n}\n.image-uploader {\n  display: flex;\n  flex-direction: column;\n  box-sizing: border-box;\n  flex-shrink: 0;\n}\n.image-uploader > * + * {\n  margin-top: 6px;\n}\n\n.iu-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  box-sizing: border-box;\n}\n\n.iu-counter {\n  font-size: 12px;\n  color: rgba(255, 255, 255, 0.5);\n}\n\n.iu-list {\n  display: flex;\n  align-items: center;\n  overflow-x: auto;\n  padding-bottom: 4px;\n  box-sizing: border-box;\n  min-height: 64px;\n  /* UXP 不支持 gap，用 margin 替代 */\n  /* 隐藏滚动条 */\n}\n.iu-list > * + * {\n  margin-left: 8px;\n}\n.iu-list::-webkit-scrollbar {\n  display: none;\n}\n\n.iu-thumb-wrapper {\n  position: relative;\n  flex-shrink: 0;\n  width: 64px;\n  height: 64px;\n  box-sizing: border-box;\n}\n\n.iu-thumb {\n  width: 100%;\n  height: 100%;\n  border-radius: 4px;\n  background-size: cover;\n  background-position: center;\n  background-repeat: no-repeat;\n  border: 1px solid rgba(255, 255, 255, 0.1);\n  box-sizing: border-box;\n}\n\n.iu-remove {\n  position: absolute;\n  top: -4px;\n  right: -4px;\n  width: 16px;\n  height: 16px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: rgba(0, 0, 0, 0.6);\n  border-radius: 50%;\n  color: #fff;\n  font-size: 10px;\n  cursor: pointer;\n  -webkit-user-select: none;\n  user-select: none;\n  z-index: 2;\n}\n.iu-remove:hover {\n  background: rgba(244, 67, 54, 0.9);\n}\n\n.iu-add-btn {\n  flex-shrink: 0;\n  width: 64px;\n  height: 64px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border: 1px dashed rgba(255, 255, 255, 0.15);\n  border-radius: 4px;\n  cursor: pointer;\n  color: rgba(255, 255, 255, 0.5);\n  font-size: 24px;\n  -webkit-user-select: none;\n  user-select: none;\n  box-sizing: border-box;\n}\n.iu-add-btn:hover {\n  border-color: rgba(255, 255, 255, 0.3);\n  color: rgba(255, 255, 255, 0.8);\n}\n\n.iu-add-btn-disabled {\n  opacity: 0.3;\n  cursor: not-allowed;\n}\n.iu-add-btn-disabled:hover {\n  border-color: rgba(255, 255, 255, 0.85);\n  color: rgba(255, 255, 255, 0.85);\n}\n.profile-center {\n  display: flex;\n  flex-direction: column;\n  padding: 20px 16px;\n  box-sizing: border-box;\n  height: 100%;\n  overflow-y: auto;\n}\n\n.profile-auth-panel,\n.profile-main-panel {\n  display: flex;\n  flex-direction: column;\n  gap: 14px;\n}\n\n/* ─── 未激活状态 ─── */\n.profile-header {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  margin-bottom: 4px;\n}\n\n.profile-icon {\n  font-size: 20px;\n  line-height: 1;\n}\n\n.profile-title {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 600;\n  color: #ffffff;\n}\n\n.profile-desc {\n  margin: 0;\n  font-size: 12px;\n  color: #888888;\n  line-height: 1.5;\n}\n\n.profile-input-wrap {\n  width: 100%;\n}\n\n.profile-password-row {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n\n.profile-input {\n  width: 100%;\n}\n.profile-input::part(input) {\n  font-family: monospace;\n  font-size: 13px;\n}\n\n.profile-eye-btn {\n  flex-shrink: 0;\n}\n\n/* ─── 已激活状态：4 个区块 ─── */\n.profile-main-panel {\n  display: flex;\n  flex-direction: column;\n  gap: 28px;\n}\n\n.profile-section {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  padding: 16px;\n  background-color: #2a2a2a;\n  border-radius: 8px;\n  border: 1px solid rgba(255, 255, 255, 0.08);\n}\n\n.profile-section-header {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 4px;\n}\n\n.profile-status-icon {\n  font-size: 16px;\n  line-height: 1;\n}\n\nsp-label {\n  font-size: 12px;\n  font-weight: 500;\n  color: #888888;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n\nsp-body {\n  font-size: 13px;\n  color: #cccccc;\n  word-break: break-all;\n}\n\n.profile-info-row {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n\n.profile-info-label {\n  font-size: 11px;\n  color: #888888;\n  text-transform: uppercase;\n  letter-spacing: 0.5px;\n}\n\n.profile-key {\n  font-family: monospace;\n  background-color: #1e1e1e;\n  padding: 8px 10px;\n  border-radius: 4px;\n  border: 1px solid #333333;\n}\n\n.profile-balance-row sp-body {\n  font-size: 20px;\n  font-weight: 700;\n  color: #3ecf8e;\n}\n\n.profile-actions-row {\n  display: flex;\n  gap: 10px;\n}\n\n.profile-btn-uxp {\n  width: 100%;\n  justify-content: center;\n}\n\n.profile-btn-uxp--primary {\n  --spectrum-actionbutton-background-color-default: #3ecf8e;\n  --spectrum-actionbutton-text-color-default: #000000;\n  --spectrum-actionbutton-background-color-hover: #4dd99a;\n}\n\n.profile-btn-uxp--secondary {\n  --spectrum-actionbutton-background-color-default: #444444;\n  --spectrum-actionbutton-text-color-default: #ffffff;\n  --spectrum-actionbutton-background-color-hover: #555555;\n}\n\n.profile-error {\n  color: #ff5252;\n  font-size: 12px;\n  padding: 8px 10px;\n  background-color: rgba(255, 82, 82, 0.1);\n  border-radius: 6px;\n  border: 1px solid rgba(255, 82, 82, 0.2);\n}\n\n/* ─── 线路选择 ─── */\n.profile-route-item {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 10px 12px;\n  border-radius: 6px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  border: 1px solid transparent;\n  background-color: transparent;\n  box-sizing: border-box;\n  user-select: none;\n  -webkit-user-select: none;\n}\n.profile-route-item:hover {\n  background-color: rgba(255, 255, 255, 0.06);\n}\n.profile-route-item:active {\n  transform: scale(0.98);\n  background-color: rgba(255, 255, 255, 0.1);\n}\n.profile-route-item.selected {\n  background-color: rgba(255, 255, 255, 0.1);\n  border-color: rgba(255, 255, 255, 0.12);\n}\n.profile-route-item.selected .profile-route-name {\n  color: #ffffff;\n  font-weight: 500;\n}\n\n.profile-route-dot {\n  width: 10px;\n  height: 10px;\n  border-radius: 50%;\n  flex-shrink: 0;\n  transition: all 0.2s ease;\n}\n.profile-route-dot.hollow {\n  background-color: transparent;\n  border: 2px solid;\n}\n.profile-route-dot.hollow.green {\n  border-color: #3ecf8e;\n}\n.profile-route-dot.hollow.red {\n  border-color: #ff5252;\n}\n.profile-route-dot.filled {\n  border: 2px solid transparent;\n}\n.profile-route-dot.filled.green {\n  background-color: #3ecf8e;\n  box-shadow: 0 0 8px rgba(62, 207, 142, 0.5);\n}\n.profile-route-dot.filled.red {\n  background-color: #ff5252;\n  box-shadow: 0 0 8px rgba(255, 82, 82, 0.5);\n}\n\n.profile-route-name {\n  font-size: 13px;\n  color: #cccccc;\n  transition: color 0.2s ease;\n}\n\n.profile-route-latency {\n  font-size: 12px;\n  font-weight: 600;\n  font-family: monospace;\n  margin-left: auto;\n  transition: color 0.2s ease;\n}\n.profile-route-latency.green {\n  color: #3ecf8e;\n}\n.profile-route-latency.red {\n  color: #ff5252;\n}\n\n.profile-route-badge {\n  font-size: 10px;\n  padding: 2px 8px;\n  border-radius: 10px;\n  background-color: rgba(62, 207, 142, 0.15);\n  color: #3ecf8e;\n  margin-left: 4px;\n  flex-shrink: 0;\n}\n\n/* ─── 链接与 Footer ─── */\n.profile-link-row {\n  display: flex;\n  justify-content: center;\n}\n\n.profile-link-btn {\n  --spectrum-actionbutton-background-color-default: transparent;\n  --spectrum-actionbutton-text-color-default: #888888;\n  --spectrum-actionbutton-background-color-hover: rgba(255, 255, 255, 0.06);\n  --spectrum-actionbutton-text-color-hover: #aaaaaa;\n}\n\n.profile-footer {\n  display: flex;\n  justify-content: center;\n  margin-top: 8px;\n}/*$vite$:1*/';
  document.head.appendChild(__vite_style__);
  var _documentCurrentScript = typeof document !== "undefined" ? document.currentScript : null;
  function getDefaultExportFromCjs(x) {
    return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x["default"] : x;
  }
  var jsxRuntime = { exports: {} };
  var reactJsxRuntime_production_min = {};
  var react = { exports: {} };
  var react_production_min = {};
  /**
   * @license React
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var hasRequiredReact_production_min;
  function requireReact_production_min() {
    if (hasRequiredReact_production_min) return react_production_min;
    hasRequiredReact_production_min = 1;
    var l = Symbol.for("react.element"), n = Symbol.for("react.portal"), p = Symbol.for("react.fragment"), q = Symbol.for("react.strict_mode"), r = Symbol.for("react.profiler"), t2 = Symbol.for("react.provider"), u = Symbol.for("react.context"), v = Symbol.for("react.forward_ref"), w = Symbol.for("react.suspense"), x = Symbol.for("react.memo"), y = Symbol.for("react.lazy"), z = Symbol.iterator;
    function A(a) {
      if (null === a || "object" !== typeof a) return null;
      a = z && a[z] || a["@@iterator"];
      return "function" === typeof a ? a : null;
    }
    var B = { isMounted: function() {
      return false;
    }, enqueueForceUpdate: function() {
    }, enqueueReplaceState: function() {
    }, enqueueSetState: function() {
    } }, C = Object.assign, D = {};
    function E(a, b, e) {
      this.props = a;
      this.context = b;
      this.refs = D;
      this.updater = e || B;
    }
    E.prototype.isReactComponent = {};
    E.prototype.setState = function(a, b) {
      if ("object" !== typeof a && "function" !== typeof a && null != a) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, a, b, "setState");
    };
    E.prototype.forceUpdate = function(a) {
      this.updater.enqueueForceUpdate(this, a, "forceUpdate");
    };
    function F() {
    }
    F.prototype = E.prototype;
    function G(a, b, e) {
      this.props = a;
      this.context = b;
      this.refs = D;
      this.updater = e || B;
    }
    var H = G.prototype = new F();
    H.constructor = G;
    C(H, E.prototype);
    H.isPureReactComponent = true;
    var I = Array.isArray, J = Object.prototype.hasOwnProperty, K = { current: null }, L = { key: true, ref: true, __self: true, __source: true };
    function M(a, b, e) {
      var d, c = {}, k = null, h = null;
      if (null != b) for (d in void 0 !== b.ref && (h = b.ref), void 0 !== b.key && (k = "" + b.key), b) J.call(b, d) && !L.hasOwnProperty(d) && (c[d] = b[d]);
      var g = arguments.length - 2;
      if (1 === g) c.children = e;
      else if (1 < g) {
        for (var f = Array(g), m = 0; m < g; m++) f[m] = arguments[m + 2];
        c.children = f;
      }
      if (a && a.defaultProps) for (d in g = a.defaultProps, g) void 0 === c[d] && (c[d] = g[d]);
      return { $$typeof: l, type: a, key: k, ref: h, props: c, _owner: K.current };
    }
    function N(a, b) {
      return { $$typeof: l, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner };
    }
    function O(a) {
      return "object" === typeof a && null !== a && a.$$typeof === l;
    }
    function escape(a) {
      var b = { "=": "=0", ":": "=2" };
      return "$" + a.replace(/[=:]/g, function(a2) {
        return b[a2];
      });
    }
    var P = /\/+/g;
    function Q(a, b) {
      return "object" === typeof a && null !== a && null != a.key ? escape("" + a.key) : b.toString(36);
    }
    function R(a, b, e, d, c) {
      var k = typeof a;
      if ("undefined" === k || "boolean" === k) a = null;
      var h = false;
      if (null === a) h = true;
      else switch (k) {
        case "string":
        case "number":
          h = true;
          break;
        case "object":
          switch (a.$$typeof) {
            case l:
            case n:
              h = true;
          }
      }
      if (h) return h = a, c = c(h), a = "" === d ? "." + Q(h, 0) : d, I(c) ? (e = "", null != a && (e = a.replace(P, "$&/") + "/"), R(c, b, e, "", function(a2) {
        return a2;
      })) : null != c && (O(c) && (c = N(c, e + (!c.key || h && h.key === c.key ? "" : ("" + c.key).replace(P, "$&/") + "/") + a)), b.push(c)), 1;
      h = 0;
      d = "" === d ? "." : d + ":";
      if (I(a)) for (var g = 0; g < a.length; g++) {
        k = a[g];
        var f = d + Q(k, g);
        h += R(k, b, e, f, c);
      }
      else if (f = A(a), "function" === typeof f) for (a = f.call(a), g = 0; !(k = a.next()).done; ) k = k.value, f = d + Q(k, g++), h += R(k, b, e, f, c);
      else if ("object" === k) throw b = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
      return h;
    }
    function S(a, b, e) {
      if (null == a) return a;
      var d = [], c = 0;
      R(a, d, "", "", function(a2) {
        return b.call(e, a2, c++);
      });
      return d;
    }
    function T(a) {
      if (-1 === a._status) {
        var b = a._result;
        b = b();
        b.then(function(b2) {
          if (0 === a._status || -1 === a._status) a._status = 1, a._result = b2;
        }, function(b2) {
          if (0 === a._status || -1 === a._status) a._status = 2, a._result = b2;
        });
        -1 === a._status && (a._status = 0, a._result = b);
      }
      if (1 === a._status) return a._result.default;
      throw a._result;
    }
    var U = { current: null }, V = { transition: null }, W = { ReactCurrentDispatcher: U, ReactCurrentBatchConfig: V, ReactCurrentOwner: K };
    function X() {
      throw Error("act(...) is not supported in production builds of React.");
    }
    react_production_min.Children = { map: S, forEach: function(a, b, e) {
      S(a, function() {
        b.apply(this, arguments);
      }, e);
    }, count: function(a) {
      var b = 0;
      S(a, function() {
        b++;
      });
      return b;
    }, toArray: function(a) {
      return S(a, function(a2) {
        return a2;
      }) || [];
    }, only: function(a) {
      if (!O(a)) throw Error("React.Children.only expected to receive a single React element child.");
      return a;
    } };
    react_production_min.Component = E;
    react_production_min.Fragment = p;
    react_production_min.Profiler = r;
    react_production_min.PureComponent = G;
    react_production_min.StrictMode = q;
    react_production_min.Suspense = w;
    react_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W;
    react_production_min.act = X;
    react_production_min.cloneElement = function(a, b, e) {
      if (null === a || void 0 === a) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
      var d = C({}, a.props), c = a.key, k = a.ref, h = a._owner;
      if (null != b) {
        void 0 !== b.ref && (k = b.ref, h = K.current);
        void 0 !== b.key && (c = "" + b.key);
        if (a.type && a.type.defaultProps) var g = a.type.defaultProps;
        for (f in b) J.call(b, f) && !L.hasOwnProperty(f) && (d[f] = void 0 === b[f] && void 0 !== g ? g[f] : b[f]);
      }
      var f = arguments.length - 2;
      if (1 === f) d.children = e;
      else if (1 < f) {
        g = Array(f);
        for (var m = 0; m < f; m++) g[m] = arguments[m + 2];
        d.children = g;
      }
      return { $$typeof: l, type: a.type, key: c, ref: k, props: d, _owner: h };
    };
    react_production_min.createContext = function(a) {
      a = { $$typeof: u, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
      a.Provider = { $$typeof: t2, _context: a };
      return a.Consumer = a;
    };
    react_production_min.createElement = M;
    react_production_min.createFactory = function(a) {
      var b = M.bind(null, a);
      b.type = a;
      return b;
    };
    react_production_min.createRef = function() {
      return { current: null };
    };
    react_production_min.forwardRef = function(a) {
      return { $$typeof: v, render: a };
    };
    react_production_min.isValidElement = O;
    react_production_min.lazy = function(a) {
      return { $$typeof: y, _payload: { _status: -1, _result: a }, _init: T };
    };
    react_production_min.memo = function(a, b) {
      return { $$typeof: x, type: a, compare: void 0 === b ? null : b };
    };
    react_production_min.startTransition = function(a) {
      var b = V.transition;
      V.transition = {};
      try {
        a();
      } finally {
        V.transition = b;
      }
    };
    react_production_min.unstable_act = X;
    react_production_min.useCallback = function(a, b) {
      return U.current.useCallback(a, b);
    };
    react_production_min.useContext = function(a) {
      return U.current.useContext(a);
    };
    react_production_min.useDebugValue = function() {
    };
    react_production_min.useDeferredValue = function(a) {
      return U.current.useDeferredValue(a);
    };
    react_production_min.useEffect = function(a, b) {
      return U.current.useEffect(a, b);
    };
    react_production_min.useId = function() {
      return U.current.useId();
    };
    react_production_min.useImperativeHandle = function(a, b, e) {
      return U.current.useImperativeHandle(a, b, e);
    };
    react_production_min.useInsertionEffect = function(a, b) {
      return U.current.useInsertionEffect(a, b);
    };
    react_production_min.useLayoutEffect = function(a, b) {
      return U.current.useLayoutEffect(a, b);
    };
    react_production_min.useMemo = function(a, b) {
      return U.current.useMemo(a, b);
    };
    react_production_min.useReducer = function(a, b, e) {
      return U.current.useReducer(a, b, e);
    };
    react_production_min.useRef = function(a) {
      return U.current.useRef(a);
    };
    react_production_min.useState = function(a) {
      return U.current.useState(a);
    };
    react_production_min.useSyncExternalStore = function(a, b, e) {
      return U.current.useSyncExternalStore(a, b, e);
    };
    react_production_min.useTransition = function() {
      return U.current.useTransition();
    };
    react_production_min.version = "18.3.1";
    return react_production_min;
  }
  var hasRequiredReact;
  function requireReact() {
    if (hasRequiredReact) return react.exports;
    hasRequiredReact = 1;
    {
      react.exports = requireReact_production_min();
    }
    return react.exports;
  }
  /**
   * @license React
   * react-jsx-runtime.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var hasRequiredReactJsxRuntime_production_min;
  function requireReactJsxRuntime_production_min() {
    if (hasRequiredReactJsxRuntime_production_min) return reactJsxRuntime_production_min;
    hasRequiredReactJsxRuntime_production_min = 1;
    var f = requireReact(), k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
    function q(c, a, g) {
      var b, d = {}, e = null, h = null;
      void 0 !== g && (e = "" + g);
      void 0 !== a.key && (e = "" + a.key);
      void 0 !== a.ref && (h = a.ref);
      for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
      if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
      return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
    }
    reactJsxRuntime_production_min.Fragment = l;
    reactJsxRuntime_production_min.jsx = q;
    reactJsxRuntime_production_min.jsxs = q;
    return reactJsxRuntime_production_min;
  }
  var hasRequiredJsxRuntime;
  function requireJsxRuntime() {
    if (hasRequiredJsxRuntime) return jsxRuntime.exports;
    hasRequiredJsxRuntime = 1;
    {
      jsxRuntime.exports = requireReactJsxRuntime_production_min();
    }
    return jsxRuntime.exports;
  }
  var jsxRuntimeExports = requireJsxRuntime();
  var reactExports = requireReact();
  const React = /* @__PURE__ */ getDefaultExportFromCjs(reactExports);
  var client = {};
  var reactDom = { exports: {} };
  var reactDom_production_min = {};
  var scheduler = { exports: {} };
  var scheduler_production_min = {};
  /**
   * @license React
   * scheduler.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var hasRequiredScheduler_production_min;
  function requireScheduler_production_min() {
    if (hasRequiredScheduler_production_min) return scheduler_production_min;
    hasRequiredScheduler_production_min = 1;
    (function(exports) {
      function f(a, b) {
        var c = a.length;
        a.push(b);
        a: for (; 0 < c; ) {
          var d = c - 1 >>> 1, e = a[d];
          if (0 < g(e, b)) a[d] = b, a[c] = e, c = d;
          else break a;
        }
      }
      function h(a) {
        return 0 === a.length ? null : a[0];
      }
      function k(a) {
        if (0 === a.length) return null;
        var b = a[0], c = a.pop();
        if (c !== b) {
          a[0] = c;
          a: for (var d = 0, e = a.length, w = e >>> 1; d < w; ) {
            var m = 2 * (d + 1) - 1, C = a[m], n = m + 1, x = a[n];
            if (0 > g(C, c)) n < e && 0 > g(x, C) ? (a[d] = x, a[n] = c, d = n) : (a[d] = C, a[m] = c, d = m);
            else if (n < e && 0 > g(x, c)) a[d] = x, a[n] = c, d = n;
            else break a;
          }
        }
        return b;
      }
      function g(a, b) {
        var c = a.sortIndex - b.sortIndex;
        return 0 !== c ? c : a.id - b.id;
      }
      if ("object" === typeof performance && "function" === typeof performance.now) {
        var l = performance;
        exports.unstable_now = function() {
          return l.now();
        };
      } else {
        var p = Date, q = p.now();
        exports.unstable_now = function() {
          return p.now() - q;
        };
      }
      var r = [], t2 = [], u = 1, v = null, y = 3, z = false, A = false, B = false, D = "function" === typeof setTimeout ? setTimeout : null, E = "function" === typeof clearTimeout ? clearTimeout : null, F = "undefined" !== typeof setImmediate ? setImmediate : null;
      "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
      function G(a) {
        for (var b = h(t2); null !== b; ) {
          if (null === b.callback) k(t2);
          else if (b.startTime <= a) k(t2), b.sortIndex = b.expirationTime, f(r, b);
          else break;
          b = h(t2);
        }
      }
      function H(a) {
        B = false;
        G(a);
        if (!A) if (null !== h(r)) A = true, I(J);
        else {
          var b = h(t2);
          null !== b && K(H, b.startTime - a);
        }
      }
      function J(a, b) {
        A = false;
        B && (B = false, E(L), L = -1);
        z = true;
        var c = y;
        try {
          G(b);
          for (v = h(r); null !== v && (!(v.expirationTime > b) || a && !M()); ) {
            var d = v.callback;
            if ("function" === typeof d) {
              v.callback = null;
              y = v.priorityLevel;
              var e = d(v.expirationTime <= b);
              b = exports.unstable_now();
              "function" === typeof e ? v.callback = e : v === h(r) && k(r);
              G(b);
            } else k(r);
            v = h(r);
          }
          if (null !== v) var w = true;
          else {
            var m = h(t2);
            null !== m && K(H, m.startTime - b);
            w = false;
          }
          return w;
        } finally {
          v = null, y = c, z = false;
        }
      }
      var N = false, O = null, L = -1, P = 5, Q = -1;
      function M() {
        return exports.unstable_now() - Q < P ? false : true;
      }
      function R() {
        if (null !== O) {
          var a = exports.unstable_now();
          Q = a;
          var b = true;
          try {
            b = O(true, a);
          } finally {
            b ? S() : (N = false, O = null);
          }
        } else N = false;
      }
      var S;
      if ("function" === typeof F) S = function() {
        F(R);
      };
      else if ("undefined" !== typeof MessageChannel) {
        var T = new MessageChannel(), U = T.port2;
        T.port1.onmessage = R;
        S = function() {
          U.postMessage(null);
        };
      } else S = function() {
        D(R, 0);
      };
      function I(a) {
        O = a;
        N || (N = true, S());
      }
      function K(a, b) {
        L = D(function() {
          a(exports.unstable_now());
        }, b);
      }
      exports.unstable_IdlePriority = 5;
      exports.unstable_ImmediatePriority = 1;
      exports.unstable_LowPriority = 4;
      exports.unstable_NormalPriority = 3;
      exports.unstable_Profiling = null;
      exports.unstable_UserBlockingPriority = 2;
      exports.unstable_cancelCallback = function(a) {
        a.callback = null;
      };
      exports.unstable_continueExecution = function() {
        A || z || (A = true, I(J));
      };
      exports.unstable_forceFrameRate = function(a) {
        0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P = 0 < a ? Math.floor(1e3 / a) : 5;
      };
      exports.unstable_getCurrentPriorityLevel = function() {
        return y;
      };
      exports.unstable_getFirstCallbackNode = function() {
        return h(r);
      };
      exports.unstable_next = function(a) {
        switch (y) {
          case 1:
          case 2:
          case 3:
            var b = 3;
            break;
          default:
            b = y;
        }
        var c = y;
        y = b;
        try {
          return a();
        } finally {
          y = c;
        }
      };
      exports.unstable_pauseExecution = function() {
      };
      exports.unstable_requestPaint = function() {
      };
      exports.unstable_runWithPriority = function(a, b) {
        switch (a) {
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
          default:
            a = 3;
        }
        var c = y;
        y = a;
        try {
          return b();
        } finally {
          y = c;
        }
      };
      exports.unstable_scheduleCallback = function(a, b, c) {
        var d = exports.unstable_now();
        "object" === typeof c && null !== c ? (c = c.delay, c = "number" === typeof c && 0 < c ? d + c : d) : c = d;
        switch (a) {
          case 1:
            var e = -1;
            break;
          case 2:
            e = 250;
            break;
          case 5:
            e = 1073741823;
            break;
          case 4:
            e = 1e4;
            break;
          default:
            e = 5e3;
        }
        e = c + e;
        a = { id: u++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1 };
        c > d ? (a.sortIndex = c, f(t2, a), null === h(r) && a === h(t2) && (B ? (E(L), L = -1) : B = true, K(H, c - d))) : (a.sortIndex = e, f(r, a), A || z || (A = true, I(J)));
        return a;
      };
      exports.unstable_shouldYield = M;
      exports.unstable_wrapCallback = function(a) {
        var b = y;
        return function() {
          var c = y;
          y = b;
          try {
            return a.apply(this, arguments);
          } finally {
            y = c;
          }
        };
      };
    })(scheduler_production_min);
    return scheduler_production_min;
  }
  var hasRequiredScheduler;
  function requireScheduler() {
    if (hasRequiredScheduler) return scheduler.exports;
    hasRequiredScheduler = 1;
    {
      scheduler.exports = requireScheduler_production_min();
    }
    return scheduler.exports;
  }
  /**
   * @license React
   * react-dom.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var hasRequiredReactDom_production_min;
  function requireReactDom_production_min() {
    if (hasRequiredReactDom_production_min) return reactDom_production_min;
    hasRequiredReactDom_production_min = 1;
    var aa = requireReact(), ca = requireScheduler();
    function p(a) {
      for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++) b += "&args[]=" + encodeURIComponent(arguments[c]);
      return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    var da = /* @__PURE__ */ new Set(), ea = {};
    function fa(a, b) {
      ha(a, b);
      ha(a + "Capture", b);
    }
    function ha(a, b) {
      ea[a] = b;
      for (a = 0; a < b.length; a++) da.add(b[a]);
    }
    var ia = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement), ja = Object.prototype.hasOwnProperty, ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, la = {}, ma = {};
    function oa(a) {
      if (ja.call(ma, a)) return true;
      if (ja.call(la, a)) return false;
      if (ka.test(a)) return ma[a] = true;
      la[a] = true;
      return false;
    }
    function pa(a, b, c, d) {
      if (null !== c && 0 === c.type) return false;
      switch (typeof b) {
        case "function":
        case "symbol":
          return true;
        case "boolean":
          if (d) return false;
          if (null !== c) return !c.acceptsBooleans;
          a = a.toLowerCase().slice(0, 5);
          return "data-" !== a && "aria-" !== a;
        default:
          return false;
      }
    }
    function qa(a, b, c, d) {
      if (null === b || "undefined" === typeof b || pa(a, b, c, d)) return true;
      if (d) return false;
      if (null !== c) switch (c.type) {
        case 3:
          return !b;
        case 4:
          return false === b;
        case 5:
          return isNaN(b);
        case 6:
          return isNaN(b) || 1 > b;
      }
      return false;
    }
    function v(a, b, c, d, e, f, g) {
      this.acceptsBooleans = 2 === b || 3 === b || 4 === b;
      this.attributeName = d;
      this.attributeNamespace = e;
      this.mustUseProperty = c;
      this.propertyName = a;
      this.type = b;
      this.sanitizeURL = f;
      this.removeEmptyString = g;
    }
    var z = {};
    "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
      z[a] = new v(a, 0, false, a, null, false, false);
    });
    [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
      var b = a[0];
      z[b] = new v(b, 1, false, a[1], null, false, false);
    });
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
      z[a] = new v(a, 2, false, a.toLowerCase(), null, false, false);
    });
    ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
      z[a] = new v(a, 2, false, a, null, false, false);
    });
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
      z[a] = new v(a, 3, false, a.toLowerCase(), null, false, false);
    });
    ["checked", "multiple", "muted", "selected"].forEach(function(a) {
      z[a] = new v(a, 3, true, a, null, false, false);
    });
    ["capture", "download"].forEach(function(a) {
      z[a] = new v(a, 4, false, a, null, false, false);
    });
    ["cols", "rows", "size", "span"].forEach(function(a) {
      z[a] = new v(a, 6, false, a, null, false, false);
    });
    ["rowSpan", "start"].forEach(function(a) {
      z[a] = new v(a, 5, false, a.toLowerCase(), null, false, false);
    });
    var ra = /[\-:]([a-z])/g;
    function sa(a) {
      return a[1].toUpperCase();
    }
    "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
      var b = a.replace(
        ra,
        sa
      );
      z[b] = new v(b, 1, false, a, null, false, false);
    });
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
      var b = a.replace(ra, sa);
      z[b] = new v(b, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
    });
    ["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
      var b = a.replace(ra, sa);
      z[b] = new v(b, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
    });
    ["tabIndex", "crossOrigin"].forEach(function(a) {
      z[a] = new v(a, 1, false, a.toLowerCase(), null, false, false);
    });
    z.xlinkHref = new v("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
    ["src", "href", "action", "formAction"].forEach(function(a) {
      z[a] = new v(a, 1, false, a.toLowerCase(), null, true, true);
    });
    function ta(a, b, c, d) {
      var e = z.hasOwnProperty(b) ? z[b] : null;
      if (null !== e ? 0 !== e.type : d || !(2 < b.length) || "o" !== b[0] && "O" !== b[0] || "n" !== b[1] && "N" !== b[1]) qa(b, c, e, d) && (c = null), d || null === e ? oa(b) && (null === c ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = null === c ? 3 === e.type ? false : "" : c : (b = e.attributeName, d = e.attributeNamespace, null === c ? a.removeAttribute(b) : (e = e.type, c = 3 === e || 4 === e && true === c ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)));
    }
    var ua = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, va = Symbol.for("react.element"), wa = Symbol.for("react.portal"), ya = Symbol.for("react.fragment"), za = Symbol.for("react.strict_mode"), Aa = Symbol.for("react.profiler"), Ba = Symbol.for("react.provider"), Ca = Symbol.for("react.context"), Da = Symbol.for("react.forward_ref"), Ea = Symbol.for("react.suspense"), Fa = Symbol.for("react.suspense_list"), Ga = Symbol.for("react.memo"), Ha = Symbol.for("react.lazy");
    var Ia = Symbol.for("react.offscreen");
    var Ja = Symbol.iterator;
    function Ka(a) {
      if (null === a || "object" !== typeof a) return null;
      a = Ja && a[Ja] || a["@@iterator"];
      return "function" === typeof a ? a : null;
    }
    var A = Object.assign, La;
    function Ma(a) {
      if (void 0 === La) try {
        throw Error();
      } catch (c) {
        var b = c.stack.trim().match(/\n( *(at )?)/);
        La = b && b[1] || "";
      }
      return "\n" + La + a;
    }
    var Na = false;
    function Oa(a, b) {
      if (!a || Na) return "";
      Na = true;
      var c = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        if (b) if (b = function() {
          throw Error();
        }, Object.defineProperty(b.prototype, "props", { set: function() {
          throw Error();
        } }), "object" === typeof Reflect && Reflect.construct) {
          try {
            Reflect.construct(b, []);
          } catch (l) {
            var d = l;
          }
          Reflect.construct(a, [], b);
        } else {
          try {
            b.call();
          } catch (l) {
            d = l;
          }
          a.call(b.prototype);
        }
        else {
          try {
            throw Error();
          } catch (l) {
            d = l;
          }
          a();
        }
      } catch (l) {
        if (l && d && "string" === typeof l.stack) {
          for (var e = l.stack.split("\n"), f = d.stack.split("\n"), g = e.length - 1, h = f.length - 1; 1 <= g && 0 <= h && e[g] !== f[h]; ) h--;
          for (; 1 <= g && 0 <= h; g--, h--) if (e[g] !== f[h]) {
            if (1 !== g || 1 !== h) {
              do
                if (g--, h--, 0 > h || e[g] !== f[h]) {
                  var k = "\n" + e[g].replace(" at new ", " at ");
                  a.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", a.displayName));
                  return k;
                }
              while (1 <= g && 0 <= h);
            }
            break;
          }
        }
      } finally {
        Na = false, Error.prepareStackTrace = c;
      }
      return (a = a ? a.displayName || a.name : "") ? Ma(a) : "";
    }
    function Pa(a) {
      switch (a.tag) {
        case 5:
          return Ma(a.type);
        case 16:
          return Ma("Lazy");
        case 13:
          return Ma("Suspense");
        case 19:
          return Ma("SuspenseList");
        case 0:
        case 2:
        case 15:
          return a = Oa(a.type, false), a;
        case 11:
          return a = Oa(a.type.render, false), a;
        case 1:
          return a = Oa(a.type, true), a;
        default:
          return "";
      }
    }
    function Qa(a) {
      if (null == a) return null;
      if ("function" === typeof a) return a.displayName || a.name || null;
      if ("string" === typeof a) return a;
      switch (a) {
        case ya:
          return "Fragment";
        case wa:
          return "Portal";
        case Aa:
          return "Profiler";
        case za:
          return "StrictMode";
        case Ea:
          return "Suspense";
        case Fa:
          return "SuspenseList";
      }
      if ("object" === typeof a) switch (a.$$typeof) {
        case Ca:
          return (a.displayName || "Context") + ".Consumer";
        case Ba:
          return (a._context.displayName || "Context") + ".Provider";
        case Da:
          var b = a.render;
          a = a.displayName;
          a || (a = b.displayName || b.name || "", a = "" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
          return a;
        case Ga:
          return b = a.displayName || null, null !== b ? b : Qa(a.type) || "Memo";
        case Ha:
          b = a._payload;
          a = a._init;
          try {
            return Qa(a(b));
          } catch (c) {
          }
      }
      return null;
    }
    function Ra(a) {
      var b = a.type;
      switch (a.tag) {
        case 24:
          return "Cache";
        case 9:
          return (b.displayName || "Context") + ".Consumer";
        case 10:
          return (b._context.displayName || "Context") + ".Provider";
        case 18:
          return "DehydratedFragment";
        case 11:
          return a = b.render, a = a.displayName || a.name || "", b.displayName || ("" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
        case 7:
          return "Fragment";
        case 5:
          return b;
        case 4:
          return "Portal";
        case 3:
          return "Root";
        case 6:
          return "Text";
        case 16:
          return Qa(b);
        case 8:
          return b === za ? "StrictMode" : "Mode";
        case 22:
          return "Offscreen";
        case 12:
          return "Profiler";
        case 21:
          return "Scope";
        case 13:
          return "Suspense";
        case 19:
          return "SuspenseList";
        case 25:
          return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
          if ("function" === typeof b) return b.displayName || b.name || null;
          if ("string" === typeof b) return b;
      }
      return null;
    }
    function Sa(a) {
      switch (typeof a) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
          return a;
        case "object":
          return a;
        default:
          return "";
      }
    }
    function Ta(a) {
      var b = a.type;
      return (a = a.nodeName) && "input" === a.toLowerCase() && ("checkbox" === b || "radio" === b);
    }
    function Ua(a) {
      var b = Ta(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
      if (!a.hasOwnProperty(b) && "undefined" !== typeof c && "function" === typeof c.get && "function" === typeof c.set) {
        var e = c.get, f = c.set;
        Object.defineProperty(a, b, { configurable: true, get: function() {
          return e.call(this);
        }, set: function(a2) {
          d = "" + a2;
          f.call(this, a2);
        } });
        Object.defineProperty(a, b, { enumerable: c.enumerable });
        return { getValue: function() {
          return d;
        }, setValue: function(a2) {
          d = "" + a2;
        }, stopTracking: function() {
          a._valueTracker = null;
          delete a[b];
        } };
      }
    }
    function Va(a) {
      a._valueTracker || (a._valueTracker = Ua(a));
    }
    function Wa(a) {
      if (!a) return false;
      var b = a._valueTracker;
      if (!b) return true;
      var c = b.getValue();
      var d = "";
      a && (d = Ta(a) ? a.checked ? "true" : "false" : a.value);
      a = d;
      return a !== c ? (b.setValue(a), true) : false;
    }
    function Xa(a) {
      a = a || ("undefined" !== typeof document ? document : void 0);
      if ("undefined" === typeof a) return null;
      try {
        return a.activeElement || a.body;
      } catch (b) {
        return a.body;
      }
    }
    function Ya(a, b) {
      var c = b.checked;
      return A({}, b, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: null != c ? c : a._wrapperState.initialChecked });
    }
    function Za(a, b) {
      var c = null == b.defaultValue ? "" : b.defaultValue, d = null != b.checked ? b.checked : b.defaultChecked;
      c = Sa(null != b.value ? b.value : c);
      a._wrapperState = { initialChecked: d, initialValue: c, controlled: "checkbox" === b.type || "radio" === b.type ? null != b.checked : null != b.value };
    }
    function ab(a, b) {
      b = b.checked;
      null != b && ta(a, "checked", b, false);
    }
    function bb(a, b) {
      ab(a, b);
      var c = Sa(b.value), d = b.type;
      if (null != c) if ("number" === d) {
        if (0 === c && "" === a.value || a.value != c) a.value = "" + c;
      } else a.value !== "" + c && (a.value = "" + c);
      else if ("submit" === d || "reset" === d) {
        a.removeAttribute("value");
        return;
      }
      b.hasOwnProperty("value") ? cb(a, b.type, c) : b.hasOwnProperty("defaultValue") && cb(a, b.type, Sa(b.defaultValue));
      null == b.checked && null != b.defaultChecked && (a.defaultChecked = !!b.defaultChecked);
    }
    function db(a, b, c) {
      if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
        var d = b.type;
        if (!("submit" !== d && "reset" !== d || void 0 !== b.value && null !== b.value)) return;
        b = "" + a._wrapperState.initialValue;
        c || b === a.value || (a.value = b);
        a.defaultValue = b;
      }
      c = a.name;
      "" !== c && (a.name = "");
      a.defaultChecked = !!a._wrapperState.initialChecked;
      "" !== c && (a.name = c);
    }
    function cb(a, b, c) {
      if ("number" !== b || Xa(a.ownerDocument) !== a) null == c ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
    }
    var eb = Array.isArray;
    function fb(a, b, c, d) {
      a = a.options;
      if (b) {
        b = {};
        for (var e = 0; e < c.length; e++) b["$" + c[e]] = true;
        for (c = 0; c < a.length; c++) e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = true);
      } else {
        c = "" + Sa(c);
        b = null;
        for (e = 0; e < a.length; e++) {
          if (a[e].value === c) {
            a[e].selected = true;
            d && (a[e].defaultSelected = true);
            return;
          }
          null !== b || a[e].disabled || (b = a[e]);
        }
        null !== b && (b.selected = true);
      }
    }
    function gb(a, b) {
      if (null != b.dangerouslySetInnerHTML) throw Error(p(91));
      return A({}, b, { value: void 0, defaultValue: void 0, children: "" + a._wrapperState.initialValue });
    }
    function hb(a, b) {
      var c = b.value;
      if (null == c) {
        c = b.children;
        b = b.defaultValue;
        if (null != c) {
          if (null != b) throw Error(p(92));
          if (eb(c)) {
            if (1 < c.length) throw Error(p(93));
            c = c[0];
          }
          b = c;
        }
        null == b && (b = "");
        c = b;
      }
      a._wrapperState = { initialValue: Sa(c) };
    }
    function ib(a, b) {
      var c = Sa(b.value), d = Sa(b.defaultValue);
      null != c && (c = "" + c, c !== a.value && (a.value = c), null == b.defaultValue && a.defaultValue !== c && (a.defaultValue = c));
      null != d && (a.defaultValue = "" + d);
    }
    function jb(a) {
      var b = a.textContent;
      b === a._wrapperState.initialValue && "" !== b && null !== b && (a.value = b);
    }
    function kb(a) {
      switch (a) {
        case "svg":
          return "http://www.w3.org/2000/svg";
        case "math":
          return "http://www.w3.org/1998/Math/MathML";
        default:
          return "http://www.w3.org/1999/xhtml";
      }
    }
    function lb(a, b) {
      return null == a || "http://www.w3.org/1999/xhtml" === a ? kb(b) : "http://www.w3.org/2000/svg" === a && "foreignObject" === b ? "http://www.w3.org/1999/xhtml" : a;
    }
    var mb, nb = function(a) {
      return "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
        MSApp.execUnsafeLocalFunction(function() {
          return a(b, c, d, e);
        });
      } : a;
    }(function(a, b) {
      if ("http://www.w3.org/2000/svg" !== a.namespaceURI || "innerHTML" in a) a.innerHTML = b;
      else {
        mb = mb || document.createElement("div");
        mb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
        for (b = mb.firstChild; a.firstChild; ) a.removeChild(a.firstChild);
        for (; b.firstChild; ) a.appendChild(b.firstChild);
      }
    });
    function ob(a, b) {
      if (b) {
        var c = a.firstChild;
        if (c && c === a.lastChild && 3 === c.nodeType) {
          c.nodeValue = b;
          return;
        }
      }
      a.textContent = b;
    }
    var pb = {
      animationIterationCount: true,
      aspectRatio: true,
      borderImageOutset: true,
      borderImageSlice: true,
      borderImageWidth: true,
      boxFlex: true,
      boxFlexGroup: true,
      boxOrdinalGroup: true,
      columnCount: true,
      columns: true,
      flex: true,
      flexGrow: true,
      flexPositive: true,
      flexShrink: true,
      flexNegative: true,
      flexOrder: true,
      gridArea: true,
      gridRow: true,
      gridRowEnd: true,
      gridRowSpan: true,
      gridRowStart: true,
      gridColumn: true,
      gridColumnEnd: true,
      gridColumnSpan: true,
      gridColumnStart: true,
      fontWeight: true,
      lineClamp: true,
      lineHeight: true,
      opacity: true,
      order: true,
      orphans: true,
      tabSize: true,
      widows: true,
      zIndex: true,
      zoom: true,
      fillOpacity: true,
      floodOpacity: true,
      stopOpacity: true,
      strokeDasharray: true,
      strokeDashoffset: true,
      strokeMiterlimit: true,
      strokeOpacity: true,
      strokeWidth: true
    }, qb = ["Webkit", "ms", "Moz", "O"];
    Object.keys(pb).forEach(function(a) {
      qb.forEach(function(b) {
        b = b + a.charAt(0).toUpperCase() + a.substring(1);
        pb[b] = pb[a];
      });
    });
    function rb(a, b, c) {
      return null == b || "boolean" === typeof b || "" === b ? "" : c || "number" !== typeof b || 0 === b || pb.hasOwnProperty(a) && pb[a] ? ("" + b).trim() : b + "px";
    }
    function sb(a, b) {
      a = a.style;
      for (var c in b) if (b.hasOwnProperty(c)) {
        var d = 0 === c.indexOf("--"), e = rb(c, b[c], d);
        "float" === c && (c = "cssFloat");
        d ? a.setProperty(c, e) : a[c] = e;
      }
    }
    var tb = A({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
    function ub(a, b) {
      if (b) {
        if (tb[a] && (null != b.children || null != b.dangerouslySetInnerHTML)) throw Error(p(137, a));
        if (null != b.dangerouslySetInnerHTML) {
          if (null != b.children) throw Error(p(60));
          if ("object" !== typeof b.dangerouslySetInnerHTML || !("__html" in b.dangerouslySetInnerHTML)) throw Error(p(61));
        }
        if (null != b.style && "object" !== typeof b.style) throw Error(p(62));
      }
    }
    function vb(a, b) {
      if (-1 === a.indexOf("-")) return "string" === typeof b.is;
      switch (a) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
          return false;
        default:
          return true;
      }
    }
    var wb = null;
    function xb(a) {
      a = a.target || a.srcElement || window;
      a.correspondingUseElement && (a = a.correspondingUseElement);
      return 3 === a.nodeType ? a.parentNode : a;
    }
    var yb = null, zb = null, Ab = null;
    function Bb(a) {
      if (a = Cb(a)) {
        if ("function" !== typeof yb) throw Error(p(280));
        var b = a.stateNode;
        b && (b = Db(b), yb(a.stateNode, a.type, b));
      }
    }
    function Eb(a) {
      zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
    }
    function Fb() {
      if (zb) {
        var a = zb, b = Ab;
        Ab = zb = null;
        Bb(a);
        if (b) for (a = 0; a < b.length; a++) Bb(b[a]);
      }
    }
    function Gb(a, b) {
      return a(b);
    }
    function Hb() {
    }
    var Ib = false;
    function Jb(a, b, c) {
      if (Ib) return a(b, c);
      Ib = true;
      try {
        return Gb(a, b, c);
      } finally {
        if (Ib = false, null !== zb || null !== Ab) Hb(), Fb();
      }
    }
    function Kb(a, b) {
      var c = a.stateNode;
      if (null === c) return null;
      var d = Db(c);
      if (null === d) return null;
      c = d[b];
      a: switch (b) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (d = !d.disabled) || (a = a.type, d = !("button" === a || "input" === a || "select" === a || "textarea" === a));
          a = !d;
          break a;
        default:
          a = false;
      }
      if (a) return null;
      if (c && "function" !== typeof c) throw Error(p(231, b, typeof c));
      return c;
    }
    var Lb = false;
    if (ia) try {
      var Mb = {};
      Object.defineProperty(Mb, "passive", { get: function() {
        Lb = true;
      } });
      window.addEventListener("test", Mb, Mb);
      window.removeEventListener("test", Mb, Mb);
    } catch (a) {
      Lb = false;
    }
    function Nb(a, b, c, d, e, f, g, h, k) {
      var l = Array.prototype.slice.call(arguments, 3);
      try {
        b.apply(c, l);
      } catch (m) {
        this.onError(m);
      }
    }
    var Ob = false, Pb = null, Qb = false, Rb = null, Sb = { onError: function(a) {
      Ob = true;
      Pb = a;
    } };
    function Tb(a, b, c, d, e, f, g, h, k) {
      Ob = false;
      Pb = null;
      Nb.apply(Sb, arguments);
    }
    function Ub(a, b, c, d, e, f, g, h, k) {
      Tb.apply(this, arguments);
      if (Ob) {
        if (Ob) {
          var l = Pb;
          Ob = false;
          Pb = null;
        } else throw Error(p(198));
        Qb || (Qb = true, Rb = l);
      }
    }
    function Vb(a) {
      var b = a, c = a;
      if (a.alternate) for (; b.return; ) b = b.return;
      else {
        a = b;
        do
          b = a, 0 !== (b.flags & 4098) && (c = b.return), a = b.return;
        while (a);
      }
      return 3 === b.tag ? c : null;
    }
    function Wb(a) {
      if (13 === a.tag) {
        var b = a.memoizedState;
        null === b && (a = a.alternate, null !== a && (b = a.memoizedState));
        if (null !== b) return b.dehydrated;
      }
      return null;
    }
    function Xb(a) {
      if (Vb(a) !== a) throw Error(p(188));
    }
    function Yb(a) {
      var b = a.alternate;
      if (!b) {
        b = Vb(a);
        if (null === b) throw Error(p(188));
        return b !== a ? null : a;
      }
      for (var c = a, d = b; ; ) {
        var e = c.return;
        if (null === e) break;
        var f = e.alternate;
        if (null === f) {
          d = e.return;
          if (null !== d) {
            c = d;
            continue;
          }
          break;
        }
        if (e.child === f.child) {
          for (f = e.child; f; ) {
            if (f === c) return Xb(e), a;
            if (f === d) return Xb(e), b;
            f = f.sibling;
          }
          throw Error(p(188));
        }
        if (c.return !== d.return) c = e, d = f;
        else {
          for (var g = false, h = e.child; h; ) {
            if (h === c) {
              g = true;
              c = e;
              d = f;
              break;
            }
            if (h === d) {
              g = true;
              d = e;
              c = f;
              break;
            }
            h = h.sibling;
          }
          if (!g) {
            for (h = f.child; h; ) {
              if (h === c) {
                g = true;
                c = f;
                d = e;
                break;
              }
              if (h === d) {
                g = true;
                d = f;
                c = e;
                break;
              }
              h = h.sibling;
            }
            if (!g) throw Error(p(189));
          }
        }
        if (c.alternate !== d) throw Error(p(190));
      }
      if (3 !== c.tag) throw Error(p(188));
      return c.stateNode.current === c ? a : b;
    }
    function Zb(a) {
      a = Yb(a);
      return null !== a ? $b(a) : null;
    }
    function $b(a) {
      if (5 === a.tag || 6 === a.tag) return a;
      for (a = a.child; null !== a; ) {
        var b = $b(a);
        if (null !== b) return b;
        a = a.sibling;
      }
      return null;
    }
    var ac = ca.unstable_scheduleCallback, bc = ca.unstable_cancelCallback, cc = ca.unstable_shouldYield, dc = ca.unstable_requestPaint, B = ca.unstable_now, ec = ca.unstable_getCurrentPriorityLevel, fc = ca.unstable_ImmediatePriority, gc = ca.unstable_UserBlockingPriority, hc = ca.unstable_NormalPriority, ic = ca.unstable_LowPriority, jc = ca.unstable_IdlePriority, kc = null, lc = null;
    function mc(a) {
      if (lc && "function" === typeof lc.onCommitFiberRoot) try {
        lc.onCommitFiberRoot(kc, a, void 0, 128 === (a.current.flags & 128));
      } catch (b) {
      }
    }
    var oc = Math.clz32 ? Math.clz32 : nc, pc = Math.log, qc = Math.LN2;
    function nc(a) {
      a >>>= 0;
      return 0 === a ? 32 : 31 - (pc(a) / qc | 0) | 0;
    }
    var rc = 64, sc = 4194304;
    function tc(a) {
      switch (a & -a) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return a & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          return a & 130023424;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 1073741824;
        default:
          return a;
      }
    }
    function uc(a, b) {
      var c = a.pendingLanes;
      if (0 === c) return 0;
      var d = 0, e = a.suspendedLanes, f = a.pingedLanes, g = c & 268435455;
      if (0 !== g) {
        var h = g & ~e;
        0 !== h ? d = tc(h) : (f &= g, 0 !== f && (d = tc(f)));
      } else g = c & ~e, 0 !== g ? d = tc(g) : 0 !== f && (d = tc(f));
      if (0 === d) return 0;
      if (0 !== b && b !== d && 0 === (b & e) && (e = d & -d, f = b & -b, e >= f || 16 === e && 0 !== (f & 4194240))) return b;
      0 !== (d & 4) && (d |= c & 16);
      b = a.entangledLanes;
      if (0 !== b) for (a = a.entanglements, b &= d; 0 < b; ) c = 31 - oc(b), e = 1 << c, d |= a[c], b &= ~e;
      return d;
    }
    function vc(a, b) {
      switch (a) {
        case 1:
        case 2:
        case 4:
          return b + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return b + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function wc(a, b) {
      for (var c = a.suspendedLanes, d = a.pingedLanes, e = a.expirationTimes, f = a.pendingLanes; 0 < f; ) {
        var g = 31 - oc(f), h = 1 << g, k = e[g];
        if (-1 === k) {
          if (0 === (h & c) || 0 !== (h & d)) e[g] = vc(h, b);
        } else k <= b && (a.expiredLanes |= h);
        f &= ~h;
      }
    }
    function xc(a) {
      a = a.pendingLanes & -1073741825;
      return 0 !== a ? a : a & 1073741824 ? 1073741824 : 0;
    }
    function yc() {
      var a = rc;
      rc <<= 1;
      0 === (rc & 4194240) && (rc = 64);
      return a;
    }
    function zc(a) {
      for (var b = [], c = 0; 31 > c; c++) b.push(a);
      return b;
    }
    function Ac(a, b, c) {
      a.pendingLanes |= b;
      536870912 !== b && (a.suspendedLanes = 0, a.pingedLanes = 0);
      a = a.eventTimes;
      b = 31 - oc(b);
      a[b] = c;
    }
    function Bc(a, b) {
      var c = a.pendingLanes & ~b;
      a.pendingLanes = b;
      a.suspendedLanes = 0;
      a.pingedLanes = 0;
      a.expiredLanes &= b;
      a.mutableReadLanes &= b;
      a.entangledLanes &= b;
      b = a.entanglements;
      var d = a.eventTimes;
      for (a = a.expirationTimes; 0 < c; ) {
        var e = 31 - oc(c), f = 1 << e;
        b[e] = 0;
        d[e] = -1;
        a[e] = -1;
        c &= ~f;
      }
    }
    function Cc(a, b) {
      var c = a.entangledLanes |= b;
      for (a = a.entanglements; c; ) {
        var d = 31 - oc(c), e = 1 << d;
        e & b | a[d] & b && (a[d] |= b);
        c &= ~e;
      }
    }
    var C = 0;
    function Dc(a) {
      a &= -a;
      return 1 < a ? 4 < a ? 0 !== (a & 268435455) ? 16 : 536870912 : 4 : 1;
    }
    var Ec, Fc, Gc, Hc, Ic, Jc = false, Kc = [], Lc = null, Mc = null, Nc = null, Oc = /* @__PURE__ */ new Map(), Pc = /* @__PURE__ */ new Map(), Qc = [], Rc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
    function Sc(a, b) {
      switch (a) {
        case "focusin":
        case "focusout":
          Lc = null;
          break;
        case "dragenter":
        case "dragleave":
          Mc = null;
          break;
        case "mouseover":
        case "mouseout":
          Nc = null;
          break;
        case "pointerover":
        case "pointerout":
          Oc.delete(b.pointerId);
          break;
        case "gotpointercapture":
        case "lostpointercapture":
          Pc.delete(b.pointerId);
      }
    }
    function Tc(a, b, c, d, e, f) {
      if (null === a || a.nativeEvent !== f) return a = { blockedOn: b, domEventName: c, eventSystemFlags: d, nativeEvent: f, targetContainers: [e] }, null !== b && (b = Cb(b), null !== b && Fc(b)), a;
      a.eventSystemFlags |= d;
      b = a.targetContainers;
      null !== e && -1 === b.indexOf(e) && b.push(e);
      return a;
    }
    function Uc(a, b, c, d, e) {
      switch (b) {
        case "focusin":
          return Lc = Tc(Lc, a, b, c, d, e), true;
        case "dragenter":
          return Mc = Tc(Mc, a, b, c, d, e), true;
        case "mouseover":
          return Nc = Tc(Nc, a, b, c, d, e), true;
        case "pointerover":
          var f = e.pointerId;
          Oc.set(f, Tc(Oc.get(f) || null, a, b, c, d, e));
          return true;
        case "gotpointercapture":
          return f = e.pointerId, Pc.set(f, Tc(Pc.get(f) || null, a, b, c, d, e)), true;
      }
      return false;
    }
    function Vc(a) {
      var b = Wc(a.target);
      if (null !== b) {
        var c = Vb(b);
        if (null !== c) {
          if (b = c.tag, 13 === b) {
            if (b = Wb(c), null !== b) {
              a.blockedOn = b;
              Ic(a.priority, function() {
                Gc(c);
              });
              return;
            }
          } else if (3 === b && c.stateNode.current.memoizedState.isDehydrated) {
            a.blockedOn = 3 === c.tag ? c.stateNode.containerInfo : null;
            return;
          }
        }
      }
      a.blockedOn = null;
    }
    function Xc(a) {
      if (null !== a.blockedOn) return false;
      for (var b = a.targetContainers; 0 < b.length; ) {
        var c = Yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
        if (null === c) {
          c = a.nativeEvent;
          var d = new c.constructor(c.type, c);
          wb = d;
          c.target.dispatchEvent(d);
          wb = null;
        } else return b = Cb(c), null !== b && Fc(b), a.blockedOn = c, false;
        b.shift();
      }
      return true;
    }
    function Zc(a, b, c) {
      Xc(a) && c.delete(b);
    }
    function $c() {
      Jc = false;
      null !== Lc && Xc(Lc) && (Lc = null);
      null !== Mc && Xc(Mc) && (Mc = null);
      null !== Nc && Xc(Nc) && (Nc = null);
      Oc.forEach(Zc);
      Pc.forEach(Zc);
    }
    function ad(a, b) {
      a.blockedOn === b && (a.blockedOn = null, Jc || (Jc = true, ca.unstable_scheduleCallback(ca.unstable_NormalPriority, $c)));
    }
    function bd(a) {
      function b(b2) {
        return ad(b2, a);
      }
      if (0 < Kc.length) {
        ad(Kc[0], a);
        for (var c = 1; c < Kc.length; c++) {
          var d = Kc[c];
          d.blockedOn === a && (d.blockedOn = null);
        }
      }
      null !== Lc && ad(Lc, a);
      null !== Mc && ad(Mc, a);
      null !== Nc && ad(Nc, a);
      Oc.forEach(b);
      Pc.forEach(b);
      for (c = 0; c < Qc.length; c++) d = Qc[c], d.blockedOn === a && (d.blockedOn = null);
      for (; 0 < Qc.length && (c = Qc[0], null === c.blockedOn); ) Vc(c), null === c.blockedOn && Qc.shift();
    }
    var cd = ua.ReactCurrentBatchConfig, dd = true;
    function ed(a, b, c, d) {
      var e = C, f = cd.transition;
      cd.transition = null;
      try {
        C = 1, fd(a, b, c, d);
      } finally {
        C = e, cd.transition = f;
      }
    }
    function gd(a, b, c, d) {
      var e = C, f = cd.transition;
      cd.transition = null;
      try {
        C = 4, fd(a, b, c, d);
      } finally {
        C = e, cd.transition = f;
      }
    }
    function fd(a, b, c, d) {
      if (dd) {
        var e = Yc(a, b, c, d);
        if (null === e) hd(a, b, d, id, c), Sc(a, d);
        else if (Uc(e, a, b, c, d)) d.stopPropagation();
        else if (Sc(a, d), b & 4 && -1 < Rc.indexOf(a)) {
          for (; null !== e; ) {
            var f = Cb(e);
            null !== f && Ec(f);
            f = Yc(a, b, c, d);
            null === f && hd(a, b, d, id, c);
            if (f === e) break;
            e = f;
          }
          null !== e && d.stopPropagation();
        } else hd(a, b, d, null, c);
      }
    }
    var id = null;
    function Yc(a, b, c, d) {
      id = null;
      a = xb(d);
      a = Wc(a);
      if (null !== a) if (b = Vb(a), null === b) a = null;
      else if (c = b.tag, 13 === c) {
        a = Wb(b);
        if (null !== a) return a;
        a = null;
      } else if (3 === c) {
        if (b.stateNode.current.memoizedState.isDehydrated) return 3 === b.tag ? b.stateNode.containerInfo : null;
        a = null;
      } else b !== a && (a = null);
      id = a;
      return null;
    }
    function jd(a) {
      switch (a) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
          return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
          return 4;
        case "message":
          switch (ec()) {
            case fc:
              return 1;
            case gc:
              return 4;
            case hc:
            case ic:
              return 16;
            case jc:
              return 536870912;
            default:
              return 16;
          }
        default:
          return 16;
      }
    }
    var kd = null, ld = null, md = null;
    function nd() {
      if (md) return md;
      var a, b = ld, c = b.length, d, e = "value" in kd ? kd.value : kd.textContent, f = e.length;
      for (a = 0; a < c && b[a] === e[a]; a++) ;
      var g = c - a;
      for (d = 1; d <= g && b[c - d] === e[f - d]; d++) ;
      return md = e.slice(a, 1 < d ? 1 - d : void 0);
    }
    function od(a) {
      var b = a.keyCode;
      "charCode" in a ? (a = a.charCode, 0 === a && 13 === b && (a = 13)) : a = b;
      10 === a && (a = 13);
      return 32 <= a || 13 === a ? a : 0;
    }
    function pd() {
      return true;
    }
    function qd() {
      return false;
    }
    function rd(a) {
      function b(b2, d, e, f, g) {
        this._reactName = b2;
        this._targetInst = e;
        this.type = d;
        this.nativeEvent = f;
        this.target = g;
        this.currentTarget = null;
        for (var c in a) a.hasOwnProperty(c) && (b2 = a[c], this[c] = b2 ? b2(f) : f[c]);
        this.isDefaultPrevented = (null != f.defaultPrevented ? f.defaultPrevented : false === f.returnValue) ? pd : qd;
        this.isPropagationStopped = qd;
        return this;
      }
      A(b.prototype, { preventDefault: function() {
        this.defaultPrevented = true;
        var a2 = this.nativeEvent;
        a2 && (a2.preventDefault ? a2.preventDefault() : "unknown" !== typeof a2.returnValue && (a2.returnValue = false), this.isDefaultPrevented = pd);
      }, stopPropagation: function() {
        var a2 = this.nativeEvent;
        a2 && (a2.stopPropagation ? a2.stopPropagation() : "unknown" !== typeof a2.cancelBubble && (a2.cancelBubble = true), this.isPropagationStopped = pd);
      }, persist: function() {
      }, isPersistent: pd });
      return b;
    }
    var sd = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
      return a.timeStamp || Date.now();
    }, defaultPrevented: 0, isTrusted: 0 }, td = rd(sd), ud = A({}, sd, { view: 0, detail: 0 }), vd = rd(ud), wd, xd, yd, Ad = A({}, ud, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: zd, button: 0, buttons: 0, relatedTarget: function(a) {
      return void 0 === a.relatedTarget ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
    }, movementX: function(a) {
      if ("movementX" in a) return a.movementX;
      a !== yd && (yd && "mousemove" === a.type ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
      return wd;
    }, movementY: function(a) {
      return "movementY" in a ? a.movementY : xd;
    } }), Bd = rd(Ad), Cd = A({}, Ad, { dataTransfer: 0 }), Dd = rd(Cd), Ed = A({}, ud, { relatedTarget: 0 }), Fd = rd(Ed), Gd = A({}, sd, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), Hd = rd(Gd), Id = A({}, sd, { clipboardData: function(a) {
      return "clipboardData" in a ? a.clipboardData : window.clipboardData;
    } }), Jd = rd(Id), Kd = A({}, sd, { data: 0 }), Ld = rd(Kd), Md = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified"
    }, Nd = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta"
    }, Od = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
    function Pd(a) {
      var b = this.nativeEvent;
      return b.getModifierState ? b.getModifierState(a) : (a = Od[a]) ? !!b[a] : false;
    }
    function zd() {
      return Pd;
    }
    var Qd = A({}, ud, { key: function(a) {
      if (a.key) {
        var b = Md[a.key] || a.key;
        if ("Unidentified" !== b) return b;
      }
      return "keypress" === a.type ? (a = od(a), 13 === a ? "Enter" : String.fromCharCode(a)) : "keydown" === a.type || "keyup" === a.type ? Nd[a.keyCode] || "Unidentified" : "";
    }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: zd, charCode: function(a) {
      return "keypress" === a.type ? od(a) : 0;
    }, keyCode: function(a) {
      return "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
    }, which: function(a) {
      return "keypress" === a.type ? od(a) : "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
    } }), Rd = rd(Qd), Sd = A({}, Ad, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), Td = rd(Sd), Ud = A({}, ud, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: zd }), Vd = rd(Ud), Wd = A({}, sd, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), Xd = rd(Wd), Yd = A({}, Ad, {
      deltaX: function(a) {
        return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
      },
      deltaY: function(a) {
        return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
      },
      deltaZ: 0,
      deltaMode: 0
    }), Zd = rd(Yd), $d = [9, 13, 27, 32], ae = ia && "CompositionEvent" in window, be = null;
    ia && "documentMode" in document && (be = document.documentMode);
    var ce = ia && "TextEvent" in window && !be, de = ia && (!ae || be && 8 < be && 11 >= be), ee = String.fromCharCode(32), fe = false;
    function ge(a, b) {
      switch (a) {
        case "keyup":
          return -1 !== $d.indexOf(b.keyCode);
        case "keydown":
          return 229 !== b.keyCode;
        case "keypress":
        case "mousedown":
        case "focusout":
          return true;
        default:
          return false;
      }
    }
    function he(a) {
      a = a.detail;
      return "object" === typeof a && "data" in a ? a.data : null;
    }
    var ie = false;
    function je(a, b) {
      switch (a) {
        case "compositionend":
          return he(b);
        case "keypress":
          if (32 !== b.which) return null;
          fe = true;
          return ee;
        case "textInput":
          return a = b.data, a === ee && fe ? null : a;
        default:
          return null;
      }
    }
    function ke(a, b) {
      if (ie) return "compositionend" === a || !ae && ge(a, b) ? (a = nd(), md = ld = kd = null, ie = false, a) : null;
      switch (a) {
        case "paste":
          return null;
        case "keypress":
          if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
            if (b.char && 1 < b.char.length) return b.char;
            if (b.which) return String.fromCharCode(b.which);
          }
          return null;
        case "compositionend":
          return de && "ko" !== b.locale ? null : b.data;
        default:
          return null;
      }
    }
    var le = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
    function me(a) {
      var b = a && a.nodeName && a.nodeName.toLowerCase();
      return "input" === b ? !!le[a.type] : "textarea" === b ? true : false;
    }
    function ne(a, b, c, d) {
      Eb(d);
      b = oe(b, "onChange");
      0 < b.length && (c = new td("onChange", "change", null, c, d), a.push({ event: c, listeners: b }));
    }
    var pe = null, qe = null;
    function re(a) {
      se(a, 0);
    }
    function te(a) {
      var b = ue(a);
      if (Wa(b)) return a;
    }
    function ve(a, b) {
      if ("change" === a) return b;
    }
    var we = false;
    if (ia) {
      var xe;
      if (ia) {
        var ye = "oninput" in document;
        if (!ye) {
          var ze = document.createElement("div");
          ze.setAttribute("oninput", "return;");
          ye = "function" === typeof ze.oninput;
        }
        xe = ye;
      } else xe = false;
      we = xe && (!document.documentMode || 9 < document.documentMode);
    }
    function Ae() {
      pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
    }
    function Be(a) {
      if ("value" === a.propertyName && te(qe)) {
        var b = [];
        ne(b, qe, a, xb(a));
        Jb(re, b);
      }
    }
    function Ce(a, b, c) {
      "focusin" === a ? (Ae(), pe = b, qe = c, pe.attachEvent("onpropertychange", Be)) : "focusout" === a && Ae();
    }
    function De(a) {
      if ("selectionchange" === a || "keyup" === a || "keydown" === a) return te(qe);
    }
    function Ee(a, b) {
      if ("click" === a) return te(b);
    }
    function Fe(a, b) {
      if ("input" === a || "change" === a) return te(b);
    }
    function Ge(a, b) {
      return a === b && (0 !== a || 1 / a === 1 / b) || a !== a && b !== b;
    }
    var He = "function" === typeof Object.is ? Object.is : Ge;
    function Ie(a, b) {
      if (He(a, b)) return true;
      if ("object" !== typeof a || null === a || "object" !== typeof b || null === b) return false;
      var c = Object.keys(a), d = Object.keys(b);
      if (c.length !== d.length) return false;
      for (d = 0; d < c.length; d++) {
        var e = c[d];
        if (!ja.call(b, e) || !He(a[e], b[e])) return false;
      }
      return true;
    }
    function Je(a) {
      for (; a && a.firstChild; ) a = a.firstChild;
      return a;
    }
    function Ke(a, b) {
      var c = Je(a);
      a = 0;
      for (var d; c; ) {
        if (3 === c.nodeType) {
          d = a + c.textContent.length;
          if (a <= b && d >= b) return { node: c, offset: b - a };
          a = d;
        }
        a: {
          for (; c; ) {
            if (c.nextSibling) {
              c = c.nextSibling;
              break a;
            }
            c = c.parentNode;
          }
          c = void 0;
        }
        c = Je(c);
      }
    }
    function Le(a, b) {
      return a && b ? a === b ? true : a && 3 === a.nodeType ? false : b && 3 === b.nodeType ? Le(a, b.parentNode) : "contains" in a ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : false : false;
    }
    function Me() {
      for (var a = window, b = Xa(); b instanceof a.HTMLIFrameElement; ) {
        try {
          var c = "string" === typeof b.contentWindow.location.href;
        } catch (d) {
          c = false;
        }
        if (c) a = b.contentWindow;
        else break;
        b = Xa(a.document);
      }
      return b;
    }
    function Ne(a) {
      var b = a && a.nodeName && a.nodeName.toLowerCase();
      return b && ("input" === b && ("text" === a.type || "search" === a.type || "tel" === a.type || "url" === a.type || "password" === a.type) || "textarea" === b || "true" === a.contentEditable);
    }
    function Oe(a) {
      var b = Me(), c = a.focusedElem, d = a.selectionRange;
      if (b !== c && c && c.ownerDocument && Le(c.ownerDocument.documentElement, c)) {
        if (null !== d && Ne(c)) {
          if (b = d.start, a = d.end, void 0 === a && (a = b), "selectionStart" in c) c.selectionStart = b, c.selectionEnd = Math.min(a, c.value.length);
          else if (a = (b = c.ownerDocument || document) && b.defaultView || window, a.getSelection) {
            a = a.getSelection();
            var e = c.textContent.length, f = Math.min(d.start, e);
            d = void 0 === d.end ? f : Math.min(d.end, e);
            !a.extend && f > d && (e = d, d = f, f = e);
            e = Ke(c, f);
            var g = Ke(
              c,
              d
            );
            e && g && (1 !== a.rangeCount || a.anchorNode !== e.node || a.anchorOffset !== e.offset || a.focusNode !== g.node || a.focusOffset !== g.offset) && (b = b.createRange(), b.setStart(e.node, e.offset), a.removeAllRanges(), f > d ? (a.addRange(b), a.extend(g.node, g.offset)) : (b.setEnd(g.node, g.offset), a.addRange(b)));
          }
        }
        b = [];
        for (a = c; a = a.parentNode; ) 1 === a.nodeType && b.push({ element: a, left: a.scrollLeft, top: a.scrollTop });
        "function" === typeof c.focus && c.focus();
        for (c = 0; c < b.length; c++) a = b[c], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
      }
    }
    var Pe = ia && "documentMode" in document && 11 >= document.documentMode, Qe = null, Re = null, Se = null, Te = false;
    function Ue(a, b, c) {
      var d = c.window === c ? c.document : 9 === c.nodeType ? c : c.ownerDocument;
      Te || null == Qe || Qe !== Xa(d) || (d = Qe, "selectionStart" in d && Ne(d) ? d = { start: d.selectionStart, end: d.selectionEnd } : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = { anchorNode: d.anchorNode, anchorOffset: d.anchorOffset, focusNode: d.focusNode, focusOffset: d.focusOffset }), Se && Ie(Se, d) || (Se = d, d = oe(Re, "onSelect"), 0 < d.length && (b = new td("onSelect", "select", null, b, c), a.push({ event: b, listeners: d }), b.target = Qe)));
    }
    function Ve(a, b) {
      var c = {};
      c[a.toLowerCase()] = b.toLowerCase();
      c["Webkit" + a] = "webkit" + b;
      c["Moz" + a] = "moz" + b;
      return c;
    }
    var We = { animationend: Ve("Animation", "AnimationEnd"), animationiteration: Ve("Animation", "AnimationIteration"), animationstart: Ve("Animation", "AnimationStart"), transitionend: Ve("Transition", "TransitionEnd") }, Xe = {}, Ye = {};
    ia && (Ye = document.createElement("div").style, "AnimationEvent" in window || (delete We.animationend.animation, delete We.animationiteration.animation, delete We.animationstart.animation), "TransitionEvent" in window || delete We.transitionend.transition);
    function Ze(a) {
      if (Xe[a]) return Xe[a];
      if (!We[a]) return a;
      var b = We[a], c;
      for (c in b) if (b.hasOwnProperty(c) && c in Ye) return Xe[a] = b[c];
      return a;
    }
    var $e = Ze("animationend"), af = Ze("animationiteration"), bf = Ze("animationstart"), cf = Ze("transitionend"), df = /* @__PURE__ */ new Map(), ef = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    function ff(a, b) {
      df.set(a, b);
      fa(b, [a]);
    }
    for (var gf = 0; gf < ef.length; gf++) {
      var hf = ef[gf], jf = hf.toLowerCase(), kf = hf[0].toUpperCase() + hf.slice(1);
      ff(jf, "on" + kf);
    }
    ff($e, "onAnimationEnd");
    ff(af, "onAnimationIteration");
    ff(bf, "onAnimationStart");
    ff("dblclick", "onDoubleClick");
    ff("focusin", "onFocus");
    ff("focusout", "onBlur");
    ff(cf, "onTransitionEnd");
    ha("onMouseEnter", ["mouseout", "mouseover"]);
    ha("onMouseLeave", ["mouseout", "mouseover"]);
    ha("onPointerEnter", ["pointerout", "pointerover"]);
    ha("onPointerLeave", ["pointerout", "pointerover"]);
    fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
    fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
    fa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
    fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
    fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
    fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var lf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), mf = new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
    function nf(a, b, c) {
      var d = a.type || "unknown-event";
      a.currentTarget = c;
      Ub(d, b, void 0, a);
      a.currentTarget = null;
    }
    function se(a, b) {
      b = 0 !== (b & 4);
      for (var c = 0; c < a.length; c++) {
        var d = a[c], e = d.event;
        d = d.listeners;
        a: {
          var f = void 0;
          if (b) for (var g = d.length - 1; 0 <= g; g--) {
            var h = d[g], k = h.instance, l = h.currentTarget;
            h = h.listener;
            if (k !== f && e.isPropagationStopped()) break a;
            nf(e, h, l);
            f = k;
          }
          else for (g = 0; g < d.length; g++) {
            h = d[g];
            k = h.instance;
            l = h.currentTarget;
            h = h.listener;
            if (k !== f && e.isPropagationStopped()) break a;
            nf(e, h, l);
            f = k;
          }
        }
      }
      if (Qb) throw a = Rb, Qb = false, Rb = null, a;
    }
    function D(a, b) {
      var c = b[of];
      void 0 === c && (c = b[of] = /* @__PURE__ */ new Set());
      var d = a + "__bubble";
      c.has(d) || (pf(b, a, 2, false), c.add(d));
    }
    function qf(a, b, c) {
      var d = 0;
      b && (d |= 4);
      pf(c, a, d, b);
    }
    var rf = "_reactListening" + Math.random().toString(36).slice(2);
    function sf(a) {
      if (!a[rf]) {
        a[rf] = true;
        da.forEach(function(b2) {
          "selectionchange" !== b2 && (mf.has(b2) || qf(b2, false, a), qf(b2, true, a));
        });
        var b = 9 === a.nodeType ? a : a.ownerDocument;
        null === b || b[rf] || (b[rf] = true, qf("selectionchange", false, b));
      }
    }
    function pf(a, b, c, d) {
      switch (jd(b)) {
        case 1:
          var e = ed;
          break;
        case 4:
          e = gd;
          break;
        default:
          e = fd;
      }
      c = e.bind(null, b, c, a);
      e = void 0;
      !Lb || "touchstart" !== b && "touchmove" !== b && "wheel" !== b || (e = true);
      d ? void 0 !== e ? a.addEventListener(b, c, { capture: true, passive: e }) : a.addEventListener(b, c, true) : void 0 !== e ? a.addEventListener(b, c, { passive: e }) : a.addEventListener(b, c, false);
    }
    function hd(a, b, c, d, e) {
      var f = d;
      if (0 === (b & 1) && 0 === (b & 2) && null !== d) a: for (; ; ) {
        if (null === d) return;
        var g = d.tag;
        if (3 === g || 4 === g) {
          var h = d.stateNode.containerInfo;
          if (h === e || 8 === h.nodeType && h.parentNode === e) break;
          if (4 === g) for (g = d.return; null !== g; ) {
            var k = g.tag;
            if (3 === k || 4 === k) {
              if (k = g.stateNode.containerInfo, k === e || 8 === k.nodeType && k.parentNode === e) return;
            }
            g = g.return;
          }
          for (; null !== h; ) {
            g = Wc(h);
            if (null === g) return;
            k = g.tag;
            if (5 === k || 6 === k) {
              d = f = g;
              continue a;
            }
            h = h.parentNode;
          }
        }
        d = d.return;
      }
      Jb(function() {
        var d2 = f, e2 = xb(c), g2 = [];
        a: {
          var h2 = df.get(a);
          if (void 0 !== h2) {
            var k2 = td, n = a;
            switch (a) {
              case "keypress":
                if (0 === od(c)) break a;
              case "keydown":
              case "keyup":
                k2 = Rd;
                break;
              case "focusin":
                n = "focus";
                k2 = Fd;
                break;
              case "focusout":
                n = "blur";
                k2 = Fd;
                break;
              case "beforeblur":
              case "afterblur":
                k2 = Fd;
                break;
              case "click":
                if (2 === c.button) break a;
              case "auxclick":
              case "dblclick":
              case "mousedown":
              case "mousemove":
              case "mouseup":
              case "mouseout":
              case "mouseover":
              case "contextmenu":
                k2 = Bd;
                break;
              case "drag":
              case "dragend":
              case "dragenter":
              case "dragexit":
              case "dragleave":
              case "dragover":
              case "dragstart":
              case "drop":
                k2 = Dd;
                break;
              case "touchcancel":
              case "touchend":
              case "touchmove":
              case "touchstart":
                k2 = Vd;
                break;
              case $e:
              case af:
              case bf:
                k2 = Hd;
                break;
              case cf:
                k2 = Xd;
                break;
              case "scroll":
                k2 = vd;
                break;
              case "wheel":
                k2 = Zd;
                break;
              case "copy":
              case "cut":
              case "paste":
                k2 = Jd;
                break;
              case "gotpointercapture":
              case "lostpointercapture":
              case "pointercancel":
              case "pointerdown":
              case "pointermove":
              case "pointerout":
              case "pointerover":
              case "pointerup":
                k2 = Td;
            }
            var t2 = 0 !== (b & 4), J = !t2 && "scroll" === a, x = t2 ? null !== h2 ? h2 + "Capture" : null : h2;
            t2 = [];
            for (var w = d2, u; null !== w; ) {
              u = w;
              var F = u.stateNode;
              5 === u.tag && null !== F && (u = F, null !== x && (F = Kb(w, x), null != F && t2.push(tf(w, F, u))));
              if (J) break;
              w = w.return;
            }
            0 < t2.length && (h2 = new k2(h2, n, null, c, e2), g2.push({ event: h2, listeners: t2 }));
          }
        }
        if (0 === (b & 7)) {
          a: {
            h2 = "mouseover" === a || "pointerover" === a;
            k2 = "mouseout" === a || "pointerout" === a;
            if (h2 && c !== wb && (n = c.relatedTarget || c.fromElement) && (Wc(n) || n[uf])) break a;
            if (k2 || h2) {
              h2 = e2.window === e2 ? e2 : (h2 = e2.ownerDocument) ? h2.defaultView || h2.parentWindow : window;
              if (k2) {
                if (n = c.relatedTarget || c.toElement, k2 = d2, n = n ? Wc(n) : null, null !== n && (J = Vb(n), n !== J || 5 !== n.tag && 6 !== n.tag)) n = null;
              } else k2 = null, n = d2;
              if (k2 !== n) {
                t2 = Bd;
                F = "onMouseLeave";
                x = "onMouseEnter";
                w = "mouse";
                if ("pointerout" === a || "pointerover" === a) t2 = Td, F = "onPointerLeave", x = "onPointerEnter", w = "pointer";
                J = null == k2 ? h2 : ue(k2);
                u = null == n ? h2 : ue(n);
                h2 = new t2(F, w + "leave", k2, c, e2);
                h2.target = J;
                h2.relatedTarget = u;
                F = null;
                Wc(e2) === d2 && (t2 = new t2(x, w + "enter", n, c, e2), t2.target = u, t2.relatedTarget = J, F = t2);
                J = F;
                if (k2 && n) b: {
                  t2 = k2;
                  x = n;
                  w = 0;
                  for (u = t2; u; u = vf(u)) w++;
                  u = 0;
                  for (F = x; F; F = vf(F)) u++;
                  for (; 0 < w - u; ) t2 = vf(t2), w--;
                  for (; 0 < u - w; ) x = vf(x), u--;
                  for (; w--; ) {
                    if (t2 === x || null !== x && t2 === x.alternate) break b;
                    t2 = vf(t2);
                    x = vf(x);
                  }
                  t2 = null;
                }
                else t2 = null;
                null !== k2 && wf(g2, h2, k2, t2, false);
                null !== n && null !== J && wf(g2, J, n, t2, true);
              }
            }
          }
          a: {
            h2 = d2 ? ue(d2) : window;
            k2 = h2.nodeName && h2.nodeName.toLowerCase();
            if ("select" === k2 || "input" === k2 && "file" === h2.type) var na = ve;
            else if (me(h2)) if (we) na = Fe;
            else {
              na = De;
              var xa = Ce;
            }
            else (k2 = h2.nodeName) && "input" === k2.toLowerCase() && ("checkbox" === h2.type || "radio" === h2.type) && (na = Ee);
            if (na && (na = na(a, d2))) {
              ne(g2, na, c, e2);
              break a;
            }
            xa && xa(a, h2, d2);
            "focusout" === a && (xa = h2._wrapperState) && xa.controlled && "number" === h2.type && cb(h2, "number", h2.value);
          }
          xa = d2 ? ue(d2) : window;
          switch (a) {
            case "focusin":
              if (me(xa) || "true" === xa.contentEditable) Qe = xa, Re = d2, Se = null;
              break;
            case "focusout":
              Se = Re = Qe = null;
              break;
            case "mousedown":
              Te = true;
              break;
            case "contextmenu":
            case "mouseup":
            case "dragend":
              Te = false;
              Ue(g2, c, e2);
              break;
            case "selectionchange":
              if (Pe) break;
            case "keydown":
            case "keyup":
              Ue(g2, c, e2);
          }
          var $a;
          if (ae) b: {
            switch (a) {
              case "compositionstart":
                var ba = "onCompositionStart";
                break b;
              case "compositionend":
                ba = "onCompositionEnd";
                break b;
              case "compositionupdate":
                ba = "onCompositionUpdate";
                break b;
            }
            ba = void 0;
          }
          else ie ? ge(a, c) && (ba = "onCompositionEnd") : "keydown" === a && 229 === c.keyCode && (ba = "onCompositionStart");
          ba && (de && "ko" !== c.locale && (ie || "onCompositionStart" !== ba ? "onCompositionEnd" === ba && ie && ($a = nd()) : (kd = e2, ld = "value" in kd ? kd.value : kd.textContent, ie = true)), xa = oe(d2, ba), 0 < xa.length && (ba = new Ld(ba, a, null, c, e2), g2.push({ event: ba, listeners: xa }), $a ? ba.data = $a : ($a = he(c), null !== $a && (ba.data = $a))));
          if ($a = ce ? je(a, c) : ke(a, c)) d2 = oe(d2, "onBeforeInput"), 0 < d2.length && (e2 = new Ld("onBeforeInput", "beforeinput", null, c, e2), g2.push({ event: e2, listeners: d2 }), e2.data = $a);
        }
        se(g2, b);
      });
    }
    function tf(a, b, c) {
      return { instance: a, listener: b, currentTarget: c };
    }
    function oe(a, b) {
      for (var c = b + "Capture", d = []; null !== a; ) {
        var e = a, f = e.stateNode;
        5 === e.tag && null !== f && (e = f, f = Kb(a, c), null != f && d.unshift(tf(a, f, e)), f = Kb(a, b), null != f && d.push(tf(a, f, e)));
        a = a.return;
      }
      return d;
    }
    function vf(a) {
      if (null === a) return null;
      do
        a = a.return;
      while (a && 5 !== a.tag);
      return a ? a : null;
    }
    function wf(a, b, c, d, e) {
      for (var f = b._reactName, g = []; null !== c && c !== d; ) {
        var h = c, k = h.alternate, l = h.stateNode;
        if (null !== k && k === d) break;
        5 === h.tag && null !== l && (h = l, e ? (k = Kb(c, f), null != k && g.unshift(tf(c, k, h))) : e || (k = Kb(c, f), null != k && g.push(tf(c, k, h))));
        c = c.return;
      }
      0 !== g.length && a.push({ event: b, listeners: g });
    }
    var xf = /\r\n?/g, yf = /\u0000|\uFFFD/g;
    function zf(a) {
      return ("string" === typeof a ? a : "" + a).replace(xf, "\n").replace(yf, "");
    }
    function Af(a, b, c) {
      b = zf(b);
      if (zf(a) !== b && c) throw Error(p(425));
    }
    function Bf() {
    }
    var Cf = null, Df = null;
    function Ef(a, b) {
      return "textarea" === a || "noscript" === a || "string" === typeof b.children || "number" === typeof b.children || "object" === typeof b.dangerouslySetInnerHTML && null !== b.dangerouslySetInnerHTML && null != b.dangerouslySetInnerHTML.__html;
    }
    var Ff = "function" === typeof setTimeout ? setTimeout : void 0, Gf = "function" === typeof clearTimeout ? clearTimeout : void 0, Hf = "function" === typeof Promise ? Promise : void 0, Jf = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof Hf ? function(a) {
      return Hf.resolve(null).then(a).catch(If);
    } : Ff;
    function If(a) {
      setTimeout(function() {
        throw a;
      });
    }
    function Kf(a, b) {
      var c = b, d = 0;
      do {
        var e = c.nextSibling;
        a.removeChild(c);
        if (e && 8 === e.nodeType) if (c = e.data, "/$" === c) {
          if (0 === d) {
            a.removeChild(e);
            bd(b);
            return;
          }
          d--;
        } else "$" !== c && "$?" !== c && "$!" !== c || d++;
        c = e;
      } while (c);
      bd(b);
    }
    function Lf(a) {
      for (; null != a; a = a.nextSibling) {
        var b = a.nodeType;
        if (1 === b || 3 === b) break;
        if (8 === b) {
          b = a.data;
          if ("$" === b || "$!" === b || "$?" === b) break;
          if ("/$" === b) return null;
        }
      }
      return a;
    }
    function Mf(a) {
      a = a.previousSibling;
      for (var b = 0; a; ) {
        if (8 === a.nodeType) {
          var c = a.data;
          if ("$" === c || "$!" === c || "$?" === c) {
            if (0 === b) return a;
            b--;
          } else "/$" === c && b++;
        }
        a = a.previousSibling;
      }
      return null;
    }
    var Nf = Math.random().toString(36).slice(2), Of = "__reactFiber$" + Nf, Pf = "__reactProps$" + Nf, uf = "__reactContainer$" + Nf, of = "__reactEvents$" + Nf, Qf = "__reactListeners$" + Nf, Rf = "__reactHandles$" + Nf;
    function Wc(a) {
      var b = a[Of];
      if (b) return b;
      for (var c = a.parentNode; c; ) {
        if (b = c[uf] || c[Of]) {
          c = b.alternate;
          if (null !== b.child || null !== c && null !== c.child) for (a = Mf(a); null !== a; ) {
            if (c = a[Of]) return c;
            a = Mf(a);
          }
          return b;
        }
        a = c;
        c = a.parentNode;
      }
      return null;
    }
    function Cb(a) {
      a = a[Of] || a[uf];
      return !a || 5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag ? null : a;
    }
    function ue(a) {
      if (5 === a.tag || 6 === a.tag) return a.stateNode;
      throw Error(p(33));
    }
    function Db(a) {
      return a[Pf] || null;
    }
    var Sf = [], Tf = -1;
    function Uf(a) {
      return { current: a };
    }
    function E(a) {
      0 > Tf || (a.current = Sf[Tf], Sf[Tf] = null, Tf--);
    }
    function G(a, b) {
      Tf++;
      Sf[Tf] = a.current;
      a.current = b;
    }
    var Vf = {}, H = Uf(Vf), Wf = Uf(false), Xf = Vf;
    function Yf(a, b) {
      var c = a.type.contextTypes;
      if (!c) return Vf;
      var d = a.stateNode;
      if (d && d.__reactInternalMemoizedUnmaskedChildContext === b) return d.__reactInternalMemoizedMaskedChildContext;
      var e = {}, f;
      for (f in c) e[f] = b[f];
      d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
      return e;
    }
    function Zf(a) {
      a = a.childContextTypes;
      return null !== a && void 0 !== a;
    }
    function $f() {
      E(Wf);
      E(H);
    }
    function ag(a, b, c) {
      if (H.current !== Vf) throw Error(p(168));
      G(H, b);
      G(Wf, c);
    }
    function bg(a, b, c) {
      var d = a.stateNode;
      b = b.childContextTypes;
      if ("function" !== typeof d.getChildContext) return c;
      d = d.getChildContext();
      for (var e in d) if (!(e in b)) throw Error(p(108, Ra(a) || "Unknown", e));
      return A({}, c, d);
    }
    function cg(a) {
      a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Vf;
      Xf = H.current;
      G(H, a);
      G(Wf, Wf.current);
      return true;
    }
    function dg(a, b, c) {
      var d = a.stateNode;
      if (!d) throw Error(p(169));
      c ? (a = bg(a, b, Xf), d.__reactInternalMemoizedMergedChildContext = a, E(Wf), E(H), G(H, a)) : E(Wf);
      G(Wf, c);
    }
    var eg = null, fg = false, gg = false;
    function hg(a) {
      null === eg ? eg = [a] : eg.push(a);
    }
    function ig(a) {
      fg = true;
      hg(a);
    }
    function jg() {
      if (!gg && null !== eg) {
        gg = true;
        var a = 0, b = C;
        try {
          var c = eg;
          for (C = 1; a < c.length; a++) {
            var d = c[a];
            do
              d = d(true);
            while (null !== d);
          }
          eg = null;
          fg = false;
        } catch (e) {
          throw null !== eg && (eg = eg.slice(a + 1)), ac(fc, jg), e;
        } finally {
          C = b, gg = false;
        }
      }
      return null;
    }
    var kg = [], lg = 0, mg = null, ng = 0, og = [], pg = 0, qg = null, rg = 1, sg = "";
    function tg(a, b) {
      kg[lg++] = ng;
      kg[lg++] = mg;
      mg = a;
      ng = b;
    }
    function ug(a, b, c) {
      og[pg++] = rg;
      og[pg++] = sg;
      og[pg++] = qg;
      qg = a;
      var d = rg;
      a = sg;
      var e = 32 - oc(d) - 1;
      d &= ~(1 << e);
      c += 1;
      var f = 32 - oc(b) + e;
      if (30 < f) {
        var g = e - e % 5;
        f = (d & (1 << g) - 1).toString(32);
        d >>= g;
        e -= g;
        rg = 1 << 32 - oc(b) + e | c << e | d;
        sg = f + a;
      } else rg = 1 << f | c << e | d, sg = a;
    }
    function vg(a) {
      null !== a.return && (tg(a, 1), ug(a, 1, 0));
    }
    function wg(a) {
      for (; a === mg; ) mg = kg[--lg], kg[lg] = null, ng = kg[--lg], kg[lg] = null;
      for (; a === qg; ) qg = og[--pg], og[pg] = null, sg = og[--pg], og[pg] = null, rg = og[--pg], og[pg] = null;
    }
    var xg = null, yg = null, I = false, zg = null;
    function Ag(a, b) {
      var c = Bg(5, null, null, 0);
      c.elementType = "DELETED";
      c.stateNode = b;
      c.return = a;
      b = a.deletions;
      null === b ? (a.deletions = [c], a.flags |= 16) : b.push(c);
    }
    function Cg(a, b) {
      switch (a.tag) {
        case 5:
          var c = a.type;
          b = 1 !== b.nodeType || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
          return null !== b ? (a.stateNode = b, xg = a, yg = Lf(b.firstChild), true) : false;
        case 6:
          return b = "" === a.pendingProps || 3 !== b.nodeType ? null : b, null !== b ? (a.stateNode = b, xg = a, yg = null, true) : false;
        case 13:
          return b = 8 !== b.nodeType ? null : b, null !== b ? (c = null !== qg ? { id: rg, overflow: sg } : null, a.memoizedState = { dehydrated: b, treeContext: c, retryLane: 1073741824 }, c = Bg(18, null, null, 0), c.stateNode = b, c.return = a, a.child = c, xg = a, yg = null, true) : false;
        default:
          return false;
      }
    }
    function Dg(a) {
      return 0 !== (a.mode & 1) && 0 === (a.flags & 128);
    }
    function Eg(a) {
      if (I) {
        var b = yg;
        if (b) {
          var c = b;
          if (!Cg(a, b)) {
            if (Dg(a)) throw Error(p(418));
            b = Lf(c.nextSibling);
            var d = xg;
            b && Cg(a, b) ? Ag(d, c) : (a.flags = a.flags & -4097 | 2, I = false, xg = a);
          }
        } else {
          if (Dg(a)) throw Error(p(418));
          a.flags = a.flags & -4097 | 2;
          I = false;
          xg = a;
        }
      }
    }
    function Fg(a) {
      for (a = a.return; null !== a && 5 !== a.tag && 3 !== a.tag && 13 !== a.tag; ) a = a.return;
      xg = a;
    }
    function Gg(a) {
      if (a !== xg) return false;
      if (!I) return Fg(a), I = true, false;
      var b;
      (b = 3 !== a.tag) && !(b = 5 !== a.tag) && (b = a.type, b = "head" !== b && "body" !== b && !Ef(a.type, a.memoizedProps));
      if (b && (b = yg)) {
        if (Dg(a)) throw Hg(), Error(p(418));
        for (; b; ) Ag(a, b), b = Lf(b.nextSibling);
      }
      Fg(a);
      if (13 === a.tag) {
        a = a.memoizedState;
        a = null !== a ? a.dehydrated : null;
        if (!a) throw Error(p(317));
        a: {
          a = a.nextSibling;
          for (b = 0; a; ) {
            if (8 === a.nodeType) {
              var c = a.data;
              if ("/$" === c) {
                if (0 === b) {
                  yg = Lf(a.nextSibling);
                  break a;
                }
                b--;
              } else "$" !== c && "$!" !== c && "$?" !== c || b++;
            }
            a = a.nextSibling;
          }
          yg = null;
        }
      } else yg = xg ? Lf(a.stateNode.nextSibling) : null;
      return true;
    }
    function Hg() {
      for (var a = yg; a; ) a = Lf(a.nextSibling);
    }
    function Ig() {
      yg = xg = null;
      I = false;
    }
    function Jg(a) {
      null === zg ? zg = [a] : zg.push(a);
    }
    var Kg = ua.ReactCurrentBatchConfig;
    function Lg(a, b, c) {
      a = c.ref;
      if (null !== a && "function" !== typeof a && "object" !== typeof a) {
        if (c._owner) {
          c = c._owner;
          if (c) {
            if (1 !== c.tag) throw Error(p(309));
            var d = c.stateNode;
          }
          if (!d) throw Error(p(147, a));
          var e = d, f = "" + a;
          if (null !== b && null !== b.ref && "function" === typeof b.ref && b.ref._stringRef === f) return b.ref;
          b = function(a2) {
            var b2 = e.refs;
            null === a2 ? delete b2[f] : b2[f] = a2;
          };
          b._stringRef = f;
          return b;
        }
        if ("string" !== typeof a) throw Error(p(284));
        if (!c._owner) throw Error(p(290, a));
      }
      return a;
    }
    function Mg(a, b) {
      a = Object.prototype.toString.call(b);
      throw Error(p(31, "[object Object]" === a ? "object with keys {" + Object.keys(b).join(", ") + "}" : a));
    }
    function Ng(a) {
      var b = a._init;
      return b(a._payload);
    }
    function Og(a) {
      function b(b2, c2) {
        if (a) {
          var d2 = b2.deletions;
          null === d2 ? (b2.deletions = [c2], b2.flags |= 16) : d2.push(c2);
        }
      }
      function c(c2, d2) {
        if (!a) return null;
        for (; null !== d2; ) b(c2, d2), d2 = d2.sibling;
        return null;
      }
      function d(a2, b2) {
        for (a2 = /* @__PURE__ */ new Map(); null !== b2; ) null !== b2.key ? a2.set(b2.key, b2) : a2.set(b2.index, b2), b2 = b2.sibling;
        return a2;
      }
      function e(a2, b2) {
        a2 = Pg(a2, b2);
        a2.index = 0;
        a2.sibling = null;
        return a2;
      }
      function f(b2, c2, d2) {
        b2.index = d2;
        if (!a) return b2.flags |= 1048576, c2;
        d2 = b2.alternate;
        if (null !== d2) return d2 = d2.index, d2 < c2 ? (b2.flags |= 2, c2) : d2;
        b2.flags |= 2;
        return c2;
      }
      function g(b2) {
        a && null === b2.alternate && (b2.flags |= 2);
        return b2;
      }
      function h(a2, b2, c2, d2) {
        if (null === b2 || 6 !== b2.tag) return b2 = Qg(c2, a2.mode, d2), b2.return = a2, b2;
        b2 = e(b2, c2);
        b2.return = a2;
        return b2;
      }
      function k(a2, b2, c2, d2) {
        var f2 = c2.type;
        if (f2 === ya) return m(a2, b2, c2.props.children, d2, c2.key);
        if (null !== b2 && (b2.elementType === f2 || "object" === typeof f2 && null !== f2 && f2.$$typeof === Ha && Ng(f2) === b2.type)) return d2 = e(b2, c2.props), d2.ref = Lg(a2, b2, c2), d2.return = a2, d2;
        d2 = Rg(c2.type, c2.key, c2.props, null, a2.mode, d2);
        d2.ref = Lg(a2, b2, c2);
        d2.return = a2;
        return d2;
      }
      function l(a2, b2, c2, d2) {
        if (null === b2 || 4 !== b2.tag || b2.stateNode.containerInfo !== c2.containerInfo || b2.stateNode.implementation !== c2.implementation) return b2 = Sg(c2, a2.mode, d2), b2.return = a2, b2;
        b2 = e(b2, c2.children || []);
        b2.return = a2;
        return b2;
      }
      function m(a2, b2, c2, d2, f2) {
        if (null === b2 || 7 !== b2.tag) return b2 = Tg(c2, a2.mode, d2, f2), b2.return = a2, b2;
        b2 = e(b2, c2);
        b2.return = a2;
        return b2;
      }
      function q(a2, b2, c2) {
        if ("string" === typeof b2 && "" !== b2 || "number" === typeof b2) return b2 = Qg("" + b2, a2.mode, c2), b2.return = a2, b2;
        if ("object" === typeof b2 && null !== b2) {
          switch (b2.$$typeof) {
            case va:
              return c2 = Rg(b2.type, b2.key, b2.props, null, a2.mode, c2), c2.ref = Lg(a2, null, b2), c2.return = a2, c2;
            case wa:
              return b2 = Sg(b2, a2.mode, c2), b2.return = a2, b2;
            case Ha:
              var d2 = b2._init;
              return q(a2, d2(b2._payload), c2);
          }
          if (eb(b2) || Ka(b2)) return b2 = Tg(b2, a2.mode, c2, null), b2.return = a2, b2;
          Mg(a2, b2);
        }
        return null;
      }
      function r(a2, b2, c2, d2) {
        var e2 = null !== b2 ? b2.key : null;
        if ("string" === typeof c2 && "" !== c2 || "number" === typeof c2) return null !== e2 ? null : h(a2, b2, "" + c2, d2);
        if ("object" === typeof c2 && null !== c2) {
          switch (c2.$$typeof) {
            case va:
              return c2.key === e2 ? k(a2, b2, c2, d2) : null;
            case wa:
              return c2.key === e2 ? l(a2, b2, c2, d2) : null;
            case Ha:
              return e2 = c2._init, r(
                a2,
                b2,
                e2(c2._payload),
                d2
              );
          }
          if (eb(c2) || Ka(c2)) return null !== e2 ? null : m(a2, b2, c2, d2, null);
          Mg(a2, c2);
        }
        return null;
      }
      function y(a2, b2, c2, d2, e2) {
        if ("string" === typeof d2 && "" !== d2 || "number" === typeof d2) return a2 = a2.get(c2) || null, h(b2, a2, "" + d2, e2);
        if ("object" === typeof d2 && null !== d2) {
          switch (d2.$$typeof) {
            case va:
              return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, k(b2, a2, d2, e2);
            case wa:
              return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, l(b2, a2, d2, e2);
            case Ha:
              var f2 = d2._init;
              return y(a2, b2, c2, f2(d2._payload), e2);
          }
          if (eb(d2) || Ka(d2)) return a2 = a2.get(c2) || null, m(b2, a2, d2, e2, null);
          Mg(b2, d2);
        }
        return null;
      }
      function n(e2, g2, h2, k2) {
        for (var l2 = null, m2 = null, u = g2, w = g2 = 0, x = null; null !== u && w < h2.length; w++) {
          u.index > w ? (x = u, u = null) : x = u.sibling;
          var n2 = r(e2, u, h2[w], k2);
          if (null === n2) {
            null === u && (u = x);
            break;
          }
          a && u && null === n2.alternate && b(e2, u);
          g2 = f(n2, g2, w);
          null === m2 ? l2 = n2 : m2.sibling = n2;
          m2 = n2;
          u = x;
        }
        if (w === h2.length) return c(e2, u), I && tg(e2, w), l2;
        if (null === u) {
          for (; w < h2.length; w++) u = q(e2, h2[w], k2), null !== u && (g2 = f(u, g2, w), null === m2 ? l2 = u : m2.sibling = u, m2 = u);
          I && tg(e2, w);
          return l2;
        }
        for (u = d(e2, u); w < h2.length; w++) x = y(u, e2, w, h2[w], k2), null !== x && (a && null !== x.alternate && u.delete(null === x.key ? w : x.key), g2 = f(x, g2, w), null === m2 ? l2 = x : m2.sibling = x, m2 = x);
        a && u.forEach(function(a2) {
          return b(e2, a2);
        });
        I && tg(e2, w);
        return l2;
      }
      function t2(e2, g2, h2, k2) {
        var l2 = Ka(h2);
        if ("function" !== typeof l2) throw Error(p(150));
        h2 = l2.call(h2);
        if (null == h2) throw Error(p(151));
        for (var u = l2 = null, m2 = g2, w = g2 = 0, x = null, n2 = h2.next(); null !== m2 && !n2.done; w++, n2 = h2.next()) {
          m2.index > w ? (x = m2, m2 = null) : x = m2.sibling;
          var t3 = r(e2, m2, n2.value, k2);
          if (null === t3) {
            null === m2 && (m2 = x);
            break;
          }
          a && m2 && null === t3.alternate && b(e2, m2);
          g2 = f(t3, g2, w);
          null === u ? l2 = t3 : u.sibling = t3;
          u = t3;
          m2 = x;
        }
        if (n2.done) return c(
          e2,
          m2
        ), I && tg(e2, w), l2;
        if (null === m2) {
          for (; !n2.done; w++, n2 = h2.next()) n2 = q(e2, n2.value, k2), null !== n2 && (g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
          I && tg(e2, w);
          return l2;
        }
        for (m2 = d(e2, m2); !n2.done; w++, n2 = h2.next()) n2 = y(m2, e2, w, n2.value, k2), null !== n2 && (a && null !== n2.alternate && m2.delete(null === n2.key ? w : n2.key), g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
        a && m2.forEach(function(a2) {
          return b(e2, a2);
        });
        I && tg(e2, w);
        return l2;
      }
      function J(a2, d2, f2, h2) {
        "object" === typeof f2 && null !== f2 && f2.type === ya && null === f2.key && (f2 = f2.props.children);
        if ("object" === typeof f2 && null !== f2) {
          switch (f2.$$typeof) {
            case va:
              a: {
                for (var k2 = f2.key, l2 = d2; null !== l2; ) {
                  if (l2.key === k2) {
                    k2 = f2.type;
                    if (k2 === ya) {
                      if (7 === l2.tag) {
                        c(a2, l2.sibling);
                        d2 = e(l2, f2.props.children);
                        d2.return = a2;
                        a2 = d2;
                        break a;
                      }
                    } else if (l2.elementType === k2 || "object" === typeof k2 && null !== k2 && k2.$$typeof === Ha && Ng(k2) === l2.type) {
                      c(a2, l2.sibling);
                      d2 = e(l2, f2.props);
                      d2.ref = Lg(a2, l2, f2);
                      d2.return = a2;
                      a2 = d2;
                      break a;
                    }
                    c(a2, l2);
                    break;
                  } else b(a2, l2);
                  l2 = l2.sibling;
                }
                f2.type === ya ? (d2 = Tg(f2.props.children, a2.mode, h2, f2.key), d2.return = a2, a2 = d2) : (h2 = Rg(f2.type, f2.key, f2.props, null, a2.mode, h2), h2.ref = Lg(a2, d2, f2), h2.return = a2, a2 = h2);
              }
              return g(a2);
            case wa:
              a: {
                for (l2 = f2.key; null !== d2; ) {
                  if (d2.key === l2) if (4 === d2.tag && d2.stateNode.containerInfo === f2.containerInfo && d2.stateNode.implementation === f2.implementation) {
                    c(a2, d2.sibling);
                    d2 = e(d2, f2.children || []);
                    d2.return = a2;
                    a2 = d2;
                    break a;
                  } else {
                    c(a2, d2);
                    break;
                  }
                  else b(a2, d2);
                  d2 = d2.sibling;
                }
                d2 = Sg(f2, a2.mode, h2);
                d2.return = a2;
                a2 = d2;
              }
              return g(a2);
            case Ha:
              return l2 = f2._init, J(a2, d2, l2(f2._payload), h2);
          }
          if (eb(f2)) return n(a2, d2, f2, h2);
          if (Ka(f2)) return t2(a2, d2, f2, h2);
          Mg(a2, f2);
        }
        return "string" === typeof f2 && "" !== f2 || "number" === typeof f2 ? (f2 = "" + f2, null !== d2 && 6 === d2.tag ? (c(a2, d2.sibling), d2 = e(d2, f2), d2.return = a2, a2 = d2) : (c(a2, d2), d2 = Qg(f2, a2.mode, h2), d2.return = a2, a2 = d2), g(a2)) : c(a2, d2);
      }
      return J;
    }
    var Ug = Og(true), Vg = Og(false), Wg = Uf(null), Xg = null, Yg = null, Zg = null;
    function $g() {
      Zg = Yg = Xg = null;
    }
    function ah(a) {
      var b = Wg.current;
      E(Wg);
      a._currentValue = b;
    }
    function bh(a, b, c) {
      for (; null !== a; ) {
        var d = a.alternate;
        (a.childLanes & b) !== b ? (a.childLanes |= b, null !== d && (d.childLanes |= b)) : null !== d && (d.childLanes & b) !== b && (d.childLanes |= b);
        if (a === c) break;
        a = a.return;
      }
    }
    function ch(a, b) {
      Xg = a;
      Zg = Yg = null;
      a = a.dependencies;
      null !== a && null !== a.firstContext && (0 !== (a.lanes & b) && (dh = true), a.firstContext = null);
    }
    function eh(a) {
      var b = a._currentValue;
      if (Zg !== a) if (a = { context: a, memoizedValue: b, next: null }, null === Yg) {
        if (null === Xg) throw Error(p(308));
        Yg = a;
        Xg.dependencies = { lanes: 0, firstContext: a };
      } else Yg = Yg.next = a;
      return b;
    }
    var fh = null;
    function gh(a) {
      null === fh ? fh = [a] : fh.push(a);
    }
    function hh(a, b, c, d) {
      var e = b.interleaved;
      null === e ? (c.next = c, gh(b)) : (c.next = e.next, e.next = c);
      b.interleaved = c;
      return ih(a, d);
    }
    function ih(a, b) {
      a.lanes |= b;
      var c = a.alternate;
      null !== c && (c.lanes |= b);
      c = a;
      for (a = a.return; null !== a; ) a.childLanes |= b, c = a.alternate, null !== c && (c.childLanes |= b), c = a, a = a.return;
      return 3 === c.tag ? c.stateNode : null;
    }
    var jh = false;
    function kh(a) {
      a.updateQueue = { baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
    }
    function lh(a, b) {
      a = a.updateQueue;
      b.updateQueue === a && (b.updateQueue = { baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects });
    }
    function mh(a, b) {
      return { eventTime: a, lane: b, tag: 0, payload: null, callback: null, next: null };
    }
    function nh(a, b, c) {
      var d = a.updateQueue;
      if (null === d) return null;
      d = d.shared;
      if (0 !== (K & 2)) {
        var e = d.pending;
        null === e ? b.next = b : (b.next = e.next, e.next = b);
        d.pending = b;
        return ih(a, c);
      }
      e = d.interleaved;
      null === e ? (b.next = b, gh(d)) : (b.next = e.next, e.next = b);
      d.interleaved = b;
      return ih(a, c);
    }
    function oh(a, b, c) {
      b = b.updateQueue;
      if (null !== b && (b = b.shared, 0 !== (c & 4194240))) {
        var d = b.lanes;
        d &= a.pendingLanes;
        c |= d;
        b.lanes = c;
        Cc(a, c);
      }
    }
    function ph(a, b) {
      var c = a.updateQueue, d = a.alternate;
      if (null !== d && (d = d.updateQueue, c === d)) {
        var e = null, f = null;
        c = c.firstBaseUpdate;
        if (null !== c) {
          do {
            var g = { eventTime: c.eventTime, lane: c.lane, tag: c.tag, payload: c.payload, callback: c.callback, next: null };
            null === f ? e = f = g : f = f.next = g;
            c = c.next;
          } while (null !== c);
          null === f ? e = f = b : f = f.next = b;
        } else e = f = b;
        c = { baseState: d.baseState, firstBaseUpdate: e, lastBaseUpdate: f, shared: d.shared, effects: d.effects };
        a.updateQueue = c;
        return;
      }
      a = c.lastBaseUpdate;
      null === a ? c.firstBaseUpdate = b : a.next = b;
      c.lastBaseUpdate = b;
    }
    function qh(a, b, c, d) {
      var e = a.updateQueue;
      jh = false;
      var f = e.firstBaseUpdate, g = e.lastBaseUpdate, h = e.shared.pending;
      if (null !== h) {
        e.shared.pending = null;
        var k = h, l = k.next;
        k.next = null;
        null === g ? f = l : g.next = l;
        g = k;
        var m = a.alternate;
        null !== m && (m = m.updateQueue, h = m.lastBaseUpdate, h !== g && (null === h ? m.firstBaseUpdate = l : h.next = l, m.lastBaseUpdate = k));
      }
      if (null !== f) {
        var q = e.baseState;
        g = 0;
        m = l = k = null;
        h = f;
        do {
          var r = h.lane, y = h.eventTime;
          if ((d & r) === r) {
            null !== m && (m = m.next = {
              eventTime: y,
              lane: 0,
              tag: h.tag,
              payload: h.payload,
              callback: h.callback,
              next: null
            });
            a: {
              var n = a, t2 = h;
              r = b;
              y = c;
              switch (t2.tag) {
                case 1:
                  n = t2.payload;
                  if ("function" === typeof n) {
                    q = n.call(y, q, r);
                    break a;
                  }
                  q = n;
                  break a;
                case 3:
                  n.flags = n.flags & -65537 | 128;
                case 0:
                  n = t2.payload;
                  r = "function" === typeof n ? n.call(y, q, r) : n;
                  if (null === r || void 0 === r) break a;
                  q = A({}, q, r);
                  break a;
                case 2:
                  jh = true;
              }
            }
            null !== h.callback && 0 !== h.lane && (a.flags |= 64, r = e.effects, null === r ? e.effects = [h] : r.push(h));
          } else y = { eventTime: y, lane: r, tag: h.tag, payload: h.payload, callback: h.callback, next: null }, null === m ? (l = m = y, k = q) : m = m.next = y, g |= r;
          h = h.next;
          if (null === h) if (h = e.shared.pending, null === h) break;
          else r = h, h = r.next, r.next = null, e.lastBaseUpdate = r, e.shared.pending = null;
        } while (1);
        null === m && (k = q);
        e.baseState = k;
        e.firstBaseUpdate = l;
        e.lastBaseUpdate = m;
        b = e.shared.interleaved;
        if (null !== b) {
          e = b;
          do
            g |= e.lane, e = e.next;
          while (e !== b);
        } else null === f && (e.shared.lanes = 0);
        rh |= g;
        a.lanes = g;
        a.memoizedState = q;
      }
    }
    function sh(a, b, c) {
      a = b.effects;
      b.effects = null;
      if (null !== a) for (b = 0; b < a.length; b++) {
        var d = a[b], e = d.callback;
        if (null !== e) {
          d.callback = null;
          d = c;
          if ("function" !== typeof e) throw Error(p(191, e));
          e.call(d);
        }
      }
    }
    var th = {}, uh = Uf(th), vh = Uf(th), wh = Uf(th);
    function xh(a) {
      if (a === th) throw Error(p(174));
      return a;
    }
    function yh(a, b) {
      G(wh, b);
      G(vh, a);
      G(uh, th);
      a = b.nodeType;
      switch (a) {
        case 9:
        case 11:
          b = (b = b.documentElement) ? b.namespaceURI : lb(null, "");
          break;
        default:
          a = 8 === a ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = lb(b, a);
      }
      E(uh);
      G(uh, b);
    }
    function zh() {
      E(uh);
      E(vh);
      E(wh);
    }
    function Ah(a) {
      xh(wh.current);
      var b = xh(uh.current);
      var c = lb(b, a.type);
      b !== c && (G(vh, a), G(uh, c));
    }
    function Bh(a) {
      vh.current === a && (E(uh), E(vh));
    }
    var L = Uf(0);
    function Ch(a) {
      for (var b = a; null !== b; ) {
        if (13 === b.tag) {
          var c = b.memoizedState;
          if (null !== c && (c = c.dehydrated, null === c || "$?" === c.data || "$!" === c.data)) return b;
        } else if (19 === b.tag && void 0 !== b.memoizedProps.revealOrder) {
          if (0 !== (b.flags & 128)) return b;
        } else if (null !== b.child) {
          b.child.return = b;
          b = b.child;
          continue;
        }
        if (b === a) break;
        for (; null === b.sibling; ) {
          if (null === b.return || b.return === a) return null;
          b = b.return;
        }
        b.sibling.return = b.return;
        b = b.sibling;
      }
      return null;
    }
    var Dh = [];
    function Eh() {
      for (var a = 0; a < Dh.length; a++) Dh[a]._workInProgressVersionPrimary = null;
      Dh.length = 0;
    }
    var Fh = ua.ReactCurrentDispatcher, Gh = ua.ReactCurrentBatchConfig, Hh = 0, M = null, N = null, O = null, Ih = false, Jh = false, Kh = 0, Lh = 0;
    function P() {
      throw Error(p(321));
    }
    function Mh(a, b) {
      if (null === b) return false;
      for (var c = 0; c < b.length && c < a.length; c++) if (!He(a[c], b[c])) return false;
      return true;
    }
    function Nh(a, b, c, d, e, f) {
      Hh = f;
      M = b;
      b.memoizedState = null;
      b.updateQueue = null;
      b.lanes = 0;
      Fh.current = null === a || null === a.memoizedState ? Oh : Ph;
      a = c(d, e);
      if (Jh) {
        f = 0;
        do {
          Jh = false;
          Kh = 0;
          if (25 <= f) throw Error(p(301));
          f += 1;
          O = N = null;
          b.updateQueue = null;
          Fh.current = Qh;
          a = c(d, e);
        } while (Jh);
      }
      Fh.current = Rh;
      b = null !== N && null !== N.next;
      Hh = 0;
      O = N = M = null;
      Ih = false;
      if (b) throw Error(p(300));
      return a;
    }
    function Sh() {
      var a = 0 !== Kh;
      Kh = 0;
      return a;
    }
    function Th() {
      var a = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
      null === O ? M.memoizedState = O = a : O = O.next = a;
      return O;
    }
    function Uh() {
      if (null === N) {
        var a = M.alternate;
        a = null !== a ? a.memoizedState : null;
      } else a = N.next;
      var b = null === O ? M.memoizedState : O.next;
      if (null !== b) O = b, N = a;
      else {
        if (null === a) throw Error(p(310));
        N = a;
        a = { memoizedState: N.memoizedState, baseState: N.baseState, baseQueue: N.baseQueue, queue: N.queue, next: null };
        null === O ? M.memoizedState = O = a : O = O.next = a;
      }
      return O;
    }
    function Vh(a, b) {
      return "function" === typeof b ? b(a) : b;
    }
    function Wh(a) {
      var b = Uh(), c = b.queue;
      if (null === c) throw Error(p(311));
      c.lastRenderedReducer = a;
      var d = N, e = d.baseQueue, f = c.pending;
      if (null !== f) {
        if (null !== e) {
          var g = e.next;
          e.next = f.next;
          f.next = g;
        }
        d.baseQueue = e = f;
        c.pending = null;
      }
      if (null !== e) {
        f = e.next;
        d = d.baseState;
        var h = g = null, k = null, l = f;
        do {
          var m = l.lane;
          if ((Hh & m) === m) null !== k && (k = k.next = { lane: 0, action: l.action, hasEagerState: l.hasEagerState, eagerState: l.eagerState, next: null }), d = l.hasEagerState ? l.eagerState : a(d, l.action);
          else {
            var q = {
              lane: m,
              action: l.action,
              hasEagerState: l.hasEagerState,
              eagerState: l.eagerState,
              next: null
            };
            null === k ? (h = k = q, g = d) : k = k.next = q;
            M.lanes |= m;
            rh |= m;
          }
          l = l.next;
        } while (null !== l && l !== f);
        null === k ? g = d : k.next = h;
        He(d, b.memoizedState) || (dh = true);
        b.memoizedState = d;
        b.baseState = g;
        b.baseQueue = k;
        c.lastRenderedState = d;
      }
      a = c.interleaved;
      if (null !== a) {
        e = a;
        do
          f = e.lane, M.lanes |= f, rh |= f, e = e.next;
        while (e !== a);
      } else null === e && (c.lanes = 0);
      return [b.memoizedState, c.dispatch];
    }
    function Xh(a) {
      var b = Uh(), c = b.queue;
      if (null === c) throw Error(p(311));
      c.lastRenderedReducer = a;
      var d = c.dispatch, e = c.pending, f = b.memoizedState;
      if (null !== e) {
        c.pending = null;
        var g = e = e.next;
        do
          f = a(f, g.action), g = g.next;
        while (g !== e);
        He(f, b.memoizedState) || (dh = true);
        b.memoizedState = f;
        null === b.baseQueue && (b.baseState = f);
        c.lastRenderedState = f;
      }
      return [f, d];
    }
    function Yh() {
    }
    function Zh(a, b) {
      var c = M, d = Uh(), e = b(), f = !He(d.memoizedState, e);
      f && (d.memoizedState = e, dh = true);
      d = d.queue;
      $h(ai.bind(null, c, d, a), [a]);
      if (d.getSnapshot !== b || f || null !== O && O.memoizedState.tag & 1) {
        c.flags |= 2048;
        bi(9, ci.bind(null, c, d, e, b), void 0, null);
        if (null === Q) throw Error(p(349));
        0 !== (Hh & 30) || di(c, b, e);
      }
      return e;
    }
    function di(a, b, c) {
      a.flags |= 16384;
      a = { getSnapshot: b, value: c };
      b = M.updateQueue;
      null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.stores = [a]) : (c = b.stores, null === c ? b.stores = [a] : c.push(a));
    }
    function ci(a, b, c, d) {
      b.value = c;
      b.getSnapshot = d;
      ei(b) && fi(a);
    }
    function ai(a, b, c) {
      return c(function() {
        ei(b) && fi(a);
      });
    }
    function ei(a) {
      var b = a.getSnapshot;
      a = a.value;
      try {
        var c = b();
        return !He(a, c);
      } catch (d) {
        return true;
      }
    }
    function fi(a) {
      var b = ih(a, 1);
      null !== b && gi(b, a, 1, -1);
    }
    function hi(a) {
      var b = Th();
      "function" === typeof a && (a = a());
      b.memoizedState = b.baseState = a;
      a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Vh, lastRenderedState: a };
      b.queue = a;
      a = a.dispatch = ii.bind(null, M, a);
      return [b.memoizedState, a];
    }
    function bi(a, b, c, d) {
      a = { tag: a, create: b, destroy: c, deps: d, next: null };
      b = M.updateQueue;
      null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, null === c ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
      return a;
    }
    function ji() {
      return Uh().memoizedState;
    }
    function ki(a, b, c, d) {
      var e = Th();
      M.flags |= a;
      e.memoizedState = bi(1 | b, c, void 0, void 0 === d ? null : d);
    }
    function li(a, b, c, d) {
      var e = Uh();
      d = void 0 === d ? null : d;
      var f = void 0;
      if (null !== N) {
        var g = N.memoizedState;
        f = g.destroy;
        if (null !== d && Mh(d, g.deps)) {
          e.memoizedState = bi(b, c, f, d);
          return;
        }
      }
      M.flags |= a;
      e.memoizedState = bi(1 | b, c, f, d);
    }
    function mi(a, b) {
      return ki(8390656, 8, a, b);
    }
    function $h(a, b) {
      return li(2048, 8, a, b);
    }
    function ni(a, b) {
      return li(4, 2, a, b);
    }
    function oi(a, b) {
      return li(4, 4, a, b);
    }
    function pi(a, b) {
      if ("function" === typeof b) return a = a(), b(a), function() {
        b(null);
      };
      if (null !== b && void 0 !== b) return a = a(), b.current = a, function() {
        b.current = null;
      };
    }
    function qi(a, b, c) {
      c = null !== c && void 0 !== c ? c.concat([a]) : null;
      return li(4, 4, pi.bind(null, b, a), c);
    }
    function ri() {
    }
    function si(a, b) {
      var c = Uh();
      b = void 0 === b ? null : b;
      var d = c.memoizedState;
      if (null !== d && null !== b && Mh(b, d[1])) return d[0];
      c.memoizedState = [a, b];
      return a;
    }
    function ti(a, b) {
      var c = Uh();
      b = void 0 === b ? null : b;
      var d = c.memoizedState;
      if (null !== d && null !== b && Mh(b, d[1])) return d[0];
      a = a();
      c.memoizedState = [a, b];
      return a;
    }
    function ui(a, b, c) {
      if (0 === (Hh & 21)) return a.baseState && (a.baseState = false, dh = true), a.memoizedState = c;
      He(c, b) || (c = yc(), M.lanes |= c, rh |= c, a.baseState = true);
      return b;
    }
    function vi(a, b) {
      var c = C;
      C = 0 !== c && 4 > c ? c : 4;
      a(true);
      var d = Gh.transition;
      Gh.transition = {};
      try {
        a(false), b();
      } finally {
        C = c, Gh.transition = d;
      }
    }
    function wi() {
      return Uh().memoizedState;
    }
    function xi(a, b, c) {
      var d = yi(a);
      c = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
      if (zi(a)) Ai(b, c);
      else if (c = hh(a, b, c, d), null !== c) {
        var e = R();
        gi(c, a, d, e);
        Bi(c, b, d);
      }
    }
    function ii(a, b, c) {
      var d = yi(a), e = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
      if (zi(a)) Ai(b, e);
      else {
        var f = a.alternate;
        if (0 === a.lanes && (null === f || 0 === f.lanes) && (f = b.lastRenderedReducer, null !== f)) try {
          var g = b.lastRenderedState, h = f(g, c);
          e.hasEagerState = true;
          e.eagerState = h;
          if (He(h, g)) {
            var k = b.interleaved;
            null === k ? (e.next = e, gh(b)) : (e.next = k.next, k.next = e);
            b.interleaved = e;
            return;
          }
        } catch (l) {
        } finally {
        }
        c = hh(a, b, e, d);
        null !== c && (e = R(), gi(c, a, d, e), Bi(c, b, d));
      }
    }
    function zi(a) {
      var b = a.alternate;
      return a === M || null !== b && b === M;
    }
    function Ai(a, b) {
      Jh = Ih = true;
      var c = a.pending;
      null === c ? b.next = b : (b.next = c.next, c.next = b);
      a.pending = b;
    }
    function Bi(a, b, c) {
      if (0 !== (c & 4194240)) {
        var d = b.lanes;
        d &= a.pendingLanes;
        c |= d;
        b.lanes = c;
        Cc(a, c);
      }
    }
    var Rh = { readContext: eh, useCallback: P, useContext: P, useEffect: P, useImperativeHandle: P, useInsertionEffect: P, useLayoutEffect: P, useMemo: P, useReducer: P, useRef: P, useState: P, useDebugValue: P, useDeferredValue: P, useTransition: P, useMutableSource: P, useSyncExternalStore: P, useId: P, unstable_isNewReconciler: false }, Oh = { readContext: eh, useCallback: function(a, b) {
      Th().memoizedState = [a, void 0 === b ? null : b];
      return a;
    }, useContext: eh, useEffect: mi, useImperativeHandle: function(a, b, c) {
      c = null !== c && void 0 !== c ? c.concat([a]) : null;
      return ki(
        4194308,
        4,
        pi.bind(null, b, a),
        c
      );
    }, useLayoutEffect: function(a, b) {
      return ki(4194308, 4, a, b);
    }, useInsertionEffect: function(a, b) {
      return ki(4, 2, a, b);
    }, useMemo: function(a, b) {
      var c = Th();
      b = void 0 === b ? null : b;
      a = a();
      c.memoizedState = [a, b];
      return a;
    }, useReducer: function(a, b, c) {
      var d = Th();
      b = void 0 !== c ? c(b) : b;
      d.memoizedState = d.baseState = b;
      a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: a, lastRenderedState: b };
      d.queue = a;
      a = a.dispatch = xi.bind(null, M, a);
      return [d.memoizedState, a];
    }, useRef: function(a) {
      var b = Th();
      a = { current: a };
      return b.memoizedState = a;
    }, useState: hi, useDebugValue: ri, useDeferredValue: function(a) {
      return Th().memoizedState = a;
    }, useTransition: function() {
      var a = hi(false), b = a[0];
      a = vi.bind(null, a[1]);
      Th().memoizedState = a;
      return [b, a];
    }, useMutableSource: function() {
    }, useSyncExternalStore: function(a, b, c) {
      var d = M, e = Th();
      if (I) {
        if (void 0 === c) throw Error(p(407));
        c = c();
      } else {
        c = b();
        if (null === Q) throw Error(p(349));
        0 !== (Hh & 30) || di(d, b, c);
      }
      e.memoizedState = c;
      var f = { value: c, getSnapshot: b };
      e.queue = f;
      mi(ai.bind(
        null,
        d,
        f,
        a
      ), [a]);
      d.flags |= 2048;
      bi(9, ci.bind(null, d, f, c, b), void 0, null);
      return c;
    }, useId: function() {
      var a = Th(), b = Q.identifierPrefix;
      if (I) {
        var c = sg;
        var d = rg;
        c = (d & ~(1 << 32 - oc(d) - 1)).toString(32) + c;
        b = ":" + b + "R" + c;
        c = Kh++;
        0 < c && (b += "H" + c.toString(32));
        b += ":";
      } else c = Lh++, b = ":" + b + "r" + c.toString(32) + ":";
      return a.memoizedState = b;
    }, unstable_isNewReconciler: false }, Ph = {
      readContext: eh,
      useCallback: si,
      useContext: eh,
      useEffect: $h,
      useImperativeHandle: qi,
      useInsertionEffect: ni,
      useLayoutEffect: oi,
      useMemo: ti,
      useReducer: Wh,
      useRef: ji,
      useState: function() {
        return Wh(Vh);
      },
      useDebugValue: ri,
      useDeferredValue: function(a) {
        var b = Uh();
        return ui(b, N.memoizedState, a);
      },
      useTransition: function() {
        var a = Wh(Vh)[0], b = Uh().memoizedState;
        return [a, b];
      },
      useMutableSource: Yh,
      useSyncExternalStore: Zh,
      useId: wi,
      unstable_isNewReconciler: false
    }, Qh = { readContext: eh, useCallback: si, useContext: eh, useEffect: $h, useImperativeHandle: qi, useInsertionEffect: ni, useLayoutEffect: oi, useMemo: ti, useReducer: Xh, useRef: ji, useState: function() {
      return Xh(Vh);
    }, useDebugValue: ri, useDeferredValue: function(a) {
      var b = Uh();
      return null === N ? b.memoizedState = a : ui(b, N.memoizedState, a);
    }, useTransition: function() {
      var a = Xh(Vh)[0], b = Uh().memoizedState;
      return [a, b];
    }, useMutableSource: Yh, useSyncExternalStore: Zh, useId: wi, unstable_isNewReconciler: false };
    function Ci(a, b) {
      if (a && a.defaultProps) {
        b = A({}, b);
        a = a.defaultProps;
        for (var c in a) void 0 === b[c] && (b[c] = a[c]);
        return b;
      }
      return b;
    }
    function Di(a, b, c, d) {
      b = a.memoizedState;
      c = c(d, b);
      c = null === c || void 0 === c ? b : A({}, b, c);
      a.memoizedState = c;
      0 === a.lanes && (a.updateQueue.baseState = c);
    }
    var Ei = { isMounted: function(a) {
      return (a = a._reactInternals) ? Vb(a) === a : false;
    }, enqueueSetState: function(a, b, c) {
      a = a._reactInternals;
      var d = R(), e = yi(a), f = mh(d, e);
      f.payload = b;
      void 0 !== c && null !== c && (f.callback = c);
      b = nh(a, f, e);
      null !== b && (gi(b, a, e, d), oh(b, a, e));
    }, enqueueReplaceState: function(a, b, c) {
      a = a._reactInternals;
      var d = R(), e = yi(a), f = mh(d, e);
      f.tag = 1;
      f.payload = b;
      void 0 !== c && null !== c && (f.callback = c);
      b = nh(a, f, e);
      null !== b && (gi(b, a, e, d), oh(b, a, e));
    }, enqueueForceUpdate: function(a, b) {
      a = a._reactInternals;
      var c = R(), d = yi(a), e = mh(c, d);
      e.tag = 2;
      void 0 !== b && null !== b && (e.callback = b);
      b = nh(a, e, d);
      null !== b && (gi(b, a, d, c), oh(b, a, d));
    } };
    function Fi(a, b, c, d, e, f, g) {
      a = a.stateNode;
      return "function" === typeof a.shouldComponentUpdate ? a.shouldComponentUpdate(d, f, g) : b.prototype && b.prototype.isPureReactComponent ? !Ie(c, d) || !Ie(e, f) : true;
    }
    function Gi(a, b, c) {
      var d = false, e = Vf;
      var f = b.contextType;
      "object" === typeof f && null !== f ? f = eh(f) : (e = Zf(b) ? Xf : H.current, d = b.contextTypes, f = (d = null !== d && void 0 !== d) ? Yf(a, e) : Vf);
      b = new b(c, f);
      a.memoizedState = null !== b.state && void 0 !== b.state ? b.state : null;
      b.updater = Ei;
      a.stateNode = b;
      b._reactInternals = a;
      d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f);
      return b;
    }
    function Hi(a, b, c, d) {
      a = b.state;
      "function" === typeof b.componentWillReceiveProps && b.componentWillReceiveProps(c, d);
      "function" === typeof b.UNSAFE_componentWillReceiveProps && b.UNSAFE_componentWillReceiveProps(c, d);
      b.state !== a && Ei.enqueueReplaceState(b, b.state, null);
    }
    function Ii(a, b, c, d) {
      var e = a.stateNode;
      e.props = c;
      e.state = a.memoizedState;
      e.refs = {};
      kh(a);
      var f = b.contextType;
      "object" === typeof f && null !== f ? e.context = eh(f) : (f = Zf(b) ? Xf : H.current, e.context = Yf(a, f));
      e.state = a.memoizedState;
      f = b.getDerivedStateFromProps;
      "function" === typeof f && (Di(a, b, f, c), e.state = a.memoizedState);
      "function" === typeof b.getDerivedStateFromProps || "function" === typeof e.getSnapshotBeforeUpdate || "function" !== typeof e.UNSAFE_componentWillMount && "function" !== typeof e.componentWillMount || (b = e.state, "function" === typeof e.componentWillMount && e.componentWillMount(), "function" === typeof e.UNSAFE_componentWillMount && e.UNSAFE_componentWillMount(), b !== e.state && Ei.enqueueReplaceState(e, e.state, null), qh(a, c, e, d), e.state = a.memoizedState);
      "function" === typeof e.componentDidMount && (a.flags |= 4194308);
    }
    function Ji(a, b) {
      try {
        var c = "", d = b;
        do
          c += Pa(d), d = d.return;
        while (d);
        var e = c;
      } catch (f) {
        e = "\nError generating stack: " + f.message + "\n" + f.stack;
      }
      return { value: a, source: b, stack: e, digest: null };
    }
    function Ki(a, b, c) {
      return { value: a, source: null, stack: null != c ? c : null, digest: null != b ? b : null };
    }
    function Li(a, b) {
      try {
        console.error(b.value);
      } catch (c) {
        setTimeout(function() {
          throw c;
        });
      }
    }
    var Mi = "function" === typeof WeakMap ? WeakMap : Map;
    function Ni(a, b, c) {
      c = mh(-1, c);
      c.tag = 3;
      c.payload = { element: null };
      var d = b.value;
      c.callback = function() {
        Oi || (Oi = true, Pi = d);
        Li(a, b);
      };
      return c;
    }
    function Qi(a, b, c) {
      c = mh(-1, c);
      c.tag = 3;
      var d = a.type.getDerivedStateFromError;
      if ("function" === typeof d) {
        var e = b.value;
        c.payload = function() {
          return d(e);
        };
        c.callback = function() {
          Li(a, b);
        };
      }
      var f = a.stateNode;
      null !== f && "function" === typeof f.componentDidCatch && (c.callback = function() {
        Li(a, b);
        "function" !== typeof d && (null === Ri ? Ri = /* @__PURE__ */ new Set([this]) : Ri.add(this));
        var c2 = b.stack;
        this.componentDidCatch(b.value, { componentStack: null !== c2 ? c2 : "" });
      });
      return c;
    }
    function Si(a, b, c) {
      var d = a.pingCache;
      if (null === d) {
        d = a.pingCache = new Mi();
        var e = /* @__PURE__ */ new Set();
        d.set(b, e);
      } else e = d.get(b), void 0 === e && (e = /* @__PURE__ */ new Set(), d.set(b, e));
      e.has(c) || (e.add(c), a = Ti.bind(null, a, b, c), b.then(a, a));
    }
    function Ui(a) {
      do {
        var b;
        if (b = 13 === a.tag) b = a.memoizedState, b = null !== b ? null !== b.dehydrated ? true : false : true;
        if (b) return a;
        a = a.return;
      } while (null !== a);
      return null;
    }
    function Vi(a, b, c, d, e) {
      if (0 === (a.mode & 1)) return a === b ? a.flags |= 65536 : (a.flags |= 128, c.flags |= 131072, c.flags &= -52805, 1 === c.tag && (null === c.alternate ? c.tag = 17 : (b = mh(-1, 1), b.tag = 2, nh(c, b, 1))), c.lanes |= 1), a;
      a.flags |= 65536;
      a.lanes = e;
      return a;
    }
    var Wi = ua.ReactCurrentOwner, dh = false;
    function Xi(a, b, c, d) {
      b.child = null === a ? Vg(b, null, c, d) : Ug(b, a.child, c, d);
    }
    function Yi(a, b, c, d, e) {
      c = c.render;
      var f = b.ref;
      ch(b, e);
      d = Nh(a, b, c, d, f, e);
      c = Sh();
      if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
      I && c && vg(b);
      b.flags |= 1;
      Xi(a, b, d, e);
      return b.child;
    }
    function $i(a, b, c, d, e) {
      if (null === a) {
        var f = c.type;
        if ("function" === typeof f && !aj(f) && void 0 === f.defaultProps && null === c.compare && void 0 === c.defaultProps) return b.tag = 15, b.type = f, bj(a, b, f, d, e);
        a = Rg(c.type, null, d, b, b.mode, e);
        a.ref = b.ref;
        a.return = b;
        return b.child = a;
      }
      f = a.child;
      if (0 === (a.lanes & e)) {
        var g = f.memoizedProps;
        c = c.compare;
        c = null !== c ? c : Ie;
        if (c(g, d) && a.ref === b.ref) return Zi(a, b, e);
      }
      b.flags |= 1;
      a = Pg(f, d);
      a.ref = b.ref;
      a.return = b;
      return b.child = a;
    }
    function bj(a, b, c, d, e) {
      if (null !== a) {
        var f = a.memoizedProps;
        if (Ie(f, d) && a.ref === b.ref) if (dh = false, b.pendingProps = d = f, 0 !== (a.lanes & e)) 0 !== (a.flags & 131072) && (dh = true);
        else return b.lanes = a.lanes, Zi(a, b, e);
      }
      return cj(a, b, c, d, e);
    }
    function dj(a, b, c) {
      var d = b.pendingProps, e = d.children, f = null !== a ? a.memoizedState : null;
      if ("hidden" === d.mode) if (0 === (b.mode & 1)) b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, G(ej, fj), fj |= c;
      else {
        if (0 === (c & 1073741824)) return a = null !== f ? f.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = { baseLanes: a, cachePool: null, transitions: null }, b.updateQueue = null, G(ej, fj), fj |= a, null;
        b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null };
        d = null !== f ? f.baseLanes : c;
        G(ej, fj);
        fj |= d;
      }
      else null !== f ? (d = f.baseLanes | c, b.memoizedState = null) : d = c, G(ej, fj), fj |= d;
      Xi(a, b, e, c);
      return b.child;
    }
    function gj(a, b) {
      var c = b.ref;
      if (null === a && null !== c || null !== a && a.ref !== c) b.flags |= 512, b.flags |= 2097152;
    }
    function cj(a, b, c, d, e) {
      var f = Zf(c) ? Xf : H.current;
      f = Yf(b, f);
      ch(b, e);
      c = Nh(a, b, c, d, f, e);
      d = Sh();
      if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
      I && d && vg(b);
      b.flags |= 1;
      Xi(a, b, c, e);
      return b.child;
    }
    function hj(a, b, c, d, e) {
      if (Zf(c)) {
        var f = true;
        cg(b);
      } else f = false;
      ch(b, e);
      if (null === b.stateNode) ij(a, b), Gi(b, c, d), Ii(b, c, d, e), d = true;
      else if (null === a) {
        var g = b.stateNode, h = b.memoizedProps;
        g.props = h;
        var k = g.context, l = c.contextType;
        "object" === typeof l && null !== l ? l = eh(l) : (l = Zf(c) ? Xf : H.current, l = Yf(b, l));
        var m = c.getDerivedStateFromProps, q = "function" === typeof m || "function" === typeof g.getSnapshotBeforeUpdate;
        q || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== d || k !== l) && Hi(b, g, d, l);
        jh = false;
        var r = b.memoizedState;
        g.state = r;
        qh(b, d, g, e);
        k = b.memoizedState;
        h !== d || r !== k || Wf.current || jh ? ("function" === typeof m && (Di(b, c, m, d), k = b.memoizedState), (h = jh || Fi(b, c, h, d, r, k, l)) ? (q || "function" !== typeof g.UNSAFE_componentWillMount && "function" !== typeof g.componentWillMount || ("function" === typeof g.componentWillMount && g.componentWillMount(), "function" === typeof g.UNSAFE_componentWillMount && g.UNSAFE_componentWillMount()), "function" === typeof g.componentDidMount && (b.flags |= 4194308)) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), b.memoizedProps = d, b.memoizedState = k), g.props = d, g.state = k, g.context = l, d = h) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), d = false);
      } else {
        g = b.stateNode;
        lh(a, b);
        h = b.memoizedProps;
        l = b.type === b.elementType ? h : Ci(b.type, h);
        g.props = l;
        q = b.pendingProps;
        r = g.context;
        k = c.contextType;
        "object" === typeof k && null !== k ? k = eh(k) : (k = Zf(c) ? Xf : H.current, k = Yf(b, k));
        var y = c.getDerivedStateFromProps;
        (m = "function" === typeof y || "function" === typeof g.getSnapshotBeforeUpdate) || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h !== q || r !== k) && Hi(b, g, d, k);
        jh = false;
        r = b.memoizedState;
        g.state = r;
        qh(b, d, g, e);
        var n = b.memoizedState;
        h !== q || r !== n || Wf.current || jh ? ("function" === typeof y && (Di(b, c, y, d), n = b.memoizedState), (l = jh || Fi(b, c, l, d, r, n, k) || false) ? (m || "function" !== typeof g.UNSAFE_componentWillUpdate && "function" !== typeof g.componentWillUpdate || ("function" === typeof g.componentWillUpdate && g.componentWillUpdate(d, n, k), "function" === typeof g.UNSAFE_componentWillUpdate && g.UNSAFE_componentWillUpdate(d, n, k)), "function" === typeof g.componentDidUpdate && (b.flags |= 4), "function" === typeof g.getSnapshotBeforeUpdate && (b.flags |= 1024)) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), b.memoizedProps = d, b.memoizedState = n), g.props = d, g.state = n, g.context = k, d = l) : ("function" !== typeof g.componentDidUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), d = false);
      }
      return jj(a, b, c, d, f, e);
    }
    function jj(a, b, c, d, e, f) {
      gj(a, b);
      var g = 0 !== (b.flags & 128);
      if (!d && !g) return e && dg(b, c, false), Zi(a, b, f);
      d = b.stateNode;
      Wi.current = b;
      var h = g && "function" !== typeof c.getDerivedStateFromError ? null : d.render();
      b.flags |= 1;
      null !== a && g ? (b.child = Ug(b, a.child, null, f), b.child = Ug(b, null, h, f)) : Xi(a, b, h, f);
      b.memoizedState = d.state;
      e && dg(b, c, true);
      return b.child;
    }
    function kj(a) {
      var b = a.stateNode;
      b.pendingContext ? ag(a, b.pendingContext, b.pendingContext !== b.context) : b.context && ag(a, b.context, false);
      yh(a, b.containerInfo);
    }
    function lj(a, b, c, d, e) {
      Ig();
      Jg(e);
      b.flags |= 256;
      Xi(a, b, c, d);
      return b.child;
    }
    var mj = { dehydrated: null, treeContext: null, retryLane: 0 };
    function nj(a) {
      return { baseLanes: a, cachePool: null, transitions: null };
    }
    function oj(a, b, c) {
      var d = b.pendingProps, e = L.current, f = false, g = 0 !== (b.flags & 128), h;
      (h = g) || (h = null !== a && null === a.memoizedState ? false : 0 !== (e & 2));
      if (h) f = true, b.flags &= -129;
      else if (null === a || null !== a.memoizedState) e |= 1;
      G(L, e & 1);
      if (null === a) {
        Eg(b);
        a = b.memoizedState;
        if (null !== a && (a = a.dehydrated, null !== a)) return 0 === (b.mode & 1) ? b.lanes = 1 : "$!" === a.data ? b.lanes = 8 : b.lanes = 1073741824, null;
        g = d.children;
        a = d.fallback;
        return f ? (d = b.mode, f = b.child, g = { mode: "hidden", children: g }, 0 === (d & 1) && null !== f ? (f.childLanes = 0, f.pendingProps = g) : f = pj(g, d, 0, null), a = Tg(a, d, c, null), f.return = b, a.return = b, f.sibling = a, b.child = f, b.child.memoizedState = nj(c), b.memoizedState = mj, a) : qj(b, g);
      }
      e = a.memoizedState;
      if (null !== e && (h = e.dehydrated, null !== h)) return rj(a, b, g, d, h, e, c);
      if (f) {
        f = d.fallback;
        g = b.mode;
        e = a.child;
        h = e.sibling;
        var k = { mode: "hidden", children: d.children };
        0 === (g & 1) && b.child !== e ? (d = b.child, d.childLanes = 0, d.pendingProps = k, b.deletions = null) : (d = Pg(e, k), d.subtreeFlags = e.subtreeFlags & 14680064);
        null !== h ? f = Pg(h, f) : (f = Tg(f, g, c, null), f.flags |= 2);
        f.return = b;
        d.return = b;
        d.sibling = f;
        b.child = d;
        d = f;
        f = b.child;
        g = a.child.memoizedState;
        g = null === g ? nj(c) : { baseLanes: g.baseLanes | c, cachePool: null, transitions: g.transitions };
        f.memoizedState = g;
        f.childLanes = a.childLanes & ~c;
        b.memoizedState = mj;
        return d;
      }
      f = a.child;
      a = f.sibling;
      d = Pg(f, { mode: "visible", children: d.children });
      0 === (b.mode & 1) && (d.lanes = c);
      d.return = b;
      d.sibling = null;
      null !== a && (c = b.deletions, null === c ? (b.deletions = [a], b.flags |= 16) : c.push(a));
      b.child = d;
      b.memoizedState = null;
      return d;
    }
    function qj(a, b) {
      b = pj({ mode: "visible", children: b }, a.mode, 0, null);
      b.return = a;
      return a.child = b;
    }
    function sj(a, b, c, d) {
      null !== d && Jg(d);
      Ug(b, a.child, null, c);
      a = qj(b, b.pendingProps.children);
      a.flags |= 2;
      b.memoizedState = null;
      return a;
    }
    function rj(a, b, c, d, e, f, g) {
      if (c) {
        if (b.flags & 256) return b.flags &= -257, d = Ki(Error(p(422))), sj(a, b, g, d);
        if (null !== b.memoizedState) return b.child = a.child, b.flags |= 128, null;
        f = d.fallback;
        e = b.mode;
        d = pj({ mode: "visible", children: d.children }, e, 0, null);
        f = Tg(f, e, g, null);
        f.flags |= 2;
        d.return = b;
        f.return = b;
        d.sibling = f;
        b.child = d;
        0 !== (b.mode & 1) && Ug(b, a.child, null, g);
        b.child.memoizedState = nj(g);
        b.memoizedState = mj;
        return f;
      }
      if (0 === (b.mode & 1)) return sj(a, b, g, null);
      if ("$!" === e.data) {
        d = e.nextSibling && e.nextSibling.dataset;
        if (d) var h = d.dgst;
        d = h;
        f = Error(p(419));
        d = Ki(f, d, void 0);
        return sj(a, b, g, d);
      }
      h = 0 !== (g & a.childLanes);
      if (dh || h) {
        d = Q;
        if (null !== d) {
          switch (g & -g) {
            case 4:
              e = 2;
              break;
            case 16:
              e = 8;
              break;
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
              e = 32;
              break;
            case 536870912:
              e = 268435456;
              break;
            default:
              e = 0;
          }
          e = 0 !== (e & (d.suspendedLanes | g)) ? 0 : e;
          0 !== e && e !== f.retryLane && (f.retryLane = e, ih(a, e), gi(d, a, e, -1));
        }
        tj();
        d = Ki(Error(p(421)));
        return sj(a, b, g, d);
      }
      if ("$?" === e.data) return b.flags |= 128, b.child = a.child, b = uj.bind(null, a), e._reactRetry = b, null;
      a = f.treeContext;
      yg = Lf(e.nextSibling);
      xg = b;
      I = true;
      zg = null;
      null !== a && (og[pg++] = rg, og[pg++] = sg, og[pg++] = qg, rg = a.id, sg = a.overflow, qg = b);
      b = qj(b, d.children);
      b.flags |= 4096;
      return b;
    }
    function vj(a, b, c) {
      a.lanes |= b;
      var d = a.alternate;
      null !== d && (d.lanes |= b);
      bh(a.return, b, c);
    }
    function wj(a, b, c, d, e) {
      var f = a.memoizedState;
      null === f ? a.memoizedState = { isBackwards: b, rendering: null, renderingStartTime: 0, last: d, tail: c, tailMode: e } : (f.isBackwards = b, f.rendering = null, f.renderingStartTime = 0, f.last = d, f.tail = c, f.tailMode = e);
    }
    function xj(a, b, c) {
      var d = b.pendingProps, e = d.revealOrder, f = d.tail;
      Xi(a, b, d.children, c);
      d = L.current;
      if (0 !== (d & 2)) d = d & 1 | 2, b.flags |= 128;
      else {
        if (null !== a && 0 !== (a.flags & 128)) a: for (a = b.child; null !== a; ) {
          if (13 === a.tag) null !== a.memoizedState && vj(a, c, b);
          else if (19 === a.tag) vj(a, c, b);
          else if (null !== a.child) {
            a.child.return = a;
            a = a.child;
            continue;
          }
          if (a === b) break a;
          for (; null === a.sibling; ) {
            if (null === a.return || a.return === b) break a;
            a = a.return;
          }
          a.sibling.return = a.return;
          a = a.sibling;
        }
        d &= 1;
      }
      G(L, d);
      if (0 === (b.mode & 1)) b.memoizedState = null;
      else switch (e) {
        case "forwards":
          c = b.child;
          for (e = null; null !== c; ) a = c.alternate, null !== a && null === Ch(a) && (e = c), c = c.sibling;
          c = e;
          null === c ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
          wj(b, false, e, c, f);
          break;
        case "backwards":
          c = null;
          e = b.child;
          for (b.child = null; null !== e; ) {
            a = e.alternate;
            if (null !== a && null === Ch(a)) {
              b.child = e;
              break;
            }
            a = e.sibling;
            e.sibling = c;
            c = e;
            e = a;
          }
          wj(b, true, c, null, f);
          break;
        case "together":
          wj(b, false, null, null, void 0);
          break;
        default:
          b.memoizedState = null;
      }
      return b.child;
    }
    function ij(a, b) {
      0 === (b.mode & 1) && null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2);
    }
    function Zi(a, b, c) {
      null !== a && (b.dependencies = a.dependencies);
      rh |= b.lanes;
      if (0 === (c & b.childLanes)) return null;
      if (null !== a && b.child !== a.child) throw Error(p(153));
      if (null !== b.child) {
        a = b.child;
        c = Pg(a, a.pendingProps);
        b.child = c;
        for (c.return = b; null !== a.sibling; ) a = a.sibling, c = c.sibling = Pg(a, a.pendingProps), c.return = b;
        c.sibling = null;
      }
      return b.child;
    }
    function yj(a, b, c) {
      switch (b.tag) {
        case 3:
          kj(b);
          Ig();
          break;
        case 5:
          Ah(b);
          break;
        case 1:
          Zf(b.type) && cg(b);
          break;
        case 4:
          yh(b, b.stateNode.containerInfo);
          break;
        case 10:
          var d = b.type._context, e = b.memoizedProps.value;
          G(Wg, d._currentValue);
          d._currentValue = e;
          break;
        case 13:
          d = b.memoizedState;
          if (null !== d) {
            if (null !== d.dehydrated) return G(L, L.current & 1), b.flags |= 128, null;
            if (0 !== (c & b.child.childLanes)) return oj(a, b, c);
            G(L, L.current & 1);
            a = Zi(a, b, c);
            return null !== a ? a.sibling : null;
          }
          G(L, L.current & 1);
          break;
        case 19:
          d = 0 !== (c & b.childLanes);
          if (0 !== (a.flags & 128)) {
            if (d) return xj(a, b, c);
            b.flags |= 128;
          }
          e = b.memoizedState;
          null !== e && (e.rendering = null, e.tail = null, e.lastEffect = null);
          G(L, L.current);
          if (d) break;
          else return null;
        case 22:
        case 23:
          return b.lanes = 0, dj(a, b, c);
      }
      return Zi(a, b, c);
    }
    var zj, Aj, Bj, Cj;
    zj = function(a, b) {
      for (var c = b.child; null !== c; ) {
        if (5 === c.tag || 6 === c.tag) a.appendChild(c.stateNode);
        else if (4 !== c.tag && null !== c.child) {
          c.child.return = c;
          c = c.child;
          continue;
        }
        if (c === b) break;
        for (; null === c.sibling; ) {
          if (null === c.return || c.return === b) return;
          c = c.return;
        }
        c.sibling.return = c.return;
        c = c.sibling;
      }
    };
    Aj = function() {
    };
    Bj = function(a, b, c, d) {
      var e = a.memoizedProps;
      if (e !== d) {
        a = b.stateNode;
        xh(uh.current);
        var f = null;
        switch (c) {
          case "input":
            e = Ya(a, e);
            d = Ya(a, d);
            f = [];
            break;
          case "select":
            e = A({}, e, { value: void 0 });
            d = A({}, d, { value: void 0 });
            f = [];
            break;
          case "textarea":
            e = gb(a, e);
            d = gb(a, d);
            f = [];
            break;
          default:
            "function" !== typeof e.onClick && "function" === typeof d.onClick && (a.onclick = Bf);
        }
        ub(c, d);
        var g;
        c = null;
        for (l in e) if (!d.hasOwnProperty(l) && e.hasOwnProperty(l) && null != e[l]) if ("style" === l) {
          var h = e[l];
          for (g in h) h.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
        } else "dangerouslySetInnerHTML" !== l && "children" !== l && "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && "autoFocus" !== l && (ea.hasOwnProperty(l) ? f || (f = []) : (f = f || []).push(l, null));
        for (l in d) {
          var k = d[l];
          h = null != e ? e[l] : void 0;
          if (d.hasOwnProperty(l) && k !== h && (null != k || null != h)) if ("style" === l) if (h) {
            for (g in h) !h.hasOwnProperty(g) || k && k.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
            for (g in k) k.hasOwnProperty(g) && h[g] !== k[g] && (c || (c = {}), c[g] = k[g]);
          } else c || (f || (f = []), f.push(
            l,
            c
          )), c = k;
          else "dangerouslySetInnerHTML" === l ? (k = k ? k.__html : void 0, h = h ? h.__html : void 0, null != k && h !== k && (f = f || []).push(l, k)) : "children" === l ? "string" !== typeof k && "number" !== typeof k || (f = f || []).push(l, "" + k) : "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && (ea.hasOwnProperty(l) ? (null != k && "onScroll" === l && D("scroll", a), f || h === k || (f = [])) : (f = f || []).push(l, k));
        }
        c && (f = f || []).push("style", c);
        var l = f;
        if (b.updateQueue = l) b.flags |= 4;
      }
    };
    Cj = function(a, b, c, d) {
      c !== d && (b.flags |= 4);
    };
    function Dj(a, b) {
      if (!I) switch (a.tailMode) {
        case "hidden":
          b = a.tail;
          for (var c = null; null !== b; ) null !== b.alternate && (c = b), b = b.sibling;
          null === c ? a.tail = null : c.sibling = null;
          break;
        case "collapsed":
          c = a.tail;
          for (var d = null; null !== c; ) null !== c.alternate && (d = c), c = c.sibling;
          null === d ? b || null === a.tail ? a.tail = null : a.tail.sibling = null : d.sibling = null;
      }
    }
    function S(a) {
      var b = null !== a.alternate && a.alternate.child === a.child, c = 0, d = 0;
      if (b) for (var e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags & 14680064, d |= e.flags & 14680064, e.return = a, e = e.sibling;
      else for (e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags, d |= e.flags, e.return = a, e = e.sibling;
      a.subtreeFlags |= d;
      a.childLanes = c;
      return b;
    }
    function Ej(a, b, c) {
      var d = b.pendingProps;
      wg(b);
      switch (b.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return S(b), null;
        case 1:
          return Zf(b.type) && $f(), S(b), null;
        case 3:
          d = b.stateNode;
          zh();
          E(Wf);
          E(H);
          Eh();
          d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
          if (null === a || null === a.child) Gg(b) ? b.flags |= 4 : null === a || a.memoizedState.isDehydrated && 0 === (b.flags & 256) || (b.flags |= 1024, null !== zg && (Fj(zg), zg = null));
          Aj(a, b);
          S(b);
          return null;
        case 5:
          Bh(b);
          var e = xh(wh.current);
          c = b.type;
          if (null !== a && null != b.stateNode) Bj(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 512, b.flags |= 2097152);
          else {
            if (!d) {
              if (null === b.stateNode) throw Error(p(166));
              S(b);
              return null;
            }
            a = xh(uh.current);
            if (Gg(b)) {
              d = b.stateNode;
              c = b.type;
              var f = b.memoizedProps;
              d[Of] = b;
              d[Pf] = f;
              a = 0 !== (b.mode & 1);
              switch (c) {
                case "dialog":
                  D("cancel", d);
                  D("close", d);
                  break;
                case "iframe":
                case "object":
                case "embed":
                  D("load", d);
                  break;
                case "video":
                case "audio":
                  for (e = 0; e < lf.length; e++) D(lf[e], d);
                  break;
                case "source":
                  D("error", d);
                  break;
                case "img":
                case "image":
                case "link":
                  D(
                    "error",
                    d
                  );
                  D("load", d);
                  break;
                case "details":
                  D("toggle", d);
                  break;
                case "input":
                  Za(d, f);
                  D("invalid", d);
                  break;
                case "select":
                  d._wrapperState = { wasMultiple: !!f.multiple };
                  D("invalid", d);
                  break;
                case "textarea":
                  hb(d, f), D("invalid", d);
              }
              ub(c, f);
              e = null;
              for (var g in f) if (f.hasOwnProperty(g)) {
                var h = f[g];
                "children" === g ? "string" === typeof h ? d.textContent !== h && (true !== f.suppressHydrationWarning && Af(d.textContent, h, a), e = ["children", h]) : "number" === typeof h && d.textContent !== "" + h && (true !== f.suppressHydrationWarning && Af(
                  d.textContent,
                  h,
                  a
                ), e = ["children", "" + h]) : ea.hasOwnProperty(g) && null != h && "onScroll" === g && D("scroll", d);
              }
              switch (c) {
                case "input":
                  Va(d);
                  db(d, f, true);
                  break;
                case "textarea":
                  Va(d);
                  jb(d);
                  break;
                case "select":
                case "option":
                  break;
                default:
                  "function" === typeof f.onClick && (d.onclick = Bf);
              }
              d = e;
              b.updateQueue = d;
              null !== d && (b.flags |= 4);
            } else {
              g = 9 === e.nodeType ? e : e.ownerDocument;
              "http://www.w3.org/1999/xhtml" === a && (a = kb(c));
              "http://www.w3.org/1999/xhtml" === a ? "script" === c ? (a = g.createElement("div"), a.innerHTML = "<script><\/script>", a = a.removeChild(a.firstChild)) : "string" === typeof d.is ? a = g.createElement(c, { is: d.is }) : (a = g.createElement(c), "select" === c && (g = a, d.multiple ? g.multiple = true : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
              a[Of] = b;
              a[Pf] = d;
              zj(a, b, false, false);
              b.stateNode = a;
              a: {
                g = vb(c, d);
                switch (c) {
                  case "dialog":
                    D("cancel", a);
                    D("close", a);
                    e = d;
                    break;
                  case "iframe":
                  case "object":
                  case "embed":
                    D("load", a);
                    e = d;
                    break;
                  case "video":
                  case "audio":
                    for (e = 0; e < lf.length; e++) D(lf[e], a);
                    e = d;
                    break;
                  case "source":
                    D("error", a);
                    e = d;
                    break;
                  case "img":
                  case "image":
                  case "link":
                    D(
                      "error",
                      a
                    );
                    D("load", a);
                    e = d;
                    break;
                  case "details":
                    D("toggle", a);
                    e = d;
                    break;
                  case "input":
                    Za(a, d);
                    e = Ya(a, d);
                    D("invalid", a);
                    break;
                  case "option":
                    e = d;
                    break;
                  case "select":
                    a._wrapperState = { wasMultiple: !!d.multiple };
                    e = A({}, d, { value: void 0 });
                    D("invalid", a);
                    break;
                  case "textarea":
                    hb(a, d);
                    e = gb(a, d);
                    D("invalid", a);
                    break;
                  default:
                    e = d;
                }
                ub(c, e);
                h = e;
                for (f in h) if (h.hasOwnProperty(f)) {
                  var k = h[f];
                  "style" === f ? sb(a, k) : "dangerouslySetInnerHTML" === f ? (k = k ? k.__html : void 0, null != k && nb(a, k)) : "children" === f ? "string" === typeof k ? ("textarea" !== c || "" !== k) && ob(a, k) : "number" === typeof k && ob(a, "" + k) : "suppressContentEditableWarning" !== f && "suppressHydrationWarning" !== f && "autoFocus" !== f && (ea.hasOwnProperty(f) ? null != k && "onScroll" === f && D("scroll", a) : null != k && ta(a, f, k, g));
                }
                switch (c) {
                  case "input":
                    Va(a);
                    db(a, d, false);
                    break;
                  case "textarea":
                    Va(a);
                    jb(a);
                    break;
                  case "option":
                    null != d.value && a.setAttribute("value", "" + Sa(d.value));
                    break;
                  case "select":
                    a.multiple = !!d.multiple;
                    f = d.value;
                    null != f ? fb(a, !!d.multiple, f, false) : null != d.defaultValue && fb(
                      a,
                      !!d.multiple,
                      d.defaultValue,
                      true
                    );
                    break;
                  default:
                    "function" === typeof e.onClick && (a.onclick = Bf);
                }
                switch (c) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    d = !!d.autoFocus;
                    break a;
                  case "img":
                    d = true;
                    break a;
                  default:
                    d = false;
                }
              }
              d && (b.flags |= 4);
            }
            null !== b.ref && (b.flags |= 512, b.flags |= 2097152);
          }
          S(b);
          return null;
        case 6:
          if (a && null != b.stateNode) Cj(a, b, a.memoizedProps, d);
          else {
            if ("string" !== typeof d && null === b.stateNode) throw Error(p(166));
            c = xh(wh.current);
            xh(uh.current);
            if (Gg(b)) {
              d = b.stateNode;
              c = b.memoizedProps;
              d[Of] = b;
              if (f = d.nodeValue !== c) {
                if (a = xg, null !== a) switch (a.tag) {
                  case 3:
                    Af(d.nodeValue, c, 0 !== (a.mode & 1));
                    break;
                  case 5:
                    true !== a.memoizedProps.suppressHydrationWarning && Af(d.nodeValue, c, 0 !== (a.mode & 1));
                }
              }
              f && (b.flags |= 4);
            } else d = (9 === c.nodeType ? c : c.ownerDocument).createTextNode(d), d[Of] = b, b.stateNode = d;
          }
          S(b);
          return null;
        case 13:
          E(L);
          d = b.memoizedState;
          if (null === a || null !== a.memoizedState && null !== a.memoizedState.dehydrated) {
            if (I && null !== yg && 0 !== (b.mode & 1) && 0 === (b.flags & 128)) Hg(), Ig(), b.flags |= 98560, f = false;
            else if (f = Gg(b), null !== d && null !== d.dehydrated) {
              if (null === a) {
                if (!f) throw Error(p(318));
                f = b.memoizedState;
                f = null !== f ? f.dehydrated : null;
                if (!f) throw Error(p(317));
                f[Of] = b;
              } else Ig(), 0 === (b.flags & 128) && (b.memoizedState = null), b.flags |= 4;
              S(b);
              f = false;
            } else null !== zg && (Fj(zg), zg = null), f = true;
            if (!f) return b.flags & 65536 ? b : null;
          }
          if (0 !== (b.flags & 128)) return b.lanes = c, b;
          d = null !== d;
          d !== (null !== a && null !== a.memoizedState) && d && (b.child.flags |= 8192, 0 !== (b.mode & 1) && (null === a || 0 !== (L.current & 1) ? 0 === T && (T = 3) : tj()));
          null !== b.updateQueue && (b.flags |= 4);
          S(b);
          return null;
        case 4:
          return zh(), Aj(a, b), null === a && sf(b.stateNode.containerInfo), S(b), null;
        case 10:
          return ah(b.type._context), S(b), null;
        case 17:
          return Zf(b.type) && $f(), S(b), null;
        case 19:
          E(L);
          f = b.memoizedState;
          if (null === f) return S(b), null;
          d = 0 !== (b.flags & 128);
          g = f.rendering;
          if (null === g) if (d) Dj(f, false);
          else {
            if (0 !== T || null !== a && 0 !== (a.flags & 128)) for (a = b.child; null !== a; ) {
              g = Ch(a);
              if (null !== g) {
                b.flags |= 128;
                Dj(f, false);
                d = g.updateQueue;
                null !== d && (b.updateQueue = d, b.flags |= 4);
                b.subtreeFlags = 0;
                d = c;
                for (c = b.child; null !== c; ) f = c, a = d, f.flags &= 14680066, g = f.alternate, null === g ? (f.childLanes = 0, f.lanes = a, f.child = null, f.subtreeFlags = 0, f.memoizedProps = null, f.memoizedState = null, f.updateQueue = null, f.dependencies = null, f.stateNode = null) : (f.childLanes = g.childLanes, f.lanes = g.lanes, f.child = g.child, f.subtreeFlags = 0, f.deletions = null, f.memoizedProps = g.memoizedProps, f.memoizedState = g.memoizedState, f.updateQueue = g.updateQueue, f.type = g.type, a = g.dependencies, f.dependencies = null === a ? null : { lanes: a.lanes, firstContext: a.firstContext }), c = c.sibling;
                G(L, L.current & 1 | 2);
                return b.child;
              }
              a = a.sibling;
            }
            null !== f.tail && B() > Gj && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
          }
          else {
            if (!d) if (a = Ch(g), null !== a) {
              if (b.flags |= 128, d = true, c = a.updateQueue, null !== c && (b.updateQueue = c, b.flags |= 4), Dj(f, true), null === f.tail && "hidden" === f.tailMode && !g.alternate && !I) return S(b), null;
            } else 2 * B() - f.renderingStartTime > Gj && 1073741824 !== c && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
            f.isBackwards ? (g.sibling = b.child, b.child = g) : (c = f.last, null !== c ? c.sibling = g : b.child = g, f.last = g);
          }
          if (null !== f.tail) return b = f.tail, f.rendering = b, f.tail = b.sibling, f.renderingStartTime = B(), b.sibling = null, c = L.current, G(L, d ? c & 1 | 2 : c & 1), b;
          S(b);
          return null;
        case 22:
        case 23:
          return Hj(), d = null !== b.memoizedState, null !== a && null !== a.memoizedState !== d && (b.flags |= 8192), d && 0 !== (b.mode & 1) ? 0 !== (fj & 1073741824) && (S(b), b.subtreeFlags & 6 && (b.flags |= 8192)) : S(b), null;
        case 24:
          return null;
        case 25:
          return null;
      }
      throw Error(p(156, b.tag));
    }
    function Ij(a, b) {
      wg(b);
      switch (b.tag) {
        case 1:
          return Zf(b.type) && $f(), a = b.flags, a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
        case 3:
          return zh(), E(Wf), E(H), Eh(), a = b.flags, 0 !== (a & 65536) && 0 === (a & 128) ? (b.flags = a & -65537 | 128, b) : null;
        case 5:
          return Bh(b), null;
        case 13:
          E(L);
          a = b.memoizedState;
          if (null !== a && null !== a.dehydrated) {
            if (null === b.alternate) throw Error(p(340));
            Ig();
          }
          a = b.flags;
          return a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
        case 19:
          return E(L), null;
        case 4:
          return zh(), null;
        case 10:
          return ah(b.type._context), null;
        case 22:
        case 23:
          return Hj(), null;
        case 24:
          return null;
        default:
          return null;
      }
    }
    var Jj = false, U = false, Kj = "function" === typeof WeakSet ? WeakSet : Set, V = null;
    function Lj(a, b) {
      var c = a.ref;
      if (null !== c) if ("function" === typeof c) try {
        c(null);
      } catch (d) {
        W(a, b, d);
      }
      else c.current = null;
    }
    function Mj(a, b, c) {
      try {
        c();
      } catch (d) {
        W(a, b, d);
      }
    }
    var Nj = false;
    function Oj(a, b) {
      Cf = dd;
      a = Me();
      if (Ne(a)) {
        if ("selectionStart" in a) var c = { start: a.selectionStart, end: a.selectionEnd };
        else a: {
          c = (c = a.ownerDocument) && c.defaultView || window;
          var d = c.getSelection && c.getSelection();
          if (d && 0 !== d.rangeCount) {
            c = d.anchorNode;
            var e = d.anchorOffset, f = d.focusNode;
            d = d.focusOffset;
            try {
              c.nodeType, f.nodeType;
            } catch (F) {
              c = null;
              break a;
            }
            var g = 0, h = -1, k = -1, l = 0, m = 0, q = a, r = null;
            b: for (; ; ) {
              for (var y; ; ) {
                q !== c || 0 !== e && 3 !== q.nodeType || (h = g + e);
                q !== f || 0 !== d && 3 !== q.nodeType || (k = g + d);
                3 === q.nodeType && (g += q.nodeValue.length);
                if (null === (y = q.firstChild)) break;
                r = q;
                q = y;
              }
              for (; ; ) {
                if (q === a) break b;
                r === c && ++l === e && (h = g);
                r === f && ++m === d && (k = g);
                if (null !== (y = q.nextSibling)) break;
                q = r;
                r = q.parentNode;
              }
              q = y;
            }
            c = -1 === h || -1 === k ? null : { start: h, end: k };
          } else c = null;
        }
        c = c || { start: 0, end: 0 };
      } else c = null;
      Df = { focusedElem: a, selectionRange: c };
      dd = false;
      for (V = b; null !== V; ) if (b = V, a = b.child, 0 !== (b.subtreeFlags & 1028) && null !== a) a.return = b, V = a;
      else for (; null !== V; ) {
        b = V;
        try {
          var n = b.alternate;
          if (0 !== (b.flags & 1024)) switch (b.tag) {
            case 0:
            case 11:
            case 15:
              break;
            case 1:
              if (null !== n) {
                var t2 = n.memoizedProps, J = n.memoizedState, x = b.stateNode, w = x.getSnapshotBeforeUpdate(b.elementType === b.type ? t2 : Ci(b.type, t2), J);
                x.__reactInternalSnapshotBeforeUpdate = w;
              }
              break;
            case 3:
              var u = b.stateNode.containerInfo;
              1 === u.nodeType ? u.textContent = "" : 9 === u.nodeType && u.documentElement && u.removeChild(u.documentElement);
              break;
            case 5:
            case 6:
            case 4:
            case 17:
              break;
            default:
              throw Error(p(163));
          }
        } catch (F) {
          W(b, b.return, F);
        }
        a = b.sibling;
        if (null !== a) {
          a.return = b.return;
          V = a;
          break;
        }
        V = b.return;
      }
      n = Nj;
      Nj = false;
      return n;
    }
    function Pj(a, b, c) {
      var d = b.updateQueue;
      d = null !== d ? d.lastEffect : null;
      if (null !== d) {
        var e = d = d.next;
        do {
          if ((e.tag & a) === a) {
            var f = e.destroy;
            e.destroy = void 0;
            void 0 !== f && Mj(b, c, f);
          }
          e = e.next;
        } while (e !== d);
      }
    }
    function Qj(a, b) {
      b = b.updateQueue;
      b = null !== b ? b.lastEffect : null;
      if (null !== b) {
        var c = b = b.next;
        do {
          if ((c.tag & a) === a) {
            var d = c.create;
            c.destroy = d();
          }
          c = c.next;
        } while (c !== b);
      }
    }
    function Rj(a) {
      var b = a.ref;
      if (null !== b) {
        var c = a.stateNode;
        switch (a.tag) {
          case 5:
            a = c;
            break;
          default:
            a = c;
        }
        "function" === typeof b ? b(a) : b.current = a;
      }
    }
    function Sj(a) {
      var b = a.alternate;
      null !== b && (a.alternate = null, Sj(b));
      a.child = null;
      a.deletions = null;
      a.sibling = null;
      5 === a.tag && (b = a.stateNode, null !== b && (delete b[Of], delete b[Pf], delete b[of], delete b[Qf], delete b[Rf]));
      a.stateNode = null;
      a.return = null;
      a.dependencies = null;
      a.memoizedProps = null;
      a.memoizedState = null;
      a.pendingProps = null;
      a.stateNode = null;
      a.updateQueue = null;
    }
    function Tj(a) {
      return 5 === a.tag || 3 === a.tag || 4 === a.tag;
    }
    function Uj(a) {
      a: for (; ; ) {
        for (; null === a.sibling; ) {
          if (null === a.return || Tj(a.return)) return null;
          a = a.return;
        }
        a.sibling.return = a.return;
        for (a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag; ) {
          if (a.flags & 2) continue a;
          if (null === a.child || 4 === a.tag) continue a;
          else a.child.return = a, a = a.child;
        }
        if (!(a.flags & 2)) return a.stateNode;
      }
    }
    function Vj(a, b, c) {
      var d = a.tag;
      if (5 === d || 6 === d) a = a.stateNode, b ? 8 === c.nodeType ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (8 === c.nodeType ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, null !== c && void 0 !== c || null !== b.onclick || (b.onclick = Bf));
      else if (4 !== d && (a = a.child, null !== a)) for (Vj(a, b, c), a = a.sibling; null !== a; ) Vj(a, b, c), a = a.sibling;
    }
    function Wj(a, b, c) {
      var d = a.tag;
      if (5 === d || 6 === d) a = a.stateNode, b ? c.insertBefore(a, b) : c.appendChild(a);
      else if (4 !== d && (a = a.child, null !== a)) for (Wj(a, b, c), a = a.sibling; null !== a; ) Wj(a, b, c), a = a.sibling;
    }
    var X = null, Xj = false;
    function Yj(a, b, c) {
      for (c = c.child; null !== c; ) Zj(a, b, c), c = c.sibling;
    }
    function Zj(a, b, c) {
      if (lc && "function" === typeof lc.onCommitFiberUnmount) try {
        lc.onCommitFiberUnmount(kc, c);
      } catch (h) {
      }
      switch (c.tag) {
        case 5:
          U || Lj(c, b);
        case 6:
          var d = X, e = Xj;
          X = null;
          Yj(a, b, c);
          X = d;
          Xj = e;
          null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? a.parentNode.removeChild(c) : a.removeChild(c)) : X.removeChild(c.stateNode));
          break;
        case 18:
          null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? Kf(a.parentNode, c) : 1 === a.nodeType && Kf(a, c), bd(a)) : Kf(X, c.stateNode));
          break;
        case 4:
          d = X;
          e = Xj;
          X = c.stateNode.containerInfo;
          Xj = true;
          Yj(a, b, c);
          X = d;
          Xj = e;
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          if (!U && (d = c.updateQueue, null !== d && (d = d.lastEffect, null !== d))) {
            e = d = d.next;
            do {
              var f = e, g = f.destroy;
              f = f.tag;
              void 0 !== g && (0 !== (f & 2) ? Mj(c, b, g) : 0 !== (f & 4) && Mj(c, b, g));
              e = e.next;
            } while (e !== d);
          }
          Yj(a, b, c);
          break;
        case 1:
          if (!U && (Lj(c, b), d = c.stateNode, "function" === typeof d.componentWillUnmount)) try {
            d.props = c.memoizedProps, d.state = c.memoizedState, d.componentWillUnmount();
          } catch (h) {
            W(c, b, h);
          }
          Yj(a, b, c);
          break;
        case 21:
          Yj(a, b, c);
          break;
        case 22:
          c.mode & 1 ? (U = (d = U) || null !== c.memoizedState, Yj(a, b, c), U = d) : Yj(a, b, c);
          break;
        default:
          Yj(a, b, c);
      }
    }
    function ak(a) {
      var b = a.updateQueue;
      if (null !== b) {
        a.updateQueue = null;
        var c = a.stateNode;
        null === c && (c = a.stateNode = new Kj());
        b.forEach(function(b2) {
          var d = bk.bind(null, a, b2);
          c.has(b2) || (c.add(b2), b2.then(d, d));
        });
      }
    }
    function ck(a, b) {
      var c = b.deletions;
      if (null !== c) for (var d = 0; d < c.length; d++) {
        var e = c[d];
        try {
          var f = a, g = b, h = g;
          a: for (; null !== h; ) {
            switch (h.tag) {
              case 5:
                X = h.stateNode;
                Xj = false;
                break a;
              case 3:
                X = h.stateNode.containerInfo;
                Xj = true;
                break a;
              case 4:
                X = h.stateNode.containerInfo;
                Xj = true;
                break a;
            }
            h = h.return;
          }
          if (null === X) throw Error(p(160));
          Zj(f, g, e);
          X = null;
          Xj = false;
          var k = e.alternate;
          null !== k && (k.return = null);
          e.return = null;
        } catch (l) {
          W(e, b, l);
        }
      }
      if (b.subtreeFlags & 12854) for (b = b.child; null !== b; ) dk(b, a), b = b.sibling;
    }
    function dk(a, b) {
      var c = a.alternate, d = a.flags;
      switch (a.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          ck(b, a);
          ek(a);
          if (d & 4) {
            try {
              Pj(3, a, a.return), Qj(3, a);
            } catch (t2) {
              W(a, a.return, t2);
            }
            try {
              Pj(5, a, a.return);
            } catch (t2) {
              W(a, a.return, t2);
            }
          }
          break;
        case 1:
          ck(b, a);
          ek(a);
          d & 512 && null !== c && Lj(c, c.return);
          break;
        case 5:
          ck(b, a);
          ek(a);
          d & 512 && null !== c && Lj(c, c.return);
          if (a.flags & 32) {
            var e = a.stateNode;
            try {
              ob(e, "");
            } catch (t2) {
              W(a, a.return, t2);
            }
          }
          if (d & 4 && (e = a.stateNode, null != e)) {
            var f = a.memoizedProps, g = null !== c ? c.memoizedProps : f, h = a.type, k = a.updateQueue;
            a.updateQueue = null;
            if (null !== k) try {
              "input" === h && "radio" === f.type && null != f.name && ab(e, f);
              vb(h, g);
              var l = vb(h, f);
              for (g = 0; g < k.length; g += 2) {
                var m = k[g], q = k[g + 1];
                "style" === m ? sb(e, q) : "dangerouslySetInnerHTML" === m ? nb(e, q) : "children" === m ? ob(e, q) : ta(e, m, q, l);
              }
              switch (h) {
                case "input":
                  bb(e, f);
                  break;
                case "textarea":
                  ib(e, f);
                  break;
                case "select":
                  var r = e._wrapperState.wasMultiple;
                  e._wrapperState.wasMultiple = !!f.multiple;
                  var y = f.value;
                  null != y ? fb(e, !!f.multiple, y, false) : r !== !!f.multiple && (null != f.defaultValue ? fb(
                    e,
                    !!f.multiple,
                    f.defaultValue,
                    true
                  ) : fb(e, !!f.multiple, f.multiple ? [] : "", false));
              }
              e[Pf] = f;
            } catch (t2) {
              W(a, a.return, t2);
            }
          }
          break;
        case 6:
          ck(b, a);
          ek(a);
          if (d & 4) {
            if (null === a.stateNode) throw Error(p(162));
            e = a.stateNode;
            f = a.memoizedProps;
            try {
              e.nodeValue = f;
            } catch (t2) {
              W(a, a.return, t2);
            }
          }
          break;
        case 3:
          ck(b, a);
          ek(a);
          if (d & 4 && null !== c && c.memoizedState.isDehydrated) try {
            bd(b.containerInfo);
          } catch (t2) {
            W(a, a.return, t2);
          }
          break;
        case 4:
          ck(b, a);
          ek(a);
          break;
        case 13:
          ck(b, a);
          ek(a);
          e = a.child;
          e.flags & 8192 && (f = null !== e.memoizedState, e.stateNode.isHidden = f, !f || null !== e.alternate && null !== e.alternate.memoizedState || (fk = B()));
          d & 4 && ak(a);
          break;
        case 22:
          m = null !== c && null !== c.memoizedState;
          a.mode & 1 ? (U = (l = U) || m, ck(b, a), U = l) : ck(b, a);
          ek(a);
          if (d & 8192) {
            l = null !== a.memoizedState;
            if ((a.stateNode.isHidden = l) && !m && 0 !== (a.mode & 1)) for (V = a, m = a.child; null !== m; ) {
              for (q = V = m; null !== V; ) {
                r = V;
                y = r.child;
                switch (r.tag) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Pj(4, r, r.return);
                    break;
                  case 1:
                    Lj(r, r.return);
                    var n = r.stateNode;
                    if ("function" === typeof n.componentWillUnmount) {
                      d = r;
                      c = r.return;
                      try {
                        b = d, n.props = b.memoizedProps, n.state = b.memoizedState, n.componentWillUnmount();
                      } catch (t2) {
                        W(d, c, t2);
                      }
                    }
                    break;
                  case 5:
                    Lj(r, r.return);
                    break;
                  case 22:
                    if (null !== r.memoizedState) {
                      gk(q);
                      continue;
                    }
                }
                null !== y ? (y.return = r, V = y) : gk(q);
              }
              m = m.sibling;
            }
            a: for (m = null, q = a; ; ) {
              if (5 === q.tag) {
                if (null === m) {
                  m = q;
                  try {
                    e = q.stateNode, l ? (f = e.style, "function" === typeof f.setProperty ? f.setProperty("display", "none", "important") : f.display = "none") : (h = q.stateNode, k = q.memoizedProps.style, g = void 0 !== k && null !== k && k.hasOwnProperty("display") ? k.display : null, h.style.display = rb("display", g));
                  } catch (t2) {
                    W(a, a.return, t2);
                  }
                }
              } else if (6 === q.tag) {
                if (null === m) try {
                  q.stateNode.nodeValue = l ? "" : q.memoizedProps;
                } catch (t2) {
                  W(a, a.return, t2);
                }
              } else if ((22 !== q.tag && 23 !== q.tag || null === q.memoizedState || q === a) && null !== q.child) {
                q.child.return = q;
                q = q.child;
                continue;
              }
              if (q === a) break a;
              for (; null === q.sibling; ) {
                if (null === q.return || q.return === a) break a;
                m === q && (m = null);
                q = q.return;
              }
              m === q && (m = null);
              q.sibling.return = q.return;
              q = q.sibling;
            }
          }
          break;
        case 19:
          ck(b, a);
          ek(a);
          d & 4 && ak(a);
          break;
        case 21:
          break;
        default:
          ck(
            b,
            a
          ), ek(a);
      }
    }
    function ek(a) {
      var b = a.flags;
      if (b & 2) {
        try {
          a: {
            for (var c = a.return; null !== c; ) {
              if (Tj(c)) {
                var d = c;
                break a;
              }
              c = c.return;
            }
            throw Error(p(160));
          }
          switch (d.tag) {
            case 5:
              var e = d.stateNode;
              d.flags & 32 && (ob(e, ""), d.flags &= -33);
              var f = Uj(a);
              Wj(a, f, e);
              break;
            case 3:
            case 4:
              var g = d.stateNode.containerInfo, h = Uj(a);
              Vj(a, h, g);
              break;
            default:
              throw Error(p(161));
          }
        } catch (k) {
          W(a, a.return, k);
        }
        a.flags &= -3;
      }
      b & 4096 && (a.flags &= -4097);
    }
    function hk(a, b, c) {
      V = a;
      ik(a);
    }
    function ik(a, b, c) {
      for (var d = 0 !== (a.mode & 1); null !== V; ) {
        var e = V, f = e.child;
        if (22 === e.tag && d) {
          var g = null !== e.memoizedState || Jj;
          if (!g) {
            var h = e.alternate, k = null !== h && null !== h.memoizedState || U;
            h = Jj;
            var l = U;
            Jj = g;
            if ((U = k) && !l) for (V = e; null !== V; ) g = V, k = g.child, 22 === g.tag && null !== g.memoizedState ? jk(e) : null !== k ? (k.return = g, V = k) : jk(e);
            for (; null !== f; ) V = f, ik(f), f = f.sibling;
            V = e;
            Jj = h;
            U = l;
          }
          kk(a);
        } else 0 !== (e.subtreeFlags & 8772) && null !== f ? (f.return = e, V = f) : kk(a);
      }
    }
    function kk(a) {
      for (; null !== V; ) {
        var b = V;
        if (0 !== (b.flags & 8772)) {
          var c = b.alternate;
          try {
            if (0 !== (b.flags & 8772)) switch (b.tag) {
              case 0:
              case 11:
              case 15:
                U || Qj(5, b);
                break;
              case 1:
                var d = b.stateNode;
                if (b.flags & 4 && !U) if (null === c) d.componentDidMount();
                else {
                  var e = b.elementType === b.type ? c.memoizedProps : Ci(b.type, c.memoizedProps);
                  d.componentDidUpdate(e, c.memoizedState, d.__reactInternalSnapshotBeforeUpdate);
                }
                var f = b.updateQueue;
                null !== f && sh(b, f, d);
                break;
              case 3:
                var g = b.updateQueue;
                if (null !== g) {
                  c = null;
                  if (null !== b.child) switch (b.child.tag) {
                    case 5:
                      c = b.child.stateNode;
                      break;
                    case 1:
                      c = b.child.stateNode;
                  }
                  sh(b, g, c);
                }
                break;
              case 5:
                var h = b.stateNode;
                if (null === c && b.flags & 4) {
                  c = h;
                  var k = b.memoizedProps;
                  switch (b.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      k.autoFocus && c.focus();
                      break;
                    case "img":
                      k.src && (c.src = k.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (null === b.memoizedState) {
                  var l = b.alternate;
                  if (null !== l) {
                    var m = l.memoizedState;
                    if (null !== m) {
                      var q = m.dehydrated;
                      null !== q && bd(q);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(p(163));
            }
            U || b.flags & 512 && Rj(b);
          } catch (r) {
            W(b, b.return, r);
          }
        }
        if (b === a) {
          V = null;
          break;
        }
        c = b.sibling;
        if (null !== c) {
          c.return = b.return;
          V = c;
          break;
        }
        V = b.return;
      }
    }
    function gk(a) {
      for (; null !== V; ) {
        var b = V;
        if (b === a) {
          V = null;
          break;
        }
        var c = b.sibling;
        if (null !== c) {
          c.return = b.return;
          V = c;
          break;
        }
        V = b.return;
      }
    }
    function jk(a) {
      for (; null !== V; ) {
        var b = V;
        try {
          switch (b.tag) {
            case 0:
            case 11:
            case 15:
              var c = b.return;
              try {
                Qj(4, b);
              } catch (k) {
                W(b, c, k);
              }
              break;
            case 1:
              var d = b.stateNode;
              if ("function" === typeof d.componentDidMount) {
                var e = b.return;
                try {
                  d.componentDidMount();
                } catch (k) {
                  W(b, e, k);
                }
              }
              var f = b.return;
              try {
                Rj(b);
              } catch (k) {
                W(b, f, k);
              }
              break;
            case 5:
              var g = b.return;
              try {
                Rj(b);
              } catch (k) {
                W(b, g, k);
              }
          }
        } catch (k) {
          W(b, b.return, k);
        }
        if (b === a) {
          V = null;
          break;
        }
        var h = b.sibling;
        if (null !== h) {
          h.return = b.return;
          V = h;
          break;
        }
        V = b.return;
      }
    }
    var lk = Math.ceil, mk = ua.ReactCurrentDispatcher, nk = ua.ReactCurrentOwner, ok = ua.ReactCurrentBatchConfig, K = 0, Q = null, Y = null, Z = 0, fj = 0, ej = Uf(0), T = 0, pk = null, rh = 0, qk = 0, rk = 0, sk = null, tk = null, fk = 0, Gj = Infinity, uk = null, Oi = false, Pi = null, Ri = null, vk = false, wk = null, xk = 0, yk = 0, zk = null, Ak = -1, Bk = 0;
    function R() {
      return 0 !== (K & 6) ? B() : -1 !== Ak ? Ak : Ak = B();
    }
    function yi(a) {
      if (0 === (a.mode & 1)) return 1;
      if (0 !== (K & 2) && 0 !== Z) return Z & -Z;
      if (null !== Kg.transition) return 0 === Bk && (Bk = yc()), Bk;
      a = C;
      if (0 !== a) return a;
      a = window.event;
      a = void 0 === a ? 16 : jd(a.type);
      return a;
    }
    function gi(a, b, c, d) {
      if (50 < yk) throw yk = 0, zk = null, Error(p(185));
      Ac(a, c, d);
      if (0 === (K & 2) || a !== Q) a === Q && (0 === (K & 2) && (qk |= c), 4 === T && Ck(a, Z)), Dk(a, d), 1 === c && 0 === K && 0 === (b.mode & 1) && (Gj = B() + 500, fg && jg());
    }
    function Dk(a, b) {
      var c = a.callbackNode;
      wc(a, b);
      var d = uc(a, a === Q ? Z : 0);
      if (0 === d) null !== c && bc(c), a.callbackNode = null, a.callbackPriority = 0;
      else if (b = d & -d, a.callbackPriority !== b) {
        null != c && bc(c);
        if (1 === b) 0 === a.tag ? ig(Ek.bind(null, a)) : hg(Ek.bind(null, a)), Jf(function() {
          0 === (K & 6) && jg();
        }), c = null;
        else {
          switch (Dc(d)) {
            case 1:
              c = fc;
              break;
            case 4:
              c = gc;
              break;
            case 16:
              c = hc;
              break;
            case 536870912:
              c = jc;
              break;
            default:
              c = hc;
          }
          c = Fk(c, Gk.bind(null, a));
        }
        a.callbackPriority = b;
        a.callbackNode = c;
      }
    }
    function Gk(a, b) {
      Ak = -1;
      Bk = 0;
      if (0 !== (K & 6)) throw Error(p(327));
      var c = a.callbackNode;
      if (Hk() && a.callbackNode !== c) return null;
      var d = uc(a, a === Q ? Z : 0);
      if (0 === d) return null;
      if (0 !== (d & 30) || 0 !== (d & a.expiredLanes) || b) b = Ik(a, d);
      else {
        b = d;
        var e = K;
        K |= 2;
        var f = Jk();
        if (Q !== a || Z !== b) uk = null, Gj = B() + 500, Kk(a, b);
        do
          try {
            Lk();
            break;
          } catch (h) {
            Mk(a, h);
          }
        while (1);
        $g();
        mk.current = f;
        K = e;
        null !== Y ? b = 0 : (Q = null, Z = 0, b = T);
      }
      if (0 !== b) {
        2 === b && (e = xc(a), 0 !== e && (d = e, b = Nk(a, e)));
        if (1 === b) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
        if (6 === b) Ck(a, d);
        else {
          e = a.current.alternate;
          if (0 === (d & 30) && !Ok(e) && (b = Ik(a, d), 2 === b && (f = xc(a), 0 !== f && (d = f, b = Nk(a, f))), 1 === b)) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
          a.finishedWork = e;
          a.finishedLanes = d;
          switch (b) {
            case 0:
            case 1:
              throw Error(p(345));
            case 2:
              Pk(a, tk, uk);
              break;
            case 3:
              Ck(a, d);
              if ((d & 130023424) === d && (b = fk + 500 - B(), 10 < b)) {
                if (0 !== uc(a, 0)) break;
                e = a.suspendedLanes;
                if ((e & d) !== d) {
                  R();
                  a.pingedLanes |= a.suspendedLanes & e;
                  break;
                }
                a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), b);
                break;
              }
              Pk(a, tk, uk);
              break;
            case 4:
              Ck(a, d);
              if ((d & 4194240) === d) break;
              b = a.eventTimes;
              for (e = -1; 0 < d; ) {
                var g = 31 - oc(d);
                f = 1 << g;
                g = b[g];
                g > e && (e = g);
                d &= ~f;
              }
              d = e;
              d = B() - d;
              d = (120 > d ? 120 : 480 > d ? 480 : 1080 > d ? 1080 : 1920 > d ? 1920 : 3e3 > d ? 3e3 : 4320 > d ? 4320 : 1960 * lk(d / 1960)) - d;
              if (10 < d) {
                a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), d);
                break;
              }
              Pk(a, tk, uk);
              break;
            case 5:
              Pk(a, tk, uk);
              break;
            default:
              throw Error(p(329));
          }
        }
      }
      Dk(a, B());
      return a.callbackNode === c ? Gk.bind(null, a) : null;
    }
    function Nk(a, b) {
      var c = sk;
      a.current.memoizedState.isDehydrated && (Kk(a, b).flags |= 256);
      a = Ik(a, b);
      2 !== a && (b = tk, tk = c, null !== b && Fj(b));
      return a;
    }
    function Fj(a) {
      null === tk ? tk = a : tk.push.apply(tk, a);
    }
    function Ok(a) {
      for (var b = a; ; ) {
        if (b.flags & 16384) {
          var c = b.updateQueue;
          if (null !== c && (c = c.stores, null !== c)) for (var d = 0; d < c.length; d++) {
            var e = c[d], f = e.getSnapshot;
            e = e.value;
            try {
              if (!He(f(), e)) return false;
            } catch (g) {
              return false;
            }
          }
        }
        c = b.child;
        if (b.subtreeFlags & 16384 && null !== c) c.return = b, b = c;
        else {
          if (b === a) break;
          for (; null === b.sibling; ) {
            if (null === b.return || b.return === a) return true;
            b = b.return;
          }
          b.sibling.return = b.return;
          b = b.sibling;
        }
      }
      return true;
    }
    function Ck(a, b) {
      b &= ~rk;
      b &= ~qk;
      a.suspendedLanes |= b;
      a.pingedLanes &= ~b;
      for (a = a.expirationTimes; 0 < b; ) {
        var c = 31 - oc(b), d = 1 << c;
        a[c] = -1;
        b &= ~d;
      }
    }
    function Ek(a) {
      if (0 !== (K & 6)) throw Error(p(327));
      Hk();
      var b = uc(a, 0);
      if (0 === (b & 1)) return Dk(a, B()), null;
      var c = Ik(a, b);
      if (0 !== a.tag && 2 === c) {
        var d = xc(a);
        0 !== d && (b = d, c = Nk(a, d));
      }
      if (1 === c) throw c = pk, Kk(a, 0), Ck(a, b), Dk(a, B()), c;
      if (6 === c) throw Error(p(345));
      a.finishedWork = a.current.alternate;
      a.finishedLanes = b;
      Pk(a, tk, uk);
      Dk(a, B());
      return null;
    }
    function Qk(a, b) {
      var c = K;
      K |= 1;
      try {
        return a(b);
      } finally {
        K = c, 0 === K && (Gj = B() + 500, fg && jg());
      }
    }
    function Rk(a) {
      null !== wk && 0 === wk.tag && 0 === (K & 6) && Hk();
      var b = K;
      K |= 1;
      var c = ok.transition, d = C;
      try {
        if (ok.transition = null, C = 1, a) return a();
      } finally {
        C = d, ok.transition = c, K = b, 0 === (K & 6) && jg();
      }
    }
    function Hj() {
      fj = ej.current;
      E(ej);
    }
    function Kk(a, b) {
      a.finishedWork = null;
      a.finishedLanes = 0;
      var c = a.timeoutHandle;
      -1 !== c && (a.timeoutHandle = -1, Gf(c));
      if (null !== Y) for (c = Y.return; null !== c; ) {
        var d = c;
        wg(d);
        switch (d.tag) {
          case 1:
            d = d.type.childContextTypes;
            null !== d && void 0 !== d && $f();
            break;
          case 3:
            zh();
            E(Wf);
            E(H);
            Eh();
            break;
          case 5:
            Bh(d);
            break;
          case 4:
            zh();
            break;
          case 13:
            E(L);
            break;
          case 19:
            E(L);
            break;
          case 10:
            ah(d.type._context);
            break;
          case 22:
          case 23:
            Hj();
        }
        c = c.return;
      }
      Q = a;
      Y = a = Pg(a.current, null);
      Z = fj = b;
      T = 0;
      pk = null;
      rk = qk = rh = 0;
      tk = sk = null;
      if (null !== fh) {
        for (b = 0; b < fh.length; b++) if (c = fh[b], d = c.interleaved, null !== d) {
          c.interleaved = null;
          var e = d.next, f = c.pending;
          if (null !== f) {
            var g = f.next;
            f.next = e;
            d.next = g;
          }
          c.pending = d;
        }
        fh = null;
      }
      return a;
    }
    function Mk(a, b) {
      do {
        var c = Y;
        try {
          $g();
          Fh.current = Rh;
          if (Ih) {
            for (var d = M.memoizedState; null !== d; ) {
              var e = d.queue;
              null !== e && (e.pending = null);
              d = d.next;
            }
            Ih = false;
          }
          Hh = 0;
          O = N = M = null;
          Jh = false;
          Kh = 0;
          nk.current = null;
          if (null === c || null === c.return) {
            T = 1;
            pk = b;
            Y = null;
            break;
          }
          a: {
            var f = a, g = c.return, h = c, k = b;
            b = Z;
            h.flags |= 32768;
            if (null !== k && "object" === typeof k && "function" === typeof k.then) {
              var l = k, m = h, q = m.tag;
              if (0 === (m.mode & 1) && (0 === q || 11 === q || 15 === q)) {
                var r = m.alternate;
                r ? (m.updateQueue = r.updateQueue, m.memoizedState = r.memoizedState, m.lanes = r.lanes) : (m.updateQueue = null, m.memoizedState = null);
              }
              var y = Ui(g);
              if (null !== y) {
                y.flags &= -257;
                Vi(y, g, h, f, b);
                y.mode & 1 && Si(f, l, b);
                b = y;
                k = l;
                var n = b.updateQueue;
                if (null === n) {
                  var t2 = /* @__PURE__ */ new Set();
                  t2.add(k);
                  b.updateQueue = t2;
                } else n.add(k);
                break a;
              } else {
                if (0 === (b & 1)) {
                  Si(f, l, b);
                  tj();
                  break a;
                }
                k = Error(p(426));
              }
            } else if (I && h.mode & 1) {
              var J = Ui(g);
              if (null !== J) {
                0 === (J.flags & 65536) && (J.flags |= 256);
                Vi(J, g, h, f, b);
                Jg(Ji(k, h));
                break a;
              }
            }
            f = k = Ji(k, h);
            4 !== T && (T = 2);
            null === sk ? sk = [f] : sk.push(f);
            f = g;
            do {
              switch (f.tag) {
                case 3:
                  f.flags |= 65536;
                  b &= -b;
                  f.lanes |= b;
                  var x = Ni(f, k, b);
                  ph(f, x);
                  break a;
                case 1:
                  h = k;
                  var w = f.type, u = f.stateNode;
                  if (0 === (f.flags & 128) && ("function" === typeof w.getDerivedStateFromError || null !== u && "function" === typeof u.componentDidCatch && (null === Ri || !Ri.has(u)))) {
                    f.flags |= 65536;
                    b &= -b;
                    f.lanes |= b;
                    var F = Qi(f, h, b);
                    ph(f, F);
                    break a;
                  }
              }
              f = f.return;
            } while (null !== f);
          }
          Sk(c);
        } catch (na) {
          b = na;
          Y === c && null !== c && (Y = c = c.return);
          continue;
        }
        break;
      } while (1);
    }
    function Jk() {
      var a = mk.current;
      mk.current = Rh;
      return null === a ? Rh : a;
    }
    function tj() {
      if (0 === T || 3 === T || 2 === T) T = 4;
      null === Q || 0 === (rh & 268435455) && 0 === (qk & 268435455) || Ck(Q, Z);
    }
    function Ik(a, b) {
      var c = K;
      K |= 2;
      var d = Jk();
      if (Q !== a || Z !== b) uk = null, Kk(a, b);
      do
        try {
          Tk();
          break;
        } catch (e) {
          Mk(a, e);
        }
      while (1);
      $g();
      K = c;
      mk.current = d;
      if (null !== Y) throw Error(p(261));
      Q = null;
      Z = 0;
      return T;
    }
    function Tk() {
      for (; null !== Y; ) Uk(Y);
    }
    function Lk() {
      for (; null !== Y && !cc(); ) Uk(Y);
    }
    function Uk(a) {
      var b = Vk(a.alternate, a, fj);
      a.memoizedProps = a.pendingProps;
      null === b ? Sk(a) : Y = b;
      nk.current = null;
    }
    function Sk(a) {
      var b = a;
      do {
        var c = b.alternate;
        a = b.return;
        if (0 === (b.flags & 32768)) {
          if (c = Ej(c, b, fj), null !== c) {
            Y = c;
            return;
          }
        } else {
          c = Ij(c, b);
          if (null !== c) {
            c.flags &= 32767;
            Y = c;
            return;
          }
          if (null !== a) a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
          else {
            T = 6;
            Y = null;
            return;
          }
        }
        b = b.sibling;
        if (null !== b) {
          Y = b;
          return;
        }
        Y = b = a;
      } while (null !== b);
      0 === T && (T = 5);
    }
    function Pk(a, b, c) {
      var d = C, e = ok.transition;
      try {
        ok.transition = null, C = 1, Wk(a, b, c, d);
      } finally {
        ok.transition = e, C = d;
      }
      return null;
    }
    function Wk(a, b, c, d) {
      do
        Hk();
      while (null !== wk);
      if (0 !== (K & 6)) throw Error(p(327));
      c = a.finishedWork;
      var e = a.finishedLanes;
      if (null === c) return null;
      a.finishedWork = null;
      a.finishedLanes = 0;
      if (c === a.current) throw Error(p(177));
      a.callbackNode = null;
      a.callbackPriority = 0;
      var f = c.lanes | c.childLanes;
      Bc(a, f);
      a === Q && (Y = Q = null, Z = 0);
      0 === (c.subtreeFlags & 2064) && 0 === (c.flags & 2064) || vk || (vk = true, Fk(hc, function() {
        Hk();
        return null;
      }));
      f = 0 !== (c.flags & 15990);
      if (0 !== (c.subtreeFlags & 15990) || f) {
        f = ok.transition;
        ok.transition = null;
        var g = C;
        C = 1;
        var h = K;
        K |= 4;
        nk.current = null;
        Oj(a, c);
        dk(c, a);
        Oe(Df);
        dd = !!Cf;
        Df = Cf = null;
        a.current = c;
        hk(c);
        dc();
        K = h;
        C = g;
        ok.transition = f;
      } else a.current = c;
      vk && (vk = false, wk = a, xk = e);
      f = a.pendingLanes;
      0 === f && (Ri = null);
      mc(c.stateNode);
      Dk(a, B());
      if (null !== b) for (d = a.onRecoverableError, c = 0; c < b.length; c++) e = b[c], d(e.value, { componentStack: e.stack, digest: e.digest });
      if (Oi) throw Oi = false, a = Pi, Pi = null, a;
      0 !== (xk & 1) && 0 !== a.tag && Hk();
      f = a.pendingLanes;
      0 !== (f & 1) ? a === zk ? yk++ : (yk = 0, zk = a) : yk = 0;
      jg();
      return null;
    }
    function Hk() {
      if (null !== wk) {
        var a = Dc(xk), b = ok.transition, c = C;
        try {
          ok.transition = null;
          C = 16 > a ? 16 : a;
          if (null === wk) var d = false;
          else {
            a = wk;
            wk = null;
            xk = 0;
            if (0 !== (K & 6)) throw Error(p(331));
            var e = K;
            K |= 4;
            for (V = a.current; null !== V; ) {
              var f = V, g = f.child;
              if (0 !== (V.flags & 16)) {
                var h = f.deletions;
                if (null !== h) {
                  for (var k = 0; k < h.length; k++) {
                    var l = h[k];
                    for (V = l; null !== V; ) {
                      var m = V;
                      switch (m.tag) {
                        case 0:
                        case 11:
                        case 15:
                          Pj(8, m, f);
                      }
                      var q = m.child;
                      if (null !== q) q.return = m, V = q;
                      else for (; null !== V; ) {
                        m = V;
                        var r = m.sibling, y = m.return;
                        Sj(m);
                        if (m === l) {
                          V = null;
                          break;
                        }
                        if (null !== r) {
                          r.return = y;
                          V = r;
                          break;
                        }
                        V = y;
                      }
                    }
                  }
                  var n = f.alternate;
                  if (null !== n) {
                    var t2 = n.child;
                    if (null !== t2) {
                      n.child = null;
                      do {
                        var J = t2.sibling;
                        t2.sibling = null;
                        t2 = J;
                      } while (null !== t2);
                    }
                  }
                  V = f;
                }
              }
              if (0 !== (f.subtreeFlags & 2064) && null !== g) g.return = f, V = g;
              else b: for (; null !== V; ) {
                f = V;
                if (0 !== (f.flags & 2048)) switch (f.tag) {
                  case 0:
                  case 11:
                  case 15:
                    Pj(9, f, f.return);
                }
                var x = f.sibling;
                if (null !== x) {
                  x.return = f.return;
                  V = x;
                  break b;
                }
                V = f.return;
              }
            }
            var w = a.current;
            for (V = w; null !== V; ) {
              g = V;
              var u = g.child;
              if (0 !== (g.subtreeFlags & 2064) && null !== u) u.return = g, V = u;
              else b: for (g = w; null !== V; ) {
                h = V;
                if (0 !== (h.flags & 2048)) try {
                  switch (h.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Qj(9, h);
                  }
                } catch (na) {
                  W(h, h.return, na);
                }
                if (h === g) {
                  V = null;
                  break b;
                }
                var F = h.sibling;
                if (null !== F) {
                  F.return = h.return;
                  V = F;
                  break b;
                }
                V = h.return;
              }
            }
            K = e;
            jg();
            if (lc && "function" === typeof lc.onPostCommitFiberRoot) try {
              lc.onPostCommitFiberRoot(kc, a);
            } catch (na) {
            }
            d = true;
          }
          return d;
        } finally {
          C = c, ok.transition = b;
        }
      }
      return false;
    }
    function Xk(a, b, c) {
      b = Ji(c, b);
      b = Ni(a, b, 1);
      a = nh(a, b, 1);
      b = R();
      null !== a && (Ac(a, 1, b), Dk(a, b));
    }
    function W(a, b, c) {
      if (3 === a.tag) Xk(a, a, c);
      else for (; null !== b; ) {
        if (3 === b.tag) {
          Xk(b, a, c);
          break;
        } else if (1 === b.tag) {
          var d = b.stateNode;
          if ("function" === typeof b.type.getDerivedStateFromError || "function" === typeof d.componentDidCatch && (null === Ri || !Ri.has(d))) {
            a = Ji(c, a);
            a = Qi(b, a, 1);
            b = nh(b, a, 1);
            a = R();
            null !== b && (Ac(b, 1, a), Dk(b, a));
            break;
          }
        }
        b = b.return;
      }
    }
    function Ti(a, b, c) {
      var d = a.pingCache;
      null !== d && d.delete(b);
      b = R();
      a.pingedLanes |= a.suspendedLanes & c;
      Q === a && (Z & c) === c && (4 === T || 3 === T && (Z & 130023424) === Z && 500 > B() - fk ? Kk(a, 0) : rk |= c);
      Dk(a, b);
    }
    function Yk(a, b) {
      0 === b && (0 === (a.mode & 1) ? b = 1 : (b = sc, sc <<= 1, 0 === (sc & 130023424) && (sc = 4194304)));
      var c = R();
      a = ih(a, b);
      null !== a && (Ac(a, b, c), Dk(a, c));
    }
    function uj(a) {
      var b = a.memoizedState, c = 0;
      null !== b && (c = b.retryLane);
      Yk(a, c);
    }
    function bk(a, b) {
      var c = 0;
      switch (a.tag) {
        case 13:
          var d = a.stateNode;
          var e = a.memoizedState;
          null !== e && (c = e.retryLane);
          break;
        case 19:
          d = a.stateNode;
          break;
        default:
          throw Error(p(314));
      }
      null !== d && d.delete(b);
      Yk(a, c);
    }
    var Vk;
    Vk = function(a, b, c) {
      if (null !== a) if (a.memoizedProps !== b.pendingProps || Wf.current) dh = true;
      else {
        if (0 === (a.lanes & c) && 0 === (b.flags & 128)) return dh = false, yj(a, b, c);
        dh = 0 !== (a.flags & 131072) ? true : false;
      }
      else dh = false, I && 0 !== (b.flags & 1048576) && ug(b, ng, b.index);
      b.lanes = 0;
      switch (b.tag) {
        case 2:
          var d = b.type;
          ij(a, b);
          a = b.pendingProps;
          var e = Yf(b, H.current);
          ch(b, c);
          e = Nh(null, b, d, a, e, c);
          var f = Sh();
          b.flags |= 1;
          "object" === typeof e && null !== e && "function" === typeof e.render && void 0 === e.$$typeof ? (b.tag = 1, b.memoizedState = null, b.updateQueue = null, Zf(d) ? (f = true, cg(b)) : f = false, b.memoizedState = null !== e.state && void 0 !== e.state ? e.state : null, kh(b), e.updater = Ei, b.stateNode = e, e._reactInternals = b, Ii(b, d, a, c), b = jj(null, b, d, true, f, c)) : (b.tag = 0, I && f && vg(b), Xi(null, b, e, c), b = b.child);
          return b;
        case 16:
          d = b.elementType;
          a: {
            ij(a, b);
            a = b.pendingProps;
            e = d._init;
            d = e(d._payload);
            b.type = d;
            e = b.tag = Zk(d);
            a = Ci(d, a);
            switch (e) {
              case 0:
                b = cj(null, b, d, a, c);
                break a;
              case 1:
                b = hj(null, b, d, a, c);
                break a;
              case 11:
                b = Yi(null, b, d, a, c);
                break a;
              case 14:
                b = $i(null, b, d, Ci(d.type, a), c);
                break a;
            }
            throw Error(p(
              306,
              d,
              ""
            ));
          }
          return b;
        case 0:
          return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), cj(a, b, d, e, c);
        case 1:
          return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), hj(a, b, d, e, c);
        case 3:
          a: {
            kj(b);
            if (null === a) throw Error(p(387));
            d = b.pendingProps;
            f = b.memoizedState;
            e = f.element;
            lh(a, b);
            qh(b, d, null, c);
            var g = b.memoizedState;
            d = g.element;
            if (f.isDehydrated) if (f = { element: d, isDehydrated: false, cache: g.cache, pendingSuspenseBoundaries: g.pendingSuspenseBoundaries, transitions: g.transitions }, b.updateQueue.baseState = f, b.memoizedState = f, b.flags & 256) {
              e = Ji(Error(p(423)), b);
              b = lj(a, b, d, c, e);
              break a;
            } else if (d !== e) {
              e = Ji(Error(p(424)), b);
              b = lj(a, b, d, c, e);
              break a;
            } else for (yg = Lf(b.stateNode.containerInfo.firstChild), xg = b, I = true, zg = null, c = Vg(b, null, d, c), b.child = c; c; ) c.flags = c.flags & -3 | 4096, c = c.sibling;
            else {
              Ig();
              if (d === e) {
                b = Zi(a, b, c);
                break a;
              }
              Xi(a, b, d, c);
            }
            b = b.child;
          }
          return b;
        case 5:
          return Ah(b), null === a && Eg(b), d = b.type, e = b.pendingProps, f = null !== a ? a.memoizedProps : null, g = e.children, Ef(d, e) ? g = null : null !== f && Ef(d, f) && (b.flags |= 32), gj(a, b), Xi(a, b, g, c), b.child;
        case 6:
          return null === a && Eg(b), null;
        case 13:
          return oj(a, b, c);
        case 4:
          return yh(b, b.stateNode.containerInfo), d = b.pendingProps, null === a ? b.child = Ug(b, null, d, c) : Xi(a, b, d, c), b.child;
        case 11:
          return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), Yi(a, b, d, e, c);
        case 7:
          return Xi(a, b, b.pendingProps, c), b.child;
        case 8:
          return Xi(a, b, b.pendingProps.children, c), b.child;
        case 12:
          return Xi(a, b, b.pendingProps.children, c), b.child;
        case 10:
          a: {
            d = b.type._context;
            e = b.pendingProps;
            f = b.memoizedProps;
            g = e.value;
            G(Wg, d._currentValue);
            d._currentValue = g;
            if (null !== f) if (He(f.value, g)) {
              if (f.children === e.children && !Wf.current) {
                b = Zi(a, b, c);
                break a;
              }
            } else for (f = b.child, null !== f && (f.return = b); null !== f; ) {
              var h = f.dependencies;
              if (null !== h) {
                g = f.child;
                for (var k = h.firstContext; null !== k; ) {
                  if (k.context === d) {
                    if (1 === f.tag) {
                      k = mh(-1, c & -c);
                      k.tag = 2;
                      var l = f.updateQueue;
                      if (null !== l) {
                        l = l.shared;
                        var m = l.pending;
                        null === m ? k.next = k : (k.next = m.next, m.next = k);
                        l.pending = k;
                      }
                    }
                    f.lanes |= c;
                    k = f.alternate;
                    null !== k && (k.lanes |= c);
                    bh(
                      f.return,
                      c,
                      b
                    );
                    h.lanes |= c;
                    break;
                  }
                  k = k.next;
                }
              } else if (10 === f.tag) g = f.type === b.type ? null : f.child;
              else if (18 === f.tag) {
                g = f.return;
                if (null === g) throw Error(p(341));
                g.lanes |= c;
                h = g.alternate;
                null !== h && (h.lanes |= c);
                bh(g, c, b);
                g = f.sibling;
              } else g = f.child;
              if (null !== g) g.return = f;
              else for (g = f; null !== g; ) {
                if (g === b) {
                  g = null;
                  break;
                }
                f = g.sibling;
                if (null !== f) {
                  f.return = g.return;
                  g = f;
                  break;
                }
                g = g.return;
              }
              f = g;
            }
            Xi(a, b, e.children, c);
            b = b.child;
          }
          return b;
        case 9:
          return e = b.type, d = b.pendingProps.children, ch(b, c), e = eh(e), d = d(e), b.flags |= 1, Xi(a, b, d, c), b.child;
        case 14:
          return d = b.type, e = Ci(d, b.pendingProps), e = Ci(d.type, e), $i(a, b, d, e, c);
        case 15:
          return bj(a, b, b.type, b.pendingProps, c);
        case 17:
          return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), ij(a, b), b.tag = 1, Zf(d) ? (a = true, cg(b)) : a = false, ch(b, c), Gi(b, d, e), Ii(b, d, e, c), jj(null, b, d, true, a, c);
        case 19:
          return xj(a, b, c);
        case 22:
          return dj(a, b, c);
      }
      throw Error(p(156, b.tag));
    };
    function Fk(a, b) {
      return ac(a, b);
    }
    function $k(a, b, c, d) {
      this.tag = a;
      this.key = c;
      this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
      this.index = 0;
      this.ref = null;
      this.pendingProps = b;
      this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
      this.mode = d;
      this.subtreeFlags = this.flags = 0;
      this.deletions = null;
      this.childLanes = this.lanes = 0;
      this.alternate = null;
    }
    function Bg(a, b, c, d) {
      return new $k(a, b, c, d);
    }
    function aj(a) {
      a = a.prototype;
      return !(!a || !a.isReactComponent);
    }
    function Zk(a) {
      if ("function" === typeof a) return aj(a) ? 1 : 0;
      if (void 0 !== a && null !== a) {
        a = a.$$typeof;
        if (a === Da) return 11;
        if (a === Ga) return 14;
      }
      return 2;
    }
    function Pg(a, b) {
      var c = a.alternate;
      null === c ? (c = Bg(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.subtreeFlags = 0, c.deletions = null);
      c.flags = a.flags & 14680064;
      c.childLanes = a.childLanes;
      c.lanes = a.lanes;
      c.child = a.child;
      c.memoizedProps = a.memoizedProps;
      c.memoizedState = a.memoizedState;
      c.updateQueue = a.updateQueue;
      b = a.dependencies;
      c.dependencies = null === b ? null : { lanes: b.lanes, firstContext: b.firstContext };
      c.sibling = a.sibling;
      c.index = a.index;
      c.ref = a.ref;
      return c;
    }
    function Rg(a, b, c, d, e, f) {
      var g = 2;
      d = a;
      if ("function" === typeof a) aj(a) && (g = 1);
      else if ("string" === typeof a) g = 5;
      else a: switch (a) {
        case ya:
          return Tg(c.children, e, f, b);
        case za:
          g = 8;
          e |= 8;
          break;
        case Aa:
          return a = Bg(12, c, b, e | 2), a.elementType = Aa, a.lanes = f, a;
        case Ea:
          return a = Bg(13, c, b, e), a.elementType = Ea, a.lanes = f, a;
        case Fa:
          return a = Bg(19, c, b, e), a.elementType = Fa, a.lanes = f, a;
        case Ia:
          return pj(c, e, f, b);
        default:
          if ("object" === typeof a && null !== a) switch (a.$$typeof) {
            case Ba:
              g = 10;
              break a;
            case Ca:
              g = 9;
              break a;
            case Da:
              g = 11;
              break a;
            case Ga:
              g = 14;
              break a;
            case Ha:
              g = 16;
              d = null;
              break a;
          }
          throw Error(p(130, null == a ? a : typeof a, ""));
      }
      b = Bg(g, c, b, e);
      b.elementType = a;
      b.type = d;
      b.lanes = f;
      return b;
    }
    function Tg(a, b, c, d) {
      a = Bg(7, a, d, b);
      a.lanes = c;
      return a;
    }
    function pj(a, b, c, d) {
      a = Bg(22, a, d, b);
      a.elementType = Ia;
      a.lanes = c;
      a.stateNode = { isHidden: false };
      return a;
    }
    function Qg(a, b, c) {
      a = Bg(6, a, null, b);
      a.lanes = c;
      return a;
    }
    function Sg(a, b, c) {
      b = Bg(4, null !== a.children ? a.children : [], a.key, b);
      b.lanes = c;
      b.stateNode = { containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation };
      return b;
    }
    function al(a, b, c, d, e) {
      this.tag = b;
      this.containerInfo = a;
      this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
      this.timeoutHandle = -1;
      this.callbackNode = this.pendingContext = this.context = null;
      this.callbackPriority = 0;
      this.eventTimes = zc(0);
      this.expirationTimes = zc(-1);
      this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
      this.entanglements = zc(0);
      this.identifierPrefix = d;
      this.onRecoverableError = e;
      this.mutableSourceEagerHydrationData = null;
    }
    function bl(a, b, c, d, e, f, g, h, k) {
      a = new al(a, b, c, h, k);
      1 === b ? (b = 1, true === f && (b |= 8)) : b = 0;
      f = Bg(3, null, null, b);
      a.current = f;
      f.stateNode = a;
      f.memoizedState = { element: d, isDehydrated: c, cache: null, transitions: null, pendingSuspenseBoundaries: null };
      kh(f);
      return a;
    }
    function cl(a, b, c) {
      var d = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
      return { $$typeof: wa, key: null == d ? null : "" + d, children: a, containerInfo: b, implementation: c };
    }
    function dl(a) {
      if (!a) return Vf;
      a = a._reactInternals;
      a: {
        if (Vb(a) !== a || 1 !== a.tag) throw Error(p(170));
        var b = a;
        do {
          switch (b.tag) {
            case 3:
              b = b.stateNode.context;
              break a;
            case 1:
              if (Zf(b.type)) {
                b = b.stateNode.__reactInternalMemoizedMergedChildContext;
                break a;
              }
          }
          b = b.return;
        } while (null !== b);
        throw Error(p(171));
      }
      if (1 === a.tag) {
        var c = a.type;
        if (Zf(c)) return bg(a, c, b);
      }
      return b;
    }
    function el(a, b, c, d, e, f, g, h, k) {
      a = bl(c, d, true, a, e, f, g, h, k);
      a.context = dl(null);
      c = a.current;
      d = R();
      e = yi(c);
      f = mh(d, e);
      f.callback = void 0 !== b && null !== b ? b : null;
      nh(c, f, e);
      a.current.lanes = e;
      Ac(a, e, d);
      Dk(a, d);
      return a;
    }
    function fl(a, b, c, d) {
      var e = b.current, f = R(), g = yi(e);
      c = dl(c);
      null === b.context ? b.context = c : b.pendingContext = c;
      b = mh(f, g);
      b.payload = { element: a };
      d = void 0 === d ? null : d;
      null !== d && (b.callback = d);
      a = nh(e, b, g);
      null !== a && (gi(a, e, g, f), oh(a, e, g));
      return g;
    }
    function gl(a) {
      a = a.current;
      if (!a.child) return null;
      switch (a.child.tag) {
        case 5:
          return a.child.stateNode;
        default:
          return a.child.stateNode;
      }
    }
    function hl(a, b) {
      a = a.memoizedState;
      if (null !== a && null !== a.dehydrated) {
        var c = a.retryLane;
        a.retryLane = 0 !== c && c < b ? c : b;
      }
    }
    function il(a, b) {
      hl(a, b);
      (a = a.alternate) && hl(a, b);
    }
    function jl() {
      return null;
    }
    var kl = "function" === typeof reportError ? reportError : function(a) {
      console.error(a);
    };
    function ll(a) {
      this._internalRoot = a;
    }
    ml.prototype.render = ll.prototype.render = function(a) {
      var b = this._internalRoot;
      if (null === b) throw Error(p(409));
      fl(a, b, null, null);
    };
    ml.prototype.unmount = ll.prototype.unmount = function() {
      var a = this._internalRoot;
      if (null !== a) {
        this._internalRoot = null;
        var b = a.containerInfo;
        Rk(function() {
          fl(null, a, null, null);
        });
        b[uf] = null;
      }
    };
    function ml(a) {
      this._internalRoot = a;
    }
    ml.prototype.unstable_scheduleHydration = function(a) {
      if (a) {
        var b = Hc();
        a = { blockedOn: null, target: a, priority: b };
        for (var c = 0; c < Qc.length && 0 !== b && b < Qc[c].priority; c++) ;
        Qc.splice(c, 0, a);
        0 === c && Vc(a);
      }
    };
    function nl(a) {
      return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType);
    }
    function ol(a) {
      return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType && (8 !== a.nodeType || " react-mount-point-unstable " !== a.nodeValue));
    }
    function pl() {
    }
    function ql(a, b, c, d, e) {
      if (e) {
        if ("function" === typeof d) {
          var f = d;
          d = function() {
            var a2 = gl(g);
            f.call(a2);
          };
        }
        var g = el(b, d, a, 0, null, false, false, "", pl);
        a._reactRootContainer = g;
        a[uf] = g.current;
        sf(8 === a.nodeType ? a.parentNode : a);
        Rk();
        return g;
      }
      for (; e = a.lastChild; ) a.removeChild(e);
      if ("function" === typeof d) {
        var h = d;
        d = function() {
          var a2 = gl(k);
          h.call(a2);
        };
      }
      var k = bl(a, 0, false, null, null, false, false, "", pl);
      a._reactRootContainer = k;
      a[uf] = k.current;
      sf(8 === a.nodeType ? a.parentNode : a);
      Rk(function() {
        fl(b, k, c, d);
      });
      return k;
    }
    function rl(a, b, c, d, e) {
      var f = c._reactRootContainer;
      if (f) {
        var g = f;
        if ("function" === typeof e) {
          var h = e;
          e = function() {
            var a2 = gl(g);
            h.call(a2);
          };
        }
        fl(b, g, a, e);
      } else g = ql(c, b, a, e, d);
      return gl(g);
    }
    Ec = function(a) {
      switch (a.tag) {
        case 3:
          var b = a.stateNode;
          if (b.current.memoizedState.isDehydrated) {
            var c = tc(b.pendingLanes);
            0 !== c && (Cc(b, c | 1), Dk(b, B()), 0 === (K & 6) && (Gj = B() + 500, jg()));
          }
          break;
        case 13:
          Rk(function() {
            var b2 = ih(a, 1);
            if (null !== b2) {
              var c2 = R();
              gi(b2, a, 1, c2);
            }
          }), il(a, 1);
      }
    };
    Fc = function(a) {
      if (13 === a.tag) {
        var b = ih(a, 134217728);
        if (null !== b) {
          var c = R();
          gi(b, a, 134217728, c);
        }
        il(a, 134217728);
      }
    };
    Gc = function(a) {
      if (13 === a.tag) {
        var b = yi(a), c = ih(a, b);
        if (null !== c) {
          var d = R();
          gi(c, a, b, d);
        }
        il(a, b);
      }
    };
    Hc = function() {
      return C;
    };
    Ic = function(a, b) {
      var c = C;
      try {
        return C = a, b();
      } finally {
        C = c;
      }
    };
    yb = function(a, b, c) {
      switch (b) {
        case "input":
          bb(a, c);
          b = c.name;
          if ("radio" === c.type && null != b) {
            for (c = a; c.parentNode; ) c = c.parentNode;
            c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + '][type="radio"]');
            for (b = 0; b < c.length; b++) {
              var d = c[b];
              if (d !== a && d.form === a.form) {
                var e = Db(d);
                if (!e) throw Error(p(90));
                Wa(d);
                bb(d, e);
              }
            }
          }
          break;
        case "textarea":
          ib(a, c);
          break;
        case "select":
          b = c.value, null != b && fb(a, !!c.multiple, b, false);
      }
    };
    Gb = Qk;
    Hb = Rk;
    var sl = { usingClientEntryPoint: false, Events: [Cb, ue, Db, Eb, Fb, Qk] }, tl = { findFiberByHostInstance: Wc, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" };
    var ul = { bundleType: tl.bundleType, version: tl.version, rendererPackageName: tl.rendererPackageName, rendererConfig: tl.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ua.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
      a = Zb(a);
      return null === a ? null : a.stateNode;
    }, findFiberByHostInstance: tl.findFiberByHostInstance || jl, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
    if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
      var vl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!vl.isDisabled && vl.supportsFiber) try {
        kc = vl.inject(ul), lc = vl;
      } catch (a) {
      }
    }
    reactDom_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = sl;
    reactDom_production_min.createPortal = function(a, b) {
      var c = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
      if (!nl(b)) throw Error(p(200));
      return cl(a, b, null, c);
    };
    reactDom_production_min.createRoot = function(a, b) {
      if (!nl(a)) throw Error(p(299));
      var c = false, d = "", e = kl;
      null !== b && void 0 !== b && (true === b.unstable_strictMode && (c = true), void 0 !== b.identifierPrefix && (d = b.identifierPrefix), void 0 !== b.onRecoverableError && (e = b.onRecoverableError));
      b = bl(a, 1, false, null, null, c, false, d, e);
      a[uf] = b.current;
      sf(8 === a.nodeType ? a.parentNode : a);
      return new ll(b);
    };
    reactDom_production_min.findDOMNode = function(a) {
      if (null == a) return null;
      if (1 === a.nodeType) return a;
      var b = a._reactInternals;
      if (void 0 === b) {
        if ("function" === typeof a.render) throw Error(p(188));
        a = Object.keys(a).join(",");
        throw Error(p(268, a));
      }
      a = Zb(b);
      a = null === a ? null : a.stateNode;
      return a;
    };
    reactDom_production_min.flushSync = function(a) {
      return Rk(a);
    };
    reactDom_production_min.hydrate = function(a, b, c) {
      if (!ol(b)) throw Error(p(200));
      return rl(null, a, b, true, c);
    };
    reactDom_production_min.hydrateRoot = function(a, b, c) {
      if (!nl(a)) throw Error(p(405));
      var d = null != c && c.hydratedSources || null, e = false, f = "", g = kl;
      null !== c && void 0 !== c && (true === c.unstable_strictMode && (e = true), void 0 !== c.identifierPrefix && (f = c.identifierPrefix), void 0 !== c.onRecoverableError && (g = c.onRecoverableError));
      b = el(b, null, a, 1, null != c ? c : null, e, false, f, g);
      a[uf] = b.current;
      sf(a);
      if (d) for (a = 0; a < d.length; a++) c = d[a], e = c._getVersion, e = e(c._source), null == b.mutableSourceEagerHydrationData ? b.mutableSourceEagerHydrationData = [c, e] : b.mutableSourceEagerHydrationData.push(
        c,
        e
      );
      return new ml(b);
    };
    reactDom_production_min.render = function(a, b, c) {
      if (!ol(b)) throw Error(p(200));
      return rl(null, a, b, false, c);
    };
    reactDom_production_min.unmountComponentAtNode = function(a) {
      if (!ol(a)) throw Error(p(40));
      return a._reactRootContainer ? (Rk(function() {
        rl(null, null, a, false, function() {
          a._reactRootContainer = null;
          a[uf] = null;
        });
      }), true) : false;
    };
    reactDom_production_min.unstable_batchedUpdates = Qk;
    reactDom_production_min.unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
      if (!ol(c)) throw Error(p(200));
      if (null == a || void 0 === a._reactInternals) throw Error(p(38));
      return rl(a, b, c, false, d);
    };
    reactDom_production_min.version = "18.3.1-next-f1338f8080-20240426";
    return reactDom_production_min;
  }
  var hasRequiredReactDom;
  function requireReactDom() {
    if (hasRequiredReactDom) return reactDom.exports;
    hasRequiredReactDom = 1;
    function checkDCE() {
      if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
        return;
      }
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
      } catch (err) {
        console.error(err);
      }
    }
    {
      checkDCE();
      reactDom.exports = requireReactDom_production_min();
    }
    return reactDom.exports;
  }
  var hasRequiredClient;
  function requireClient() {
    if (hasRequiredClient) return client;
    hasRequiredClient = 1;
    var m = requireReactDom();
    {
      client.createRoot = m.createRoot;
      client.hydrateRoot = m.hydrateRoot;
    }
    return client;
  }
  var clientExports = requireClient();
  const ReactDOM = /* @__PURE__ */ getDefaultExportFromCjs(clientExports);
  const scriptRel = "modulepreload";
  const assetsURL = function(dep, importerUrl) {
    return new URL(dep, importerUrl).href;
  };
  const seen = {};
  const __vitePreload = function preload(baseModule, deps, importerUrl) {
    let promise = Promise.resolve();
    if (false) {
      let allSettled2 = function(promises) {
        return Promise.all(
          promises.map(
            (p) => Promise.resolve(p).then(
              (value) => ({ status: "fulfilled", value }),
              (reason) => ({ status: "rejected", reason })
            )
          )
        );
      };
      const links = document.getElementsByTagName("link");
      const cspNonceMeta = document.querySelector(
        "meta[property=csp-nonce]"
      );
      const cspNonce = (cspNonceMeta == null ? void 0 : cspNonceMeta.nonce) || (cspNonceMeta == null ? void 0 : cspNonceMeta.getAttribute("nonce"));
      promise = allSettled2(
        deps.map((dep) => {
          dep = assetsURL(dep, importerUrl);
          if (dep in seen) return;
          seen[dep] = true;
          const isCss = dep.endsWith(".css");
          const cssSelector = isCss ? '[rel="stylesheet"]' : "";
          const isBaseRelative = !!importerUrl;
          if (isBaseRelative) {
            for (let i = links.length - 1; i >= 0; i--) {
              const link2 = links[i];
              if (link2.href === dep && (!isCss || link2.rel === "stylesheet")) {
                return;
              }
            }
          } else if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
            return;
          }
          const link = document.createElement("link");
          link.rel = isCss ? "stylesheet" : scriptRel;
          if (!isCss) {
            link.as = "script";
          }
          link.crossOrigin = "";
          link.href = dep;
          if (cspNonce) {
            link.setAttribute("nonce", cspNonce);
          }
          document.head.appendChild(link);
          if (isCss) {
            return new Promise((res, rej) => {
              link.addEventListener("load", res);
              link.addEventListener(
                "error",
                () => rej(new Error(`Unable to preload CSS for ${dep}`))
              );
            });
          }
        })
      );
    }
    function handlePreloadError(err) {
      const e = new Event("vite:preloadError", {
        cancelable: true
      });
      e.payload = err;
      window.dispatchEvent(e);
      if (!e.defaultPrevented) {
        throw err;
      }
    }
    return promise.then((res) => {
      for (const item of res || []) {
        if (item.status !== "rejected") continue;
        handlePreloadError(item.reason);
      }
      return baseModule().catch(handlePreloadError);
    });
  };
  if (typeof require === "undefined") {
    window.require = (moduleName) => {
      return {};
    };
  }
  const uxp = require("uxp");
  const hostName = uxp && ((_b = (_a = uxp == null ? void 0 : uxp.host) == null ? void 0 : _a.name) == null ? void 0 : _b.toLowerCase());
  const photoshop = hostName === "photoshop" ? require("photoshop") : {};
  hostName === "indesign" ? require("indesign") : {};
  hostName === "illustrator" ? require("illustrator") : {};
  var GalleryEventType = /* @__PURE__ */ ((GalleryEventType2) => {
    GalleryEventType2["IMAGE_GENERATED"] = "generation:imageReady";
    GalleryEventType2["IMAGE_UPLOADED"] = "gallery:imageUploaded";
    return GalleryEventType2;
  })(GalleryEventType || {});
  const eventBus = {
    emit(type, detail) {
      window.dispatchEvent(new CustomEvent(type, { detail }));
    },
    on(type, handler) {
      const listener = (event) => {
        handler(event.detail);
      };
      window.addEventListener(type, listener);
      return () => {
        window.removeEventListener(type, listener);
      };
    }
  };
  const fs = require("uxp").storage.localFileSystem;
  const { formats: formats$1 } = require("uxp").storage;
  const placeImageUsingToken = async (sessionToken, layerName, _imageWidth, _imageHeight) => {
    const startTime = performance.now();
    const app = photoshop.app;
    const core = photoshop.core;
    const action = photoshop.action;
    const targetDoc = app.activeDocument;
    if (!targetDoc) {
      throw new Error("请先打开一个文档");
    }
    const docWidth = targetDoc.width;
    const docHeight = targetDoc.height;
    await core.executeAsModal(async (context) => {
      let suspensionID = null;
      const t0 = performance.now();
      try {
        suspensionID = await context.hostControl.suspendHistory({
          "documentID": targetDoc.id,
          "name": "Import Smart Object"
        });
        const t1 = performance.now();
        console.log(`[SmartPlace] Suspend History took: ${(t1 - t0).toFixed(2)}ms`);
        try {
          const selectionResult = await action.batchPlay([
            {
              _obj: "set",
              _target: [{ _ref: "channel", _property: "selection" }],
              to: { _enum: "ordinal", _value: "none" },
              _options: { dialogOptions: "dontDisplay" }
            }
          ], { synchronousExecution: true, modalBehavior: "execute" });
          if (selectionResult && selectionResult[0] && selectionResult[0].message) {
          }
        } catch (e) {
          console.warn("[SmartPlace] Deselect failed (ignorable):", e);
        }
        const descriptors = [];
        descriptors.push({
          _obj: "placeEvent",
          ID: 1,
          null: {
            _path: sessionToken,
            _kind: "local"
          },
          linked: false,
          freeTransformCenterState: {
            _enum: "quadCenterState",
            _value: "QCSAverage"
          },
          offset: {
            _obj: "offset",
            horizontal: { _unit: "pixelsUnit", _value: 0 },
            vertical: { _unit: "pixelsUnit", _value: 0 }
          },
          _options: {
            dialogOptions: "dontDisplay"
          }
        });
        let scaleFactor = 1;
        let shouldTransform = false;
        if (_imageWidth && _imageHeight) ;
        if (shouldTransform) {
          descriptors.push({
            _obj: "transform",
            _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
            freeTransformCenterState: { _enum: "quadCenterState", _value: "QCSAverage" },
            width: { _unit: "percentUnit", _value: scaleFactor * 100 },
            height: { _unit: "percentUnit", _value: scaleFactor * 100 },
            _options: { dialogOptions: "dontDisplay" }
          });
        }
        if (layerName) {
          descriptors.push({
            _obj: "set",
            _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
            to: { _obj: "layer", name: layerName },
            _options: { dialogOptions: "dontDisplay" }
          });
        }
        if (_imageWidth && _imageHeight) ;
        else {
          console.log(`[SmartPlace] Unknown dimensions, using multi-step placement`);
          await action.batchPlay([descriptors[0]], { synchronousExecution: true, modalBehavior: "execute" });
          const boundsResult = await action.batchPlay(
            [{
              _obj: "get",
              _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
              _options: { dialogOptions: "dontDisplay" }
            }],
            { synchronousExecution: true, modalBehavior: "execute" }
          );
          const boundsObj = boundsResult[0].bounds;
          const currentLeft = boundsObj.left._value;
          const currentTop = boundsObj.top._value;
          const layerWidth = boundsObj.right._value - currentLeft;
          const layerHeight = boundsObj.bottom._value - currentTop;
          const widthRatio = docWidth / layerWidth;
          const heightRatio = docHeight / layerHeight;
          scaleFactor = Math.max(widthRatio, heightRatio);
          const needsTransform = Math.abs(scaleFactor - 1) > 0.01 || Math.abs(currentLeft) > 0.1 || Math.abs(currentTop) > 0.1;
          if (needsTransform) {
            console.log(`[SmartPlace] Adjusting layer: scale=${scaleFactor.toFixed(4)}, move offset=(${-currentLeft}, ${-currentTop})`);
            await action.batchPlay([{
              _obj: "transform",
              _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
              freeTransformCenterState: { _enum: "quadCenterState", _value: "QCSAverage" },
              width: { _unit: "percentUnit", _value: scaleFactor * 100 },
              height: { _unit: "percentUnit", _value: scaleFactor * 100 },
              offset: {
                _obj: "offset",
                horizontal: { _unit: "pixelsUnit", _value: -currentLeft },
                vertical: { _unit: "pixelsUnit", _value: -currentTop }
              },
              _options: { dialogOptions: "dontDisplay" }
            }], { synchronousExecution: true, modalBehavior: "execute" });
          }
          if (layerName) {
            await action.batchPlay([{
              _obj: "set",
              _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
              to: { _obj: "layer", name: layerName },
              _options: { dialogOptions: "dontDisplay" }
            }], { synchronousExecution: true, modalBehavior: "execute" });
          }
        }
        console.log(`[SmartPlace] ✅ Smart Object Placement 完成（保持为智能对象，可双击编辑）`);
      } catch (error) {
        console.error("[SmartPlace] 放置失败:", error);
        throw error;
      } finally {
        if (suspensionID) {
          const tResumeStart = performance.now();
          await context.hostControl.resumeHistory(suspensionID);
          console.log(`[SmartPlace] Resume History took: ${(performance.now() - tResumeStart).toFixed(2)}ms`);
        }
      }
    }, {
      commandName: "Smart Object Import",
      interactive: false
    });
    console.log(`[SmartPlace] Total time: ${(performance.now() - startTime).toFixed(2)}ms`);
  };
  const placeImageUsingTokenNoScale = async (sessionToken, layerName) => {
    const app = photoshop.app;
    const core = photoshop.core;
    const action = photoshop.action;
    const targetDoc = app.activeDocument;
    if (!targetDoc) {
      throw new Error("请先打开一个文档");
    }
    await core.executeAsModal(async (context) => {
      let suspensionID = null;
      try {
        suspensionID = await context.hostControl.suspendHistory({
          documentID: targetDoc.id,
          name: "Import Smart Object"
        });
        await action.batchPlay([
          {
            _obj: "placeEvent",
            null: { _path: sessionToken, _kind: "local" },
            linked: false,
            freeTransformCenterState: { _enum: "quadCenterState", _value: "QCSAverage" },
            _options: { dialogOptions: "dontDisplay" }
          }
        ], { synchronousExecution: true, modalBehavior: "execute" });
        console.log("[SmartPlace] Embedded Smart Object placed");
        if (layerName) {
          await action.batchPlay([
            {
              _obj: "set",
              _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
              to: { _obj: "layer", name: layerName },
              _options: { dialogOptions: "dontDisplay" }
            }
          ], { synchronousExecution: true, modalBehavior: "execute" });
        }
        await action.batchPlay([
          {
            _obj: "set",
            _target: [{ _ref: "channel", _property: "selection" }],
            to: { _enum: "ordinal", _value: "allEnum" },
            _options: { dialogOptions: "dontDisplay" }
          },
          {
            _obj: "align",
            _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
            using: { _enum: "alignDistributeSelector", _value: "ADSCentersV" },
            alignToCanvas: false,
            _options: { dialogOptions: "dontDisplay" }
          },
          {
            _obj: "align",
            _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
            using: { _enum: "alignDistributeSelector", _value: "ADSCentersH" },
            alignToCanvas: false,
            _options: { dialogOptions: "dontDisplay" }
          },
          {
            _obj: "set",
            _target: [{ _ref: "channel", _property: "selection" }],
            to: { _enum: "ordinal", _value: "none" },
            _options: { dialogOptions: "dontDisplay" }
          }
        ], { synchronousExecution: true, modalBehavior: "execute" });
      } finally {
        if (suspensionID) await context.hostControl.resumeHistory(suspensionID);
      }
    }, {
      commandName: "Import Smart Object",
      interactive: false
    });
  };
  const placeImageOnCanvasAsNewLayer = async (imageData, layerName) => {
    console.log("[PS] ========== 开始将图片放置到画布 (Fast Mode v2) ==========");
    if (!imageData) {
      throw new Error("No image data available");
    }
    try {
      let token;
      if (imageData.startsWith("data:image")) {
        console.log("[PS] Base64 -> Token");
        const fileInfo = await saveBase64ToTempFile(imageData);
        token = fileInfo.token;
      } else if (imageData.startsWith("blob:") || imageData.startsWith("http")) {
        console.log("[PS] URL/Blob -> Token");
        const fileInfo = await saveUrlToTempFile(imageData);
        token = fileInfo.token;
      } else {
        console.log("[PS] Path -> Token");
        const entry = await fs.getEntryWithUrl(imageData);
        token = await fs.createSessionToken(entry);
      }
      await placeImageUsingToken(token, layerName);
      console.log("[PS] ========== 图片放置成功 ==========");
    } catch (error) {
      console.error("[PS] 放置失败:", error);
      throw error;
    }
  };
  const sessionTokenCache = /* @__PURE__ */ new Map();
  const CACHE_TTL = 5 * 60 * 1e3;
  const saveBase64ToTempFile = async (base64Data) => {
    const base64Content = base64Data.split(",")[1];
    const cacheKey = base64Content.substring(0, 100);
    const cached = sessionTokenCache.get(cacheKey);
    const now = Date.now();
    if (cached && now - cached.timestamp < CACHE_TTL) {
      return { path: "", token: cached.token };
    }
    const tempFolder = await fs.getTemporaryFolder();
    const fileName = `generated_image_${Date.now()}.png`;
    const file = await tempFolder.createFile(fileName, { overwrite: true });
    const binaryString = atob(base64Content);
    const arrayBuffer = Uint8Array.from(binaryString, (c) => c.charCodeAt(0)).buffer;
    await file.write(arrayBuffer, { format: formats$1.binary });
    const token = await fs.createSessionToken(file);
    sessionTokenCache.set(cacheKey, { token, timestamp: now });
    return { path: file.nativePath, token };
  };
  const saveUrlToTempFile = async (url) => {
    const cacheKey = url;
    const cached = sessionTokenCache.get(cacheKey);
    const now = Date.now();
    if (cached && now - cached.timestamp < CACHE_TTL) {
      return { path: "", token: cached.token };
    }
    const MAX_RETRIES = 3;
    const TIMEOUT_MS = 3e4;
    let lastError;
    let response;
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        const fetchWithTimeout = Promise.race([
          fetch(url, {
            method: "GET",
            headers: {
              "Accept": "image/png,image/webp,image/*,*/*"
            }
          }),
          new Promise(
            (_, reject) => setTimeout(() => reject(new Error(`Download timeout after ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
          )
        ]);
        response = await fetchWithTimeout;
        if (response.ok) break;
        throw new Error(`Failed to fetch image: ${response.status} ${response.statusText}`);
      } catch (err) {
        lastError = err;
        if (attempt < MAX_RETRIES) {
          await new Promise((r) => setTimeout(r, attempt * 1e3));
        }
      }
    }
    if (!response || !response.ok) {
      throw lastError || new Error("All download attempts failed");
    }
    const arrayBuffer = await response.arrayBuffer();
    const tempFolder = await fs.getTemporaryFolder();
    const fileName = `downloaded_image_${Date.now()}.png`;
    const file = await tempFolder.createFile(fileName, { overwrite: true });
    await file.write(arrayBuffer, { format: formats$1.binary });
    const token = await fs.createSessionToken(file);
    sessionTokenCache.set(cacheKey, { token, timestamp: now });
    return { path: file.nativePath, token };
  };
  const createSessionTokenFromImageData = async (imageData) => {
    if (!imageData) {
      throw new Error("No image data available");
    }
    if (imageData.startsWith("data:image")) {
      const fileInfo = await saveBase64ToTempFile(imageData);
      return fileInfo.token;
    }
    if (imageData.startsWith("blob:") || imageData.startsWith("http")) {
      const fileInfo = await saveUrlToTempFile(imageData);
      return fileInfo.token;
    }
    const entry = await fs.getEntryWithUrl(imageData);
    return fs.createSessionToken(entry);
  };
  const cleanExpiredCache = () => {
    const now = Date.now();
    for (const [key, value] of sessionTokenCache.entries()) {
      if (now - value.timestamp > CACHE_TTL) {
        sessionTokenCache.delete(key);
      }
    }
  };
  setInterval(cleanExpiredCache, 60 * 1e3);
  const placeImageToSelection = async (sessionToken, bounds, layerName) => {
    const app = photoshop.app;
    const core = photoshop.core;
    const action = photoshop.action;
    const targetDoc = app.activeDocument;
    if (!targetDoc) throw new Error("没有活动文档");
    await core.executeAsModal(async (context) => {
      var _a2, _b2, _c2, _d2, _e;
      let suspensionID = null;
      let selectionSaved = false;
      try {
        suspensionID = await context.hostControl.suspendHistory({
          "documentID": targetDoc.id,
          "name": "Place Image to Selection"
        });
        console.log("[FastPlace] Target Doc ID:", targetDoc.id);
        console.log("[FastPlace] Selection Bounds provided:", bounds);
        try {
          let selectionExists = false;
          try {
            const domBounds = (_a2 = targetDoc == null ? void 0 : targetDoc.selection) == null ? void 0 : _a2.bounds;
            if (domBounds) selectionExists = true;
          } catch {
          }
          if (!selectionExists) {
            try {
              const selectionResult = await action.batchPlay([
                {
                  _obj: "get",
                  _target: [
                    { _property: "selection" },
                    { _ref: "document", _enum: "ordinal", _value: "targetEnum" }
                  ],
                  _options: { dialogOptions: "dontDisplay" }
                }
              ], { synchronousExecution: true, modalBehavior: "execute" });
              selectionExists = Boolean((_c2 = (_b2 = selectionResult[0]) == null ? void 0 : _b2.selection) == null ? void 0 : _c2.bounds);
            } catch {
            }
          }
          if (!selectionExists) {
            try {
              const { imaging } = require("photoshop");
              const selectionObj = await imaging.getSelection({ documentID: targetDoc.id });
              selectionExists = Boolean(selectionObj);
              (_e = (_d2 = selectionObj == null ? void 0 : selectionObj.imageData) == null ? void 0 : _d2.dispose) == null ? void 0 : _e.call(_d2);
            } catch {
            }
          }
          if (selectionExists) {
            await action.batchPlay([
              {
                _obj: "duplicate",
                _target: [{ _ref: "channel", _property: "selection" }],
                name: "SavedSelection",
                _options: { dialogOptions: "dontDisplay" }
              }
            ], { synchronousExecution: true, modalBehavior: "execute" });
            selectionSaved = true;
            console.log("[FastPlace] Saving current selection...");
          } else {
            selectionSaved = false;
          }
        } catch {
          selectionSaved = false;
        }
        const deselect2 = async () => {
          try {
            await action.batchPlay([{
              _obj: "set",
              _target: [{ _ref: "channel", _property: "selection" }],
              to: { _enum: "ordinal", _value: "none" },
              _options: { dialogOptions: "dontDisplay" }
            }], { synchronousExecution: true, modalBehavior: "execute" });
          } catch {
            await action.batchPlay([{
              _obj: "set",
              _target: [{ _ref: "selection", _enum: "ordinal", _value: "targetEnum" }],
              to: { _enum: "ordinal", _value: "none" },
              _options: { dialogOptions: "dontDisplay" }
            }], { synchronousExecution: true, modalBehavior: "execute" });
          }
        };
        console.log("[SmartPlace] Placing Smart Object...");
        await deselect2();
        await action.batchPlay([
          {
            _obj: "placeEvent",
            null: { _path: sessionToken, _kind: "local" },
            linked: false,
            freeTransformCenterState: { _enum: "quadCenterState", _value: "QCSAverage" },
            _options: { dialogOptions: "dontDisplay" }
          }
        ], { synchronousExecution: true, modalBehavior: "execute" });
        console.log("[SmartPlace] Embedded Smart Object placed");
        const imageLayerID = targetDoc.activeLayers[0].id;
        if (selectionSaved) {
          console.log("[SmartPlace] Applying mask from existing selection...");
          try {
            await action.batchPlay([
              {
                _obj: "set",
                _target: [{ _ref: "channel", _property: "selection" }],
                to: { _ref: "channel", _name: "SavedSelection" },
                _options: { dialogOptions: "dontDisplay" }
              }
            ], { synchronousExecution: true, modalBehavior: "execute" });
          } catch {
            await action.batchPlay([
              {
                _obj: "set",
                _target: [{ _ref: "selection", _enum: "ordinal", _value: "targetEnum" }],
                to: { _ref: "channel", _name: "SavedSelection" },
                _options: { dialogOptions: "dontDisplay" }
              }
            ], { synchronousExecution: true, modalBehavior: "execute" });
          }
          await action.batchPlay([{
            _obj: "select",
            _target: [{ _ref: "layer", _id: imageLayerID }],
            makeVisible: false,
            _options: { dialogOptions: "dontDisplay" }
          }], { synchronousExecution: true, modalBehavior: "execute" });
          await action.batchPlay([{
            _obj: "make",
            new: { _class: "channel" },
            at: { _ref: "channel", _enum: "channel", _value: "mask" },
            using: { _enum: "userMaskEnabled", _value: "revealSelection" },
            _options: { dialogOptions: "dontDisplay" }
          }], { synchronousExecution: true, modalBehavior: "execute" });
          await deselect2();
        }
        if (layerName) {
          await action.batchPlay([{
            _obj: "set",
            _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }],
            to: { _obj: "layer", name: layerName },
            _options: { dialogOptions: "dontDisplay" }
          }], { synchronousExecution: true, modalBehavior: "execute" });
        }
      } catch (error) {
        console.error("[PlaceToSelection] 失败:", error);
        throw error;
      } finally {
        try {
          await deselect();
        } catch {
        }
        if (selectionSaved) {
          try {
            await action.batchPlay([
              {
                _obj: "delete",
                _target: [{ _ref: "channel", _name: "SavedSelection" }],
                _options: { dialogOptions: "dontDisplay" }
              }
            ], { synchronousExecution: true, modalBehavior: "execute" });
          } catch {
          }
        }
        if (suspensionID) await context.hostControl.resumeHistory(suspensionID);
      }
    }, { commandName: "Place Image to Selection", interactive: false });
  };
  const placeImageCentered = async (imageData, imageWidth, imageHeight, layerName) => {
    const startTime = performance.now();
    const app = photoshop.app;
    const core = photoshop.core;
    const action = photoshop.action;
    const targetDoc = app.activeDocument;
    if (!targetDoc) {
      throw new Error("请先在Photoshop中打开一个文档");
    }
    await core.executeAsModal(async (context) => {
      let suspensionID = null;
      try {
        suspensionID = await context.hostControl.suspendHistory({
          "documentID": targetDoc.id,
          "name": "Place Image Centered"
        });
        const tokenStartTime = performance.now();
        let token;
        if (!imageData) {
          throw new Error("No image data available");
        }
        if (imageData.startsWith("data:image")) {
          const fileInfo = await saveBase64ToTempFile(imageData);
          token = fileInfo.token;
        } else if (imageData.startsWith("blob:") || imageData.startsWith("http")) {
          const fileInfo = await saveUrlToTempFile(imageData);
          token = fileInfo.token;
        } else {
          const entry = await fs.getEntryWithUrl(imageData);
          token = await fs.createSessionToken(entry);
        }
        console.log(`[PlaceCentered] Token generation: ${(performance.now() - tokenStartTime).toFixed(2)}ms`);
        const placeStartTime = performance.now();
        await action.batchPlay(
          [
            {
              _obj: "placeEvent",
              ID: 1,
              null: {
                _path: token,
                _kind: "local"
              },
              linked: false,
              freeTransformCenterState: {
                _enum: "quadCenterState",
                _value: "QCSAverage"
              },
              offset: {
                _obj: "offset",
                horizontal: { _unit: "pixelsUnit", _value: 0 },
                vertical: { _unit: "pixelsUnit", _value: 0 }
              },
              _options: {
                dialogOptions: "dontDisplay"
              }
            }
          ],
          {
            synchronousExecution: true,
            modalBehavior: "execute",
            historyStateInfo: {
              name: "Place Smart Object",
              target: { _ref: "document", _enum: "ordinal", _value: "targetEnum" }
            }
          }
        );
        console.log(`[PlaceCentered] Smart Object placed (no rasterize): ${(performance.now() - placeStartTime).toFixed(2)}ms`);
        const newLayer = targetDoc.activeLayers[0];
        if (!newLayer) {
          throw new Error("无法获取新创建的图层");
        }
        const layerBounds = newLayer.bounds;
        const layerWidth = layerBounds.right - layerBounds.left;
        const layerHeight = layerBounds.bottom - layerBounds.top;
        const docWidth = targetDoc.width;
        const docHeight = targetDoc.height;
        let scaleFactor = 1;
        if (imageWidth && imageHeight) ;
        else {
          const widthRatio = docWidth / layerWidth;
          const heightRatio = docHeight / layerHeight;
          scaleFactor = Math.min(widthRatio, heightRatio);
          if (scaleFactor > 1) {
            scaleFactor = 1;
          }
        }
        if (scaleFactor !== 1) {
          const scaleStartTime = performance.now();
          await action.batchPlay(
            [
              {
                _obj: "transform",
                _target: [
                  {
                    _ref: "layer",
                    _enum: "ordinal",
                    _value: "targetEnum"
                  }
                ],
                freeTransformCenterState: {
                  _enum: "quadCenterState",
                  _value: "QCSAverage"
                },
                width: {
                  _unit: "percentUnit",
                  _value: scaleFactor * 100
                },
                height: {
                  _unit: "percentUnit",
                  _value: scaleFactor * 100
                },
                _options: {
                  dialogOptions: "dontDisplay"
                }
              }
            ],
            {
              synchronousExecution: true,
              modalBehavior: "execute"
            }
          );
          console.log(`[PlaceCentered] Scale transform: ${(performance.now() - scaleStartTime).toFixed(2)}ms`);
        }
        if (layerName) {
          await action.batchPlay(
            [
              {
                _obj: "set",
                _target: [
                  {
                    _ref: "layer",
                    _enum: "ordinal",
                    _value: "targetEnum"
                  }
                ],
                to: {
                  _obj: "layer",
                  name: layerName
                },
                _options: {
                  dialogOptions: "dontDisplay"
                }
              }
            ],
            {
              synchronousExecution: true,
              modalBehavior: "execute",
              historyStateInfo: {
                name: "Rename Layer",
                target: { _ref: "document", _enum: "ordinal", _value: "targetEnum" }
              }
            }
          );
        }
        const totalTime = performance.now() - startTime;
        console.log(`[PlaceCentered] ✅ 图片已居中放置到画布 (总耗时: ${totalTime.toFixed(2)}ms)`);
      } catch (error) {
        console.error("[PlaceCentered] 放置失败:", error);
        throw error;
      } finally {
        if (suspensionID) {
          await context.hostControl.resumeHistory(suspensionID);
        }
      }
    }, {
      commandName: "Place Image Centered",
      interactive: false
    });
  };
  const imagePlacement = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createSessionTokenFromImageData,
    placeImageCentered,
    placeImageOnCanvasAsNewLayer,
    placeImageToSelection,
    placeImageUsingToken,
    placeImageUsingTokenNoScale
  }, Symbol.toStringTag, { value: "Module" }));
  const { localFileSystem, formats } = require("uxp").storage;
  class TokenPreheatService {
    constructor() {
      __publicField(this, "cache", /* @__PURE__ */ new Map());
      __publicField(this, "CACHE_TTL", 5 * 60 * 1e3);
      // 5分钟有效期
      __publicField(this, "MAX_CACHE_SIZE", 10);
    }
    // 最多缓存10个token
    /**
     * 生成Base64内容的哈希值
     */
    hashBase64(base64Content) {
      return base64Content.substring(0, 100);
    }
    /**
     * 异步预热:将Base64转换为Token
     * ⚠️ 注意: 此方法不使用executeAsModal，避免与用户操作冲突
     */
    async preheatToken(base64Data) {
      const base64Content = base64Data.split(",")[1];
      const hash = this.hashBase64(base64Content);
      const cached = this.cache.get(hash);
      if (cached) {
        const age = Date.now() - cached.result.timestamp;
        if (age < this.CACHE_TTL) {
          console.log("[TokenPreheat] 使用缓存Token, age:", age, "ms");
          return cached.result;
        } else {
          console.log("[TokenPreheat] 缓存Token过期, age:", age, " ms");
          this.cache.delete(hash);
        }
      }
      console.log("[TokenPreheat] 开始预热Token...");
      const startTime = performance.now();
      try {
        const binaryString = atob(base64Content);
        const arrayBuffer = Uint8Array.from(binaryString, (c) => c.charCodeAt(0)).buffer;
        const tempFolder = await localFileSystem.getTemporaryFolder();
        const fileName = `preheat_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.png`;
        const file = await tempFolder.createFile(fileName, { overwrite: true });
        await file.write(arrayBuffer, { format: formats.binary });
        const token = await localFileSystem.createSessionToken(file);
        const endTime = performance.now();
        console.log(`[TokenPreheat] 预热完成,耗时: ${(endTime - startTime).toFixed(2)}ms`);
        const result = {
          token,
          tempPath: file.nativePath,
          timestamp: Date.now()
        };
        if (this.cache.size >= this.MAX_CACHE_SIZE) {
          const oldestKey = this.cache.keys().next().value;
          this.cache.delete(oldestKey);
          console.log("[TokenPreheat] LRU淘汰最旧token");
        }
        this.cache.set(hash, { result, base64Hash: hash });
        return result;
      } catch (error) {
        console.error("[TokenPreheat] 预热失败:", error);
        throw error;
      }
    }
    /**
     * 清理指定token
     */
    async cleanupToken(tempPath) {
      try {
        const tempFolder = await localFileSystem.getTemporaryFolder();
        const parts = tempPath.split(/[/\\]/);
        const fileName = parts[parts.length - 1];
        if (fileName) {
          const file = await tempFolder.getEntry(fileName);
          await file.delete();
          console.log("[TokenPreheat] 临时文件已删除:", fileName);
        }
      } catch (error) {
        console.warn("[TokenPreheat] 清理临时文件失败:", error);
      }
    }
    /**
     * 清理所有缓存
     */
    clearCache() {
      this.cache.clear();
      console.log("[TokenPreheat] 缓存已清空");
    }
  }
  const tokenPreheatService = new TokenPreheatService();
  require("uxp").storage.localFileSystem;
  require("uxp").storage.formats;
  class PixelPreheatService {
    constructor() {
      __publicField(this, "cache", /* @__PURE__ */ new Map());
      __publicField(this, "CACHE_TTL", 5 * 60 * 1e3);
      __publicField(this, "MAX_CACHE_SIZE", 5);
    }
    hashBase64(base64Content) {
      return base64Content.substring(0, 100);
    }
    /**
     * 预热像素数据：将 Base64 解码为 ArrayBuffer
     */
    async preheatPixels(base64Data, width, height) {
      try {
        const base64Content = base64Data.split(",")[1];
        const hash = this.hashBase64(base64Content);
        const cached = this.cache.get(hash);
        if (cached) {
          const age = Date.now() - cached.result.timestamp;
          if (age < this.CACHE_TTL) {
            console.log("[PixelPreheat] ⚡ 使用缓存的 ArrayBuffer");
            return cached.result;
          } else {
            console.log("[PixelPreheat] 缓存 ArrayBuffer 过期, age:", age, "ms");
            this.cache.delete(hash);
          }
        }
        console.log("[PixelPreheat] ⚡ 开始 ArrayBuffer 预热...");
        const binaryString = atob(base64Content);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const arrayBuffer = bytes.buffer;
        let imgWidth = width;
        let imgHeight = height;
        if (!imgWidth || !imgHeight) {
          const view = new DataView(arrayBuffer);
          if (view.getUint32(0) === 2303741511) {
            imgWidth = view.getUint32(16);
            imgHeight = view.getUint32(20);
            console.log(`[PixelPreheat] 从 PNG 头解析尺寸: ${imgWidth} x ${imgHeight}`);
          }
        }
        if (!imgWidth || !imgHeight) {
          console.warn("[PixelPreheat] 无法获取图片尺寸，使用默认值");
          imgWidth = 1024;
          imgHeight = 1024;
        }
        console.log(`[PixelPreheat] ✅ ArrayBuffer 预热成功, 尺寸: ${imgWidth} x ${imgHeight}`);
        const result = {
          arrayBuffer,
          width: imgWidth,
          height: imgHeight,
          timestamp: Date.now()
        };
        if (this.cache.size >= this.MAX_CACHE_SIZE) {
          const oldestKey = this.cache.keys().next().value;
          this.cache.delete(oldestKey);
          console.log("[PixelPreheat] LRU淘汰最旧 ArrayBuffer");
        }
        this.cache.set(hash, { result, base64Hash: hash });
        return result;
      } catch (e) {
        console.error("[PixelPreheat] ❌ ArrayBuffer 预热失败:", e);
        return null;
      }
    }
    /**
     * 清理缓存
     */
    clearCache() {
      console.log("[PixelPreheat] 清理 ArrayBuffer 缓存...");
      this.cache.clear();
    }
  }
  const pixelPreheatService = new PixelPreheatService();
  class PerformanceMonitor {
    static start(operation) {
      this.startTime = performance.now();
      this.operationName = operation;
      console.log(`[Performance] 开始 ${operation}`);
    }
    static end() {
      const duration = performance.now() - this.startTime;
      console.log(`[Performance] ${this.operationName} 耗时: ${duration.toFixed(2)}ms`);
      if (duration > 1e3) {
        console.warn(`[Performance] ${this.operationName} 耗时过长: ${duration.toFixed(2)}ms`);
      }
      return duration;
    }
    static measure(operation, fn) {
      return new Promise(async (resolve, reject) => {
        this.start(operation);
        try {
          const result = await fn();
          this.end();
          resolve(result);
        } catch (error) {
          this.end();
          reject(error);
        }
      });
    }
  }
  __publicField(PerformanceMonitor, "startTime", 0);
  __publicField(PerformanceMonitor, "operationName", "");
  class ImageProcessingError extends Error {
    constructor(message, code, userMessage, canRetry = false) {
      super(message);
      this.code = code;
      this.userMessage = userMessage;
      this.canRetry = canRetry;
      this.name = "ImageProcessingError";
    }
  }
  const handleImageProcessingError = (error) => {
    const errorMap = {
      "No active document": {
        message: "没有活动的Photoshop文档",
        canRetry: false
      },
      "No image data available": {
        message: "图片数据不可用",
        canRetry: false
      },
      "Memory allocation failed": {
        message: "内存分配失败，请尝试较小的图片",
        canRetry: true
      },
      "Unsupported format": {
        message: "不支持的图片格式",
        canRetry: false
      },
      "Failed to load image for dimension detection": {
        message: "图片加载失败",
        canRetry: true
      }
    };
    const errorMessage = (error == null ? void 0 : error.message) || String(error);
    const errorInfo = errorMap[errorMessage] || {
      message: "未知错误",
      canRetry: true
    };
    return new ImageProcessingError(
      errorMessage,
      "IMAGE_PROCESSING_ERROR",
      errorInfo.message,
      errorInfo.canRetry
    );
  };
  const getUserFriendlyErrorMessage = (error) => {
    const processedError = handleImageProcessingError(error);
    return processedError.userMessage;
  };
  const imagingConfig = {
    /** 最大图像尺寸（宽或高）- 4096px */
    maxImageSize: 4096,
    /** 内存限制（字节）- 100MB */
    memoryLimit: 100 * 1024 * 1024,
    /** 启用性能监控 */
    enablePerformanceMonitoring: true,
    /** 记录慢操作 */
    logSlowOperations: true,
    /** 慢操作阈值（毫秒）- 1秒 */
    slowOperationThreshold: 1e3,
    /**
     * 🆕 生产环境优化
     * - 降低内存限制以避免浏览器崩溃
     * - 增加超时阈值以处理云端请求
     */
    production: {
      maxImageSize: 2048,
      // 生产环境降低至 2048px
      memoryLimit: 80 * 1024 * 1024,
      // 80MB
      timeout: 6e4
      // 云端请求超时 60 秒
    }
  };
  const PROXY_CONFIG = {
    /** 代理服务器基础 URL */
    baseURL: "https://thebigone.cc",
    /** 上传 API 路径 */
    uploadPath: "/api/upload",
    /** 请求超时时间（毫秒）- 5分钟 */
    timeout: 5 * 60 * 1e3,
    /** ⭐ 新增: 本地后端 URL (用于 animle.py 等本地工作流) */
    localBackendURL: "http://127.0.0.1:8787"
  };
  const ROUTE_CONFIG = {
    domestic: {
      name: "国内线路",
      // 之前确认可用的地址（域名 + HTTPS）
      baseURL: "https://thebigone.cc",
      healthUrl: "https://thebigone.cc/health"
    },
    overseas: {
      name: "国外线路",
      baseURL: "https://sg.thebigone.top",
      healthUrl: "https://sg.thebigone.top/health"
    }
  };
  const ROUTE_STORAGE_KEY = "ps_plugin_selected_route";
  let _lastLoggedBaseURL = "";
  const getProxyBaseURL = () => {
    try {
      const selected = localStorage.getItem(ROUTE_STORAGE_KEY);
      if (selected && ROUTE_CONFIG[selected]) {
        const url = ROUTE_CONFIG[selected].baseURL;
        if (url !== _lastLoggedBaseURL) {
          _lastLoggedBaseURL = url;
          console.log(`[Route] 使用线路: ${ROUTE_CONFIG[selected].name} → ${url}`);
        }
        return url;
      }
    } catch {
    }
    const defaultURL = ROUTE_CONFIG.domestic.baseURL;
    if (defaultURL !== _lastLoggedBaseURL) {
      _lastLoggedBaseURL = defaultURL;
      console.log(`[Route] 使用默认线路: ${ROUTE_CONFIG.domestic.name} → ${defaultURL}`);
    }
    return defaultURL;
  };
  const setProxyRoute = (route) => {
    try {
      localStorage.setItem(ROUTE_STORAGE_KEY, route);
      const config = ROUTE_CONFIG[route];
      console.log(`[Route] ✅ 线路已切换 → ${config.name} (${config.baseURL})`);
    } catch {
      console.warn("[Route] ❌ 切换线路失败");
    }
  };
  const getProxyRoute = () => {
    try {
      const selected = localStorage.getItem(ROUTE_STORAGE_KEY);
      if (selected && ROUTE_CONFIG[selected]) {
        return selected;
      }
    } catch {
    }
    return "domestic";
  };
  const isOverseasRoute = () => {
    return getProxyRoute() === "overseas";
  };
  const getLocalBackendApiUrl = (path) => {
    return `${PROXY_CONFIG.localBackendURL}${path.startsWith("/") ? path : "/" + path}`;
  };
  const captureCanvasUsingImagingAPI = async () => {
    console.log("[Imaging Capture] ========== 开始使用 Imaging API 捕获画布 ==========");
    {
      PerformanceMonitor.start("Imaging API 画布捕获");
    }
    try {
      console.log("[Imaging Capture] 步骤1: 在 executeAsModal 中获取像素数据...");
      if (!photoshop.app.activeDocument) {
        throw new Error("没有活动文档");
      }
      const base64Data = await photoshop.core.executeAsModal(
        async () => {
          var _a2;
          console.log("[Imaging Capture] 进入 executeAsModal...");
          const { imaging, app } = require("photoshop");
          console.log("[Imaging Capture] imaging 模块:", !!imaging);
          console.log("[Imaging Capture] 活动文档:", (_a2 = app.activeDocument) == null ? void 0 : _a2.name);
          if (!imaging || !imaging.getPixels) {
            throw new Error("Imaging API 的 getPixels 方法不可用");
          }
          if (!app.activeDocument) {
            throw new Error("没有活动文档");
          }
          console.log("[Imaging Capture] 步骤2: 调用 imaging.getPixels()...");
          const pixelData = await imaging.getPixels({
            applyAlpha: true
            // 将 RGBA 转换为 RGB（在白色背景上合成）
          });
          console.log("[Imaging Capture] 像素数据获取成功:", {
            width: pixelData.imageData.width,
            height: pixelData.imageData.height,
            hasAlpha: pixelData.imageData.hasAlpha,
            componentSize: pixelData.imageData.componentSize
          });
          console.log("[Imaging Capture] 步骤3: 调用 imaging.encodeImageData()...");
          const encodedResult = await imaging.encodeImageData({
            imageData: pixelData.imageData,
            base64: false,
            // ⭐ 关闭 Base64
            format: "jpeg"
            // ⭐ 锁定 JPEG 格式
          });
          console.log("[Imaging Capture] 编码成功:", {
            hasData: !!encodedResult,
            type: typeof encodedResult,
            byteLength: encodedResult == null ? void 0 : encodedResult.byteLength
          });
          console.log("[Imaging Capture] 清理像素数据...");
          pixelData.imageData.dispose();
          console.log("[Imaging Capture] 像素数据已清理");
          return encodedResult;
        },
        { commandName: "Capture Canvas Using Imaging API" }
      );
      console.log("[Imaging Capture] ========== 画布捕获完成 ==========");
      if (imagingConfig.enablePerformanceMonitoring) {
        PerformanceMonitor.end();
      }
      return base64Data;
    } catch (error) {
      console.error("[Imaging Capture] ========== 捕获失败 ==========");
      console.error("[Imaging Capture] 错误详情:", error);
      console.error("[Imaging Capture] 错误消息:", error == null ? void 0 : error.message);
      console.error("[Imaging Capture] 错误堆栈:", error == null ? void 0 : error.stack);
      {
        PerformanceMonitor.end();
      }
      throw error;
    }
  };
  const exportMaskFromSelection = async () => {
    console.log("[Mask Export] ========== 开始提取选区蒙版 (getSelection 模式) ==========");
    {
      PerformanceMonitor.start("选区蒙版提取");
    }
    try {
      const doc = photoshop.app.activeDocument;
      if (!doc) {
        throw new Error("没有活动文档");
      }
      const docWidth = doc.width;
      const docHeight = doc.height;
      const result = await photoshop.core.executeAsModal(
        async () => {
          const { imaging } = require("photoshop");
          console.log("[Mask Export] 步骤1: 调用 imaging.getSelection()...");
          const selectionObj = await imaging.getSelection({
            documentID: doc.id
          });
          if (!selectionObj) {
            throw new Error("⚠️ 请先使用选区工具勾选需要重绘的区域！");
          }
          const { imageData, sourceBounds } = selectionObj;
          console.log("[Mask Export] 选区边界:", sourceBounds);
          const maskData = await imageData.getData();
          const fullRgbData = new Uint8Array(docWidth * docHeight * 3);
          const selWidth = imageData.width;
          const selHeight = imageData.height;
          for (let y = 0; y < selHeight; y++) {
            for (let x = 0; x < selWidth; x++) {
              const srcIdx = y * selWidth + x;
              const val = maskData[srcIdx];
              const globalX = sourceBounds.left + x;
              const globalY = sourceBounds.top + y;
              if (globalX >= 0 && globalX < docWidth && globalY >= 0 && globalY < docHeight) {
                const dstIdx = (globalY * docWidth + globalX) * 3;
                fullRgbData[dstIdx] = val;
                fullRgbData[dstIdx + 1] = val;
                fullRgbData[dstIdx + 2] = val;
              }
            }
          }
          console.log("[Mask Export] 步骤2: 编码为 JPEG...");
          const maskImageData = await imaging.createImageDataFromBuffer(fullRgbData, {
            width: docWidth,
            height: docHeight,
            components: 3,
            colorSpace: "RGB",
            colorProfile: "sRGB IEC61966-2.1"
          });
          const encodedJpeg = await imaging.encodeImageData({
            imageData: maskImageData,
            base64: false,
            format: "jpeg"
          });
          imageData.dispose();
          maskImageData.dispose();
          return {
            maskData: encodedJpeg,
            bounds: sourceBounds
          };
        },
        { commandName: "Export Mask (getSelection Mode)" }
      );
      console.log("[Mask Export] 蒙版提取完成，大小:", result.maskData.byteLength);
      if (imagingConfig.enablePerformanceMonitoring) PerformanceMonitor.end();
      return result;
    } catch (error) {
      console.error("[Mask Export] 失败:", error);
      PerformanceMonitor.end();
      throw error;
    }
  };
  const uploadImageWithPresign = async (imageData, fileName) => {
    console.log("[Presign Upload] ========== 开始 presign 直传 ==========");
    const baseURL = getProxyBaseURL();
    const presignUrl = `${baseURL}/api/upload/presign`;
    const name = fileName || `upload_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.png`;
    try {
      const token = localStorage.getItem("ps_plugin_token") || "";
      console.log("[Presign Upload] 请求 presign:", presignUrl, "文件名:", name);
      const res = await fetch(presignUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          filename: name,
          contentType: "image/png"
        })
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`presign 失败 (${res.status}): ${text}`);
      }
      const result = await res.json();
      const { uploadUrl, publicUrl } = result.data || result;
      if (!uploadUrl || !publicUrl) {
        throw new Error("presign 响应缺少 uploadUrl 或 publicUrl");
      }
      console.log("[Presign Upload] 获取 presign URL 成功");
      const blob = new Blob([imageData], { type: "image/png" });
      const putRes = await fetch(uploadUrl, {
        method: "PUT",
        body: blob,
        headers: { "Content-Type": "image/png" }
      });
      if (!putRes.ok) {
        throw new Error(`R2 直传失败 (${putRes.status})`);
      }
      console.log("[Presign Upload] ========== ✅ 直传成功 ==========");
      console.log("[Presign Upload] publicUrl:", publicUrl);
      return publicUrl;
    } catch (error) {
      console.error("[Presign Upload] ========== ❌ 直传失败 ==========");
      console.error("[Presign Upload] 错误:", error);
      throw error;
    }
  };
  const uploadImageToBizyAir = async (imageData, options) => {
    if (isOverseasRoute()) {
      return uploadImageWithPresign(imageData);
    }
    console.log("[Proxy Upload] ========== 开始上传到代理服务器 ==========");
    try {
      console.log("[Proxy Upload] 步骤 1/2: 生成文件名...");
      const timestamp = Date.now();
      const random = Math.random().toString(36).substring(2, 8);
      const fileName = `upload_${timestamp}_${random}.png`;
      console.log("[Proxy Upload] 文件名:", fileName);
      console.log("[Proxy Upload] 步骤 2/2: 发送二进制数据到代理服务器...");
      const uploadUrl = `${getProxyBaseURL()}${PROXY_CONFIG.uploadPath}`;
      console.log("[Proxy Upload] API URL:", uploadUrl);
      console.log("[Proxy Upload] 二进制数据大小:", imageData.byteLength, "bytes");
      const responseText = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.timeout = PROXY_CONFIG.timeout;
        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable && (options == null ? void 0 : options.onProgress)) {
            const progress = Math.round(event.loaded / event.total * 100);
            options.onProgress(progress, event.loaded, event.total);
          }
        };
        xhr.onload = function() {
          console.log("[Proxy Upload] XHR 响应状态:", xhr.status, xhr.statusText);
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve(xhr.responseText);
          } else {
            console.error("[Proxy Upload] XHR 错误响应:", xhr.responseText);
            reject(new Error(`HTTP ${xhr.status}: ${xhr.responseText}`));
          }
        };
        xhr.onerror = function() {
          console.error("[Proxy Upload] XHR 网络错误");
          reject(new Error("无法连接到代理服务器，请检查网络连接和服务器地址"));
        };
        xhr.ontimeout = function() {
          console.error("[Proxy Upload] XHR 请求超时");
          reject(new Error("请求超时，请检查网络连接"));
        };
        xhr.onabort = function() {
          console.log("[Proxy Upload] XHR 请求已取消");
          reject(new Error("请求已取消"));
        };
        console.log("[Proxy Upload] 开始发送 XHR 请求 (二进制模式)...");
        xhr.open("POST", uploadUrl, true);
        try {
          const token = localStorage.getItem("ps_plugin_token");
          if (token) {
            xhr.setRequestHeader("Authorization", `Bearer ${token}`);
          }
        } catch {
        }
        const formData = new FormData();
        formData.append("image", new Blob([imageData], { type: "image/png" }), fileName);
        formData.append("fileName", fileName);
        xhr.send(formData);
      });
      console.log("[Proxy Upload] 响应状态: 200 OK");
      const result = JSON.parse(responseText);
      console.log("[Proxy Upload] 响应数据:", result);
      if (!result.url) {
        throw new Error("响应中缺少 URL 字段");
      }
      console.log("[Proxy Upload] ========== ✅ 上传成功! ==========");
      console.log("[Proxy Upload] BizyAir URL:", result.url);
      console.log("[Proxy Upload] Object Key:", result.object_key);
      console.log("[Proxy Upload] Resource ID:", result.id);
      return result.url;
    } catch (error) {
      console.error("[Proxy Upload] ========== ❌ 上传失败 ==========");
      console.error("[Proxy Upload] 错误详情:", error);
      if (error instanceof Error) {
        if (error.name === "AbortError") {
          console.log("[Proxy Upload] 用户取消上传");
          throw new Error("上传已取消");
        }
        if (error.message.includes("fetch")) {
          throw new Error("无法连接到代理服务器，请检查服务器地址: " + getProxyBaseURL());
        }
      }
      throw error;
    }
  };
  const uploadInpaintingImages = async (sourceImageData, maskImageData, options) => {
    console.log("[Inpainting Upload] ========== 开始上传双图（原图 + 蒙版）===========");
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8);
    const sourceFileName = `source_${timestamp}_${random}.png`;
    const maskFileName = `mask_${timestamp}_${random}.png`;
    if (isOverseasRoute()) {
      console.log("[Inpainting Upload] 国外线路，使用 presign 直传");
      const [sourceUrl, maskUrl] = await Promise.all([
        uploadImageWithPresign(sourceImageData, sourceFileName),
        uploadImageWithPresign(maskImageData, maskFileName)
      ]);
      console.log("[Inpainting Upload] ========== ✅ 双图 presign 上传成功 ==========");
      return { sourceUrl, maskUrl };
    }
    try {
      console.log("[Inpainting Upload] 原图文件名:", sourceFileName);
      console.log("[Inpainting Upload] 蒙版文件名:", maskFileName);
      console.log("[Inpainting Upload] 原图大小:", sourceImageData.byteLength, "bytes");
      console.log("[Inpainting Upload] 蒙版大小:", maskImageData.byteLength, "bytes");
      const uploadUrl = `${getProxyBaseURL()}${PROXY_CONFIG.uploadPath}`;
      console.log("[Inpainting Upload] API URL:", uploadUrl);
      const uploadSingleFile = async (data, fileName, label, retries = 2) => {
        return new Promise((resolve, reject) => {
          const attemptUpload = (attempt) => {
            const xhr = new XMLHttpRequest();
            xhr.timeout = PROXY_CONFIG.timeout;
            if (label === "source" && (options == null ? void 0 : options.onProgress)) {
              xhr.upload.onprogress = (event) => {
                if (event.lengthComputable) {
                  const progress = Math.round(event.loaded / event.total * 100);
                  options.onProgress(progress, event.loaded, event.total);
                }
              };
            }
            xhr.onload = function() {
              if (xhr.status >= 200 && xhr.status < 300) {
                try {
                  const result = JSON.parse(xhr.responseText);
                  if (result.url) {
                    console.log(`[Inpainting Upload] ${label} 上传成功:`, result.url);
                    resolve(result.url);
                  } else {
                    reject(new Error(`${label} 响应缺少 URL`));
                  }
                } catch (e) {
                  reject(new Error(`${label} 响应解析失败`));
                }
              } else {
                console.error(`[Inpainting Upload] ${label} XHR 错误响应:`, xhr.responseText);
                let errorMsg = `HTTP ${xhr.status}`;
                if (xhr.responseText.includes("MulterError")) {
                  errorMsg += ": MulterError (字段名不匹配)";
                }
                reject(new Error(errorMsg));
              }
            };
            xhr.onerror = () => {
              if (attempt < retries) {
                console.log(`[Inpainting Upload] ${label} 网络错误，重试 ${attempt + 1}/${retries}...`);
                setTimeout(() => attemptUpload(attempt + 1), 1e3);
              } else {
                reject(new Error(`${label} 网络错误 (已重试 ${retries} 次)`));
              }
            };
            xhr.ontimeout = () => {
              if (attempt < retries) {
                console.log(`[Inpainting Upload] ${label} 超时，重试 ${attempt + 1}/${retries}...`);
                setTimeout(() => attemptUpload(attempt + 1), 1e3);
              } else {
                reject(new Error(`${label} 请求超时 (已重试 ${retries} 次)`));
              }
            };
            xhr.onabort = () => reject(new Error(`${label} 请求取消`));
            console.log(`[Inpainting Upload] 开始上传 ${label}${attempt > 0 ? ` (重试 ${attempt})` : ""}...`);
            xhr.open("POST", uploadUrl, true);
            const formData = new FormData();
            formData.append("image", new Blob([data], { type: "image/jpeg" }), fileName);
            formData.append("fileName", fileName);
            xhr.send(formData);
          };
          attemptUpload(0);
        });
      };
      console.log("[Inpainting Upload] 启动并行上传任务...");
      const [sourceUrl, maskUrl] = await Promise.all([
        uploadSingleFile(sourceImageData, sourceFileName, "source"),
        uploadSingleFile(maskImageData, maskFileName, "mask")
      ]);
      console.log("[Inpainting Upload] ========== ✅ 双图上传成功! ==========");
      console.log("[Inpainting Upload] 原图 URL:", sourceUrl);
      console.log("[Inpainting Upload] 蒙版 URL:", maskUrl);
      return { sourceUrl, maskUrl };
    } catch (error) {
      console.error("[Inpainting Upload] ========== ❌ 双图上传失败 ==========");
      console.error("[Inpainting Upload] 错误详情:", error);
      throw error;
    }
  };
  const imageUpload = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    uploadImageToBizyAir,
    uploadInpaintingImages
  }, Symbol.toStringTag, { value: "Module" }));
  const psAny = photoshop;
  ((_c = psAny == null ? void 0 : psAny.core) == null ? void 0 : _c.executeAsModal) ?? (async (fn) => await fn());
  ((_d = psAny == null ? void 0 : psAny.action) == null ? void 0 : _d.batchPlay) ?? (async () => {
    throw new Error("Photoshop batchPlay is not available in this environment");
  });
  const roundToMultipleOf8 = (value) => {
    return Math.round(value / 8) * 8;
  };
  const getActiveDocumentDimensions = async () => {
    const doc = photoshop.app.activeDocument;
    if (!doc) {
      throw new Error("No active document found");
    }
    return {
      width: doc.width,
      height: doc.height
    };
  };
  const getSelectionBounds = async () => {
    var _a2, _b2, _c2, _d2, _e, _f, _g, _h, _i, _j, _k;
    const doc = photoshop.app.activeDocument;
    if (!doc) return null;
    try {
      const b = (_a2 = doc.selection) == null ? void 0 : _a2.bounds;
      if (b && typeof b === "object") {
        const left = ((_b2 = b.left) == null ? void 0 : _b2._value) ?? b._left ?? b.left;
        const top = ((_c2 = b.top) == null ? void 0 : _c2._value) ?? b._top ?? b.top;
        const right = ((_d2 = b.right) == null ? void 0 : _d2._value) ?? b._right ?? b.right;
        const bottom = ((_e = b.bottom) == null ? void 0 : _e._value) ?? b._bottom ?? b.bottom;
        if ([left, top, right, bottom].every((v) => typeof v === "number")) {
          return {
            left,
            top,
            right,
            bottom,
            width: right - left,
            height: bottom - top
          };
        }
      }
    } catch {
    }
    try {
      const result = await photoshop.action.batchPlay(
        [
          {
            _obj: "get",
            _target: [
              { _property: "selection" },
              { _ref: "document", _enum: "ordinal", _value: "targetEnum" }
            ],
            _options: { dialogOptions: "dontDisplay" }
          }
        ],
        { synchronousExecution: true }
      );
      const bounds = (_g = (_f = result[0]) == null ? void 0 : _f.selection) == null ? void 0 : _g.bounds;
      if (!bounds) return null;
      const left = ((_h = bounds.left) == null ? void 0 : _h._value) ?? bounds._left;
      const top = ((_i = bounds.top) == null ? void 0 : _i._value) ?? bounds._top;
      const right = ((_j = bounds.right) == null ? void 0 : _j._value) ?? bounds._right;
      const bottom = ((_k = bounds.bottom) == null ? void 0 : _k._value) ?? bounds._bottom;
      if ([left, top, right, bottom].every((v) => typeof v === "number")) {
        return {
          left,
          top,
          right,
          bottom,
          width: right - left,
          height: bottom - top
        };
      }
      return null;
    } catch {
      return null;
    }
  };
  const getTargetDimensions = async () => {
    const selection = await getSelectionBounds();
    if (selection && selection.width > 0 && selection.height > 0) {
      return {
        width: roundToMultipleOf8(selection.width),
        height: roundToMultipleOf8(selection.height)
      };
    }
    const docDimensions = await getActiveDocumentDimensions();
    return {
      width: roundToMultipleOf8(docDimensions.width),
      height: roundToMultipleOf8(docDimensions.height)
    };
  };
  var ErrorLevel = /* @__PURE__ */ ((ErrorLevel2) => {
    ErrorLevel2["RECOVERABLE"] = "recoverable";
    ErrorLevel2["NON_RECOVERABLE"] = "non_recoverable";
    return ErrorLevel2;
  })(ErrorLevel || {});
  var ErrorCategory = /* @__PURE__ */ ((ErrorCategory2) => {
    ErrorCategory2["NETWORK_TIMEOUT"] = "network_timeout";
    ErrorCategory2["PERMISSION_DENIED"] = "permission_denied";
    ErrorCategory2["FILE_CORRUPTED"] = "file_corrupted";
    ErrorCategory2["API_CHANGED"] = "api_changed";
    ErrorCategory2["UNKNOWN"] = "unknown";
    return ErrorCategory2;
  })(ErrorCategory || {});
  const ErrorCodeMap = {
    "NET_TIMEOUT": {
      code: "NET_TIMEOUT",
      category: ErrorCategory.NETWORK_TIMEOUT,
      level: ErrorLevel.RECOVERABLE,
      keywords: ["timeout", "timed out", "ETIMEDOUT", "request timeout", "connection timeout"]
    },
    "NET_CONNECTION_REFUSED": {
      code: "NET_CONNECTION_REFUSED",
      category: ErrorCategory.NETWORK_TIMEOUT,
      level: ErrorLevel.RECOVERABLE,
      keywords: ["ECONNREFUSED", "connection refused", "connection reset"]
    },
    "NET_DNS_ERROR": {
      code: "NET_DNS_ERROR",
      category: ErrorCategory.NETWORK_TIMEOUT,
      level: ErrorLevel.RECOVERABLE,
      keywords: ["ENOTFOUND", "dns", "getaddrinfo", "name or service not known"]
    },
    "NET_NETWORK_UNAVAILABLE": {
      code: "NET_NETWORK_UNAVAILABLE",
      category: ErrorCategory.NETWORK_TIMEOUT,
      level: ErrorLevel.RECOVERABLE,
      keywords: ["network", "unavailable", "offline", "no internet"]
    },
    "PERM_FILE_ACCESS": {
      code: "PERM_FILE_ACCESS",
      category: ErrorCategory.PERMISSION_DENIED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["permission denied", "EACCES", "access denied", "unauthorized"]
    },
    "PERM_LOCALFS": {
      code: "PERM_LOCALFS",
      category: ErrorCategory.PERMISSION_DENIED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["localfilesystem permission denied", "localfilesystem", "uxp permission"]
    },
    "PERM_CLIPBOARD": {
      code: "PERM_CLIPBOARD",
      category: ErrorCategory.PERMISSION_DENIED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["clipboard", "permission denied"]
    },
    "PERM_NETWORK": {
      code: "PERM_NETWORK",
      category: ErrorCategory.PERMISSION_DENIED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["network permission", "domain not allowed"]
    },
    "FILE_NOT_FOUND": {
      code: "FILE_NOT_FOUND",
      category: ErrorCategory.FILE_CORRUPTED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["ENOENT", "file not found", "no such file"]
    },
    "FILE_CORRUPTED": {
      code: "FILE_CORRUPTED",
      category: ErrorCategory.FILE_CORRUPTED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["corrupt", "invalid", "malformed", "parse error"]
    },
    "FILE_TOO_LARGE": {
      code: "FILE_TOO_LARGE",
      category: ErrorCategory.FILE_CORRUPTED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["file too large", "size limit", "max size"]
    },
    "FILE_READ_ERROR": {
      code: "FILE_READ_ERROR",
      category: ErrorCategory.FILE_CORRUPTED,
      level: ErrorLevel.RECOVERABLE,
      keywords: ["read error", "EIO", "read failed"]
    },
    "FILE_WRITE_ERROR": {
      code: "FILE_WRITE_ERROR",
      category: ErrorCategory.FILE_CORRUPTED,
      level: ErrorLevel.RECOVERABLE,
      keywords: ["write error", "EIO", "write failed", "save failed"]
    },
    "API_DEPRECATED": {
      code: "API_DEPRECATED",
      category: ErrorCategory.API_CHANGED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["deprecated", "obsolete", "no longer supported"]
    },
    "API_NOT_FOUND": {
      code: "API_NOT_FOUND",
      category: ErrorCategory.API_CHANGED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["API not found", "method not found", "undefined is not a function"]
    },
    "API_VERSION_MISMATCH": {
      code: "API_VERSION_MISMATCH",
      category: ErrorCategory.API_CHANGED,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["version mismatch", "incompatible", "not supported in this version"]
    },
    "API_RESPONSE_INVALID": {
      code: "API_RESPONSE_INVALID",
      category: ErrorCategory.API_CHANGED,
      level: ErrorLevel.RECOVERABLE,
      keywords: ["invalid response", "parse error", "json parse"]
    },
    "UNK_RUNTIME_ERROR": {
      code: "UNK_RUNTIME_ERROR",
      category: ErrorCategory.UNKNOWN,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["runtime error", "uncaught", "unhandled"]
    },
    "UNK_REFERENCE_ERROR": {
      code: "UNK_REFERENCE_ERROR",
      category: ErrorCategory.UNKNOWN,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["ReferenceError", "is not defined"]
    },
    "UNK_TYPE_ERROR": {
      code: "UNK_TYPE_ERROR",
      category: ErrorCategory.UNKNOWN,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["TypeError", "cannot read", "is not a function"]
    },
    "UNK_SYNTAX_ERROR": {
      code: "UNK_SYNTAX_ERROR",
      category: ErrorCategory.UNKNOWN,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["SyntaxError", "parse error"]
    },
    "SYS_OUT_OF_MEMORY": {
      code: "SYS_OUT_OF_MEMORY",
      category: ErrorCategory.UNKNOWN,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["out of memory", "OOM", "memory limit"]
    },
    "SYS_STACK_OVERFLOW": {
      code: "SYS_STACK_OVERFLOW",
      category: ErrorCategory.UNKNOWN,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: ["stack overflow", "maximum call stack"]
    },
    "UNK_UNKNOWN": {
      code: "UNK_UNKNOWN",
      category: ErrorCategory.UNKNOWN,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: []
    }
  };
  function detectErrorCode(error) {
    const errorString = String(error).toLowerCase();
    const errorName = error instanceof Error ? error.name : "";
    const errorMessage = error instanceof Error ? error.message.toLowerCase() : "";
    for (const [code, definition] of Object.entries(ErrorCodeMap)) {
      for (const keyword of definition.keywords) {
        if (errorString.includes(keyword.toLowerCase()) || errorName.toLowerCase().includes(keyword.toLowerCase()) || errorMessage.includes(keyword.toLowerCase())) {
          return definition;
        }
      }
    }
    return {
      code: "UNK_UNKNOWN",
      category: ErrorCategory.UNKNOWN,
      level: ErrorLevel.NON_RECOVERABLE,
      keywords: []
    };
  }
  const ErrorMessageMap = {
    NET_TIMEOUT: {
      userMessage: "网络请求超时，请检查网络连接",
      suggestion: "请检查您的网络是否稳定，然后重试操作。如果问题持续存在，请稍后再试。",
      level: ErrorLevel.RECOVERABLE
    },
    NET_CONNECTION_REFUSED: {
      userMessage: "无法连接到服务器",
      suggestion: "服务器可能暂时不可用，请稍后重试。如果问题持续，请联系技术支持。",
      level: ErrorLevel.RECOVERABLE
    },
    NET_DNS_ERROR: {
      userMessage: "无法解析服务器地址",
      suggestion: "请检查网络连接，或尝试刷新页面。如果问题持续，请联系技术支持。",
      level: ErrorLevel.RECOVERABLE
    },
    NET_NETWORK_UNAVAILABLE: {
      userMessage: "网络不可用",
      suggestion: "请检查您的网络连接，确保设备已连接到互联网。",
      level: ErrorLevel.RECOVERABLE
    },
    PERM_FILE_ACCESS: {
      userMessage: "文件访问被拒绝",
      suggestion: "请检查文件权限设置，或尝试重新选择文件路径。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    PERM_LOCALFS: {
      userMessage: "本地文件系统权限不足",
      suggestion: "请在插件设置中授予本地文件系统访问权限，然后重启插件。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    PERM_CLIPBOARD: {
      userMessage: "剪贴板访问被拒绝",
      suggestion: "请在插件设置中授予剪贴板访问权限。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    PERM_NETWORK: {
      userMessage: "网络访问被拒绝",
      suggestion: "请在插件设置中检查网络域名配置，确保目标域名已添加到允许列表。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    FILE_NOT_FOUND: {
      userMessage: "文件未找到",
      suggestion: "请确认文件路径是否正确，文件是否已被移动或删除。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    FILE_CORRUPTED: {
      userMessage: "文件已损坏",
      suggestion: "请尝试重新获取原始文件，或使用备份文件。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    FILE_TOO_LARGE: {
      userMessage: "文件过大",
      suggestion: "请选择较小的文件，或调整文件大小后重试。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    FILE_READ_ERROR: {
      userMessage: "文件读取失败",
      suggestion: "请检查文件是否被其他程序占用，或尝试重新读取。",
      level: ErrorLevel.RECOVERABLE
    },
    FILE_WRITE_ERROR: {
      userMessage: "文件保存失败",
      suggestion: "请检查磁盘空间是否充足，或尝试更换保存路径。",
      level: ErrorLevel.RECOVERABLE
    },
    API_DEPRECATED: {
      userMessage: "该功能已被弃用",
      suggestion: "请更新插件到最新版本，或使用替代功能。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    API_NOT_FOUND: {
      userMessage: "功能不可用",
      suggestion: "请更新插件到最新版本，或联系技术支持获取帮助。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    API_VERSION_MISMATCH: {
      userMessage: "版本不兼容",
      suggestion: "请更新 Photoshop 或插件到最新版本。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    API_RESPONSE_INVALID: {
      userMessage: "服务器响应无效",
      suggestion: "请稍后重试操作。如果问题持续，请联系技术支持。",
      level: ErrorLevel.RECOVERABLE
    },
    UNK_RUNTIME_ERROR: {
      userMessage: "运行时发生错误",
      suggestion: "请尝试刷新插件或重启 Photoshop。如果问题持续，请提交错误报告。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    UNK_REFERENCE_ERROR: {
      userMessage: "程序发生错误",
      suggestion: "请更新插件到最新版本，或提交错误报告。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    UNK_TYPE_ERROR: {
      userMessage: "程序发生错误",
      suggestion: "请更新插件到最新版本，或提交错误报告。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    UNK_SYNTAX_ERROR: {
      userMessage: "程序代码错误",
      suggestion: "请更新插件到最新版本。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    SYS_OUT_OF_MEMORY: {
      userMessage: "内存不足",
      suggestion: "请关闭其他程序释放内存，或减小处理文件的大小。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    SYS_STACK_OVERFLOW: {
      userMessage: "程序执行溢出",
      suggestion: "请尝试简化操作步骤，或重启 Photoshop。",
      level: ErrorLevel.NON_RECOVERABLE
    },
    UNK_UNKNOWN: {
      userMessage: "发生未知错误",
      suggestion: "请尝试刷新插件或重启 Photoshop。如果问题持续，请提交错误报告。",
      level: ErrorLevel.NON_RECOVERABLE
    }
  };
  function getErrorMessage(code) {
    return ErrorMessageMap[code] || ErrorMessageMap["UNK_UNKNOWN"];
  }
  const PLUGIN_VERSION = "0.0.1";
  const UXP_VERSION = "6.0.0";
  function generateId$2() {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
  }
  const _ErrorCollector = class _ErrorCollector {
    constructor(config) {
      __publicField(this, "isInitialized", false);
      __publicField(this, "userActionPath", []);
      __publicField(this, "errorHistory", []);
      __publicField(this, "maxHistorySize", 100);
      __publicField(this, "config");
      __publicField(this, "onErrorCallbacks", []);
      this.config = {
        retryConfig: {
          maxRetries: 3,
          retryDelay: 1e3,
          backoffMultiplier: 2,
          maxRetryDelay: 1e4
        },
        displayOptions: {
          showInPanel: true,
          showInNotificationCenter: true,
          autoDismiss: true,
          dismissDuration: 5e3
        },
        ...config
      };
    }
    static getInstance(config) {
      if (!_ErrorCollector.instance) {
        _ErrorCollector.instance = new _ErrorCollector(config);
      }
      return _ErrorCollector.instance;
    }
    static resetInstance() {
      if (_ErrorCollector.instance) {
        _ErrorCollector.instance.isInitialized = false;
        _ErrorCollector.instance.userActionPath = [];
        _ErrorCollector.instance.errorHistory = [];
      }
      _ErrorCollector.instance = null;
    }
    initialize() {
      if (this.isInitialized) {
        return;
      }
      if (typeof window !== "undefined") {
        window.onerror = this.handleGlobalError.bind(this);
        window.onunhandledrejection = this.handleUnhandledRejection.bind(this);
      }
      this.isInitialized = true;
      console.log("[ErrorCollector] Initialized successfully");
    }
    pushUserAction(action) {
      this.userActionPath.push(action);
      if (this.userActionPath.length > 50) {
        this.userActionPath = this.userActionPath.slice(-50);
      }
    }
    clearUserActionPath() {
      this.userActionPath = [];
    }
    getContext() {
      return {
        pluginVersion: PLUGIN_VERSION,
        hostVersion: this.getHostVersion(),
        hostApp: this.getHostApp(),
        uxpVersion: UXP_VERSION,
        userActionPath: [...this.userActionPath],
        timestamp: Date.now(),
        userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "",
        platform: typeof navigator !== "undefined" ? navigator.platform : ""
      };
    }
    getHostVersion() {
      try {
        if (typeof window !== "undefined" && window.require) {
          const app = window.require("photoshop");
          if (app && app.app && app.app.version) {
            return app.app.version;
          }
        }
      } catch {
      }
      return "unknown";
    }
    getHostApp() {
      return "Photoshop";
    }
    createStructuredError(error, context) {
      const errorCodeDef = detectErrorCode(error);
      const messageConfig = getErrorMessage(errorCodeDef.code);
      const errorMessage = error instanceof Error ? error.message : String(error);
      const errorStack = error instanceof Error ? error.stack : "";
      return {
        id: generateId$2(),
        code: errorCodeDef.code,
        category: errorCodeDef.category,
        level: errorCodeDef.level,
        message: errorMessage,
        userMessage: messageConfig.userMessage,
        suggestion: messageConfig.suggestion,
        stack: errorStack || "",
        context: {
          ...this.getContext(),
          ...context
        },
        originalError: error,
        retryCount: 0,
        isHandled: false
      };
    }
    handleGlobalError(message, source, lineno, colno, error) {
      const errorObj = error || new Error(String(message));
      const structuredError = this.createStructuredError(errorObj, {
        userActionPath: [...this.userActionPath]
      });
      if (lineno !== void 0 && colno !== void 0) {
        structuredError.stack = `${source}:${lineno}:${colno}
${structuredError.stack}`;
      }
      this.processError(structuredError);
      return false;
    }
    handleUnhandledRejection(event) {
      const error = event.reason;
      const structuredError = this.createStructuredError(error, {
        userActionPath: [...this.userActionPath]
      });
      this.processError(structuredError);
    }
    collectError(error, context) {
      const structuredError = this.createStructuredError(error, context);
      this.processError(structuredError);
      return structuredError;
    }
    processError(error) {
      this.errorHistory.push(error);
      if (this.errorHistory.length > this.maxHistorySize) {
        this.errorHistory = this.errorHistory.slice(-this.maxHistorySize);
      }
      for (const callback of this.onErrorCallbacks) {
        try {
          callback(error);
        } catch (callbackError) {
          console.error("[ErrorCollector] Error in callback:", callbackError);
        }
      }
      console.error("[ErrorCollector] Error collected:", {
        id: error.id,
        code: error.code,
        category: error.category,
        level: error.level,
        message: error.message,
        userMessage: error.userMessage
      });
    }
    onError(callback) {
      this.onErrorCallbacks.push(callback);
      return () => {
        const index = this.onErrorCallbacks.indexOf(callback);
        if (index > -1) {
          this.onErrorCallbacks.splice(index, 1);
        }
      };
    }
    getErrorHistory() {
      return [...this.errorHistory];
    }
    getLastError() {
      return this.errorHistory[this.errorHistory.length - 1] || null;
    }
    getErrorsByCategory(category) {
      return this.errorHistory.filter((error) => error.category === category);
    }
    getErrorsByLevel(level) {
      return this.errorHistory.filter((error) => error.level === level);
    }
    clearHistory() {
      this.errorHistory = [];
    }
    getConfig() {
      return { ...this.config };
    }
    updateConfig(config) {
      this.config = {
        ...this.config,
        ...config
      };
    }
    isRecoverableError(error) {
      return error.level === ErrorLevel.RECOVERABLE;
    }
    isNonRecoverableError(error) {
      return error.level === ErrorLevel.NON_RECOVERABLE;
    }
  };
  __publicField(_ErrorCollector, "instance", null);
  let ErrorCollector = _ErrorCollector;
  const errorCollector = ErrorCollector.getInstance();
  const SENSITIVE_PATTERNS = [
    /password/gi,
    /token/gi,
    /api[_-]?key/gi,
    /secret/gi,
    /credential/gi,
    /auth/gi,
    /bearer/gi,
    /authorization/gi,
    /x-api-key/gi,
    /access[_-]?key/gi,
    /private[_-]?key/gi
  ];
  const SENSITIVE_HEADERS = [
    "authorization",
    "x-api-key",
    "x-auth-token",
    "cookie",
    "set-cookie"
  ];
  const _ErrorReporter = class _ErrorReporter {
    static getInstance() {
      if (!_ErrorReporter.instance) {
        _ErrorReporter.instance = new _ErrorReporter();
      }
      return _ErrorReporter.instance;
    }
    static resetInstance() {
      _ErrorReporter.instance = null;
    }
    sanitizeData(data) {
      let sanitized = data;
      for (const pattern of SENSITIVE_PATTERNS) {
        sanitized = sanitized.replace(pattern, "[REDACTED]");
      }
      return sanitized;
    }
    sanitizeObject(obj) {
      const sanitized = {};
      for (const [key, value] of Object.entries(obj)) {
        const lowerKey = key.toLowerCase();
        const isSensitive = SENSITIVE_PATTERNS.some(
          (pattern) => pattern.test(key)
        ) || SENSITIVE_HEADERS.includes(lowerKey);
        if (isSensitive) {
          sanitized[key] = "[REDACTED]";
        } else if (typeof value === "string") {
          sanitized[key] = this.sanitizeData(value);
        } else if (typeof value === "object" && value !== null) {
          sanitized[key] = this.sanitizeObject(value);
        } else {
          sanitized[key] = value;
        }
      }
      return sanitized;
    }
    generateReport(error) {
      const sanitizedStack = this.sanitizeData(error.stack);
      return {
        errorId: error.id,
        pluginVersion: error.context.pluginVersion,
        hostVersion: error.context.hostVersion,
        hostApp: error.context.hostApp,
        uxpVersion: error.context.uxpVersion,
        systemInfo: {
          platform: error.context.platform,
          userAgent: this.sanitizeData(error.context.userAgent)
        },
        error: {
          code: error.code,
          category: error.category,
          level: error.level,
          message: this.sanitizeData(error.message),
          userMessage: error.userMessage,
          suggestion: error.suggestion,
          stack: sanitizedStack,
          timestamp: error.context.timestamp
        },
        userActionPath: error.context.userActionPath,
        generatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
    generateReportFromHistory(errorId) {
      let targetError = null;
      if (errorId) {
        const history = errorCollector.getErrorHistory();
        targetError = history.find((e) => e.id === errorId) || null;
      } else {
        targetError = errorCollector.getLastError();
      }
      if (!targetError) {
        return null;
      }
      return this.generateReport(targetError);
    }
    async exportReportToFile(errorId) {
      const report = this.generateReportFromHistory(errorId);
      if (!report) {
        console.error("[ErrorReporter] No error found to export");
        return null;
      }
      const reportJson = JSON.stringify(report, null, 2);
      try {
        const desktopPath = await this.getDesktopPath();
        if (!desktopPath) {
          console.error("[ErrorReporter] Could not get desktop path");
          return null;
        }
        const fileName = `error-report-${report.errorId.slice(0, 8)}-${Date.now()}.json`;
        const filePath = `${desktopPath}/${fileName}`;
        await this.writeFile(filePath, reportJson);
        console.log("[ErrorReporter] Error report saved to:", filePath);
        await this.selectFile(filePath);
        return filePath;
      } catch (error) {
        console.error("[ErrorReporter] Failed to export report:", error);
        return null;
      }
    }
    async getDesktopPath() {
      try {
        if (typeof window !== "undefined") {
          const uxp2 = window.uxp;
          if (uxp2 && uxp2.storage) {
            const folders = await uxp2.storage.localFileSystem.getFolders();
            const desktopFolder = folders.find(
              (folder) => folder.name === "Desktop" || folder.path.includes("Desktop")
            );
            if (desktopFolder) {
              return desktopFolder.path;
            }
          }
        }
      } catch (error) {
        console.error("[ErrorReporter] Failed to get desktop path:", error);
      }
      if (typeof require !== "undefined") {
        try {
          const os = require("os");
          const path = require("path");
          return path.join(os.homedir(), "Desktop");
        } catch {
        }
      }
      return null;
    }
    async writeFile(filePath, content) {
      try {
        if (typeof window !== "undefined") {
          const uxp2 = window.uxp;
          if (uxp2 && uxp2.storage) {
            const file = await uxp2.storage.localFileSystem.createFile(filePath, {
              overwrite: true
            });
            const writer = await file.open();
            await writer.write(content);
            await writer.close();
            return;
          }
        }
      } catch (error) {
        console.error("[ErrorReporter] UXP file write failed:", error);
      }
      if (typeof require !== "undefined") {
        try {
          const fs2 = require("fs");
          fs2.writeFileSync(filePath, content, "utf8");
          return;
        } catch (fsError) {
          console.error("[ErrorReporter] Node fs write failed:", fsError);
        }
      }
      throw new Error("Unable to write file: no suitable API available");
    }
    async selectFile(filePath) {
      try {
        if (typeof window !== "undefined") {
          const uxp2 = window.uxp;
          if (uxp2 && uxp2.shell) {
            await uxp2.shell.openPath(filePath);
            return;
          }
        }
      } catch (error) {
        console.error("[ErrorReporter] Failed to open file:", error);
      }
      if (typeof require !== "undefined") {
        try {
          const { shell } = require("electron");
          if (shell && shell.showItemInFolder) {
            shell.showItemInFolder(filePath);
            return;
          }
        } catch {
        }
      }
      console.log("[ErrorReporter] File saved at:", filePath);
    }
    getReportSummary(report) {
      return [
        `错误ID: ${report.errorId.slice(0, 8)}`,
        `错误码: ${report.error.code}`,
        `错误类型: ${report.error.category}`,
        `错误级别: ${report.error.level}`,
        `用户提示: ${report.error.userMessage}`,
        `插件版本: ${report.pluginVersion}`,
        `宿主应用: ${report.hostApp} ${report.hostVersion}`,
        `发生时间: ${new Date(report.error.timestamp).toLocaleString()}`
      ].join("\n");
    }
    copyReportToClipboard(errorId) {
      const report = this.generateReportFromHistory(errorId);
      if (!report) {
        return false;
      }
      const summary = this.getReportSummary(report);
      try {
        if (typeof navigator !== "undefined" && navigator.clipboard) {
          navigator.clipboard.writeText(summary);
          return true;
        }
      } catch (error) {
        console.error("[ErrorReporter] Clipboard write failed:", error);
      }
      return false;
    }
  };
  __publicField(_ErrorReporter, "instance", null);
  let ErrorReporter = _ErrorReporter;
  const errorReporter = ErrorReporter.getInstance();
  const DEFAULT_RETRY_CONFIG = {
    maxRetries: 3,
    retryDelay: 1e3,
    backoffMultiplier: 2,
    maxRetryDelay: 1e4
  };
  const _RetryManager = class _RetryManager {
    constructor(config) {
      __publicField(this, "tasks", /* @__PURE__ */ new Map());
      __publicField(this, "defaultConfig");
      this.defaultConfig = {
        ...DEFAULT_RETRY_CONFIG,
        ...config
      };
    }
    static getInstance(config) {
      if (!_RetryManager.instance) {
        _RetryManager.instance = new _RetryManager(config);
      }
      return _RetryManager.instance;
    }
    static resetInstance() {
      _RetryManager.instance = null;
    }
    setDefaultConfig(config) {
      this.defaultConfig = {
        ...this.defaultConfig,
        ...config
      };
    }
    getDefaultConfig() {
      return { ...this.defaultConfig };
    }
    calculateDelay(attempt, config) {
      const delay = config.retryDelay * Math.pow(config.backoffMultiplier, attempt);
      return Math.min(delay, config.maxRetryDelay);
    }
    isRecoverableError(error) {
      return error.level === ErrorLevel.RECOVERABLE;
    }
    shouldRetry(error, attempt, config) {
      if (!this.isRecoverableError(error)) {
        return false;
      }
      return attempt < config.maxRetries;
    }
    async executeWithRetry(fn, config, onRetry, onSuccess, onFailure) {
      const finalConfig = {
        ...this.defaultConfig,
        ...config
      };
      let attempts = 0;
      let lastError;
      while (attempts <= finalConfig.maxRetries) {
        try {
          const data = await fn();
          if (attempts > 0 && onSuccess) {
            onSuccess(data, attempts);
          }
          return {
            success: true,
            data,
            attempts: attempts + 1
          };
        } catch (error) {
          const structuredError = errorCollector.collectError(error);
          lastError = structuredError;
          if (!this.shouldRetry(structuredError, attempts, finalConfig)) {
            if (onFailure) {
              onFailure(structuredError, attempts + 1);
            }
            return {
              success: false,
              error: structuredError,
              attempts: attempts + 1,
              finalError: error
            };
          }
          if (onRetry) {
            onRetry(structuredError, attempts + 1);
          }
          if (attempts < finalConfig.maxRetries) {
            const delay = this.calculateDelay(attempts, finalConfig);
            await this.sleep(delay);
          }
          attempts++;
        }
      }
      if (lastError && onFailure) {
        onFailure(lastError, attempts);
      }
      return {
        success: false,
        error: lastError,
        attempts,
        finalError: void 0
      };
    }
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }
    createTask(id, fn, config, onRetry, onSuccess, onFailure) {
      const task = {
        id,
        fn,
        config: {
          ...this.defaultConfig,
          ...config
        },
        onRetry,
        onSuccess,
        onFailure,
        state: "pending"
      };
      this.tasks.set(id, task);
      return task;
    }
    async runTask(taskId) {
      const task = this.tasks.get(taskId);
      if (!task) {
        console.error(`[RetryManager] Task not found: ${taskId}`);
        return null;
      }
      if (task.state === "running") {
        console.warn(`[RetryManager] Task already running: ${taskId}`);
        return task.result || null;
      }
      task.state = "running";
      const result = await this.executeWithRetry(
        task.fn,
        task.config,
        task.onRetry,
        task.onSuccess,
        task.onFailure
      );
      task.result = result;
      task.state = result.success ? "completed" : "failed";
      return result;
    }
    cancelTask(taskId) {
      const task = this.tasks.get(taskId);
      if (!task) {
        return false;
      }
      if (task.state === "running") {
        task.state = "failed";
        return true;
      }
      return false;
    }
    getTask(taskId) {
      return this.tasks.get(taskId);
    }
    removeTask(taskId) {
      return this.tasks.delete(taskId);
    }
    clearTasks() {
      this.tasks.clear();
    }
    getTaskCount() {
      return this.tasks.size;
    }
    getRunningTasks() {
      return Array.from(this.tasks.values()).filter((task) => task.state === "running");
    }
    getCompletedTasks() {
      return Array.from(this.tasks.values()).filter((task) => task.state === "completed");
    }
    getFailedTasks() {
      return Array.from(this.tasks.values()).filter((task) => task.state === "failed");
    }
  };
  __publicField(_RetryManager, "instance", null);
  let RetryManager = _RetryManager;
  RetryManager.getInstance();
  const UxPActionButton$3 = ({ onClick, disabled, quiet, className, children }) => {
    const ref = reactExports.useRef(null);
    const onClickRef = reactExports.useRef(onClick);
    const disabledRef = reactExports.useRef(disabled);
    onClickRef.current = onClick;
    disabledRef.current = disabled;
    reactExports.useEffect(() => {
      var _a2;
      const btn = (_a2 = ref.current) == null ? void 0 : _a2.querySelector("sp-action-button");
      if (!btn) return;
      const handler = (e) => {
        var _a3, _b2, _c2;
        if (disabledRef.current) return;
        (_a3 = e.preventDefault) == null ? void 0 : _a3.call(e);
        (_b2 = e.stopPropagation) == null ? void 0 : _b2.call(e);
        (_c2 = onClickRef.current) == null ? void 0 : _c2.call(onClickRef);
      };
      btn.addEventListener("click", handler);
      return () => btn.removeEventListener("click", handler);
    }, []);
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref, style: { display: "inline-block" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-action-button", { class: className || "", quiet, disabled: disabled ? true : void 0, children }) });
  };
  const ErrorNotification = ({
    error,
    onDismiss,
    onShowDetails,
    onCopyLog,
    onExportReport,
    autoDismiss = true,
    dismissDuration = 5e3
  }) => {
    const [isExpanded, setIsExpanded] = reactExports.useState(false);
    const [isCopied, setIsCopied] = reactExports.useState(false);
    reactExports.useEffect(() => {
      if (autoDismiss && dismissDuration > 0) {
        const timer = setTimeout(() => {
          onDismiss();
        }, dismissDuration);
        return () => clearTimeout(timer);
      }
    }, [autoDismiss, dismissDuration, onDismiss]);
    const handleCopyLog = () => {
      const success = errorReporter.copyReportToClipboard(error.id);
      if (success) {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2e3);
      }
      onCopyLog();
    };
    const handleExportReport = async () => {
      await errorReporter.exportReportToFile(error.id);
      onExportReport();
    };
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-notification", role: "alert", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-notification-header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "error-notification-icon", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: "20", height: "20", viewBox: "0 0 20 20", fill: "none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "10", cy: "10", r: "9", stroke: "currentColor", strokeWidth: "2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "10", y1: "6", x2: "10", y2: "11", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "10", cy: "14", r: "1", fill: "currentColor" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-notification-content", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "error-notification-title", children: error.userMessage }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "error-notification-suggestion", children: error.suggestion })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          UxPActionButton$3,
          {
            quiet: true,
            className: "error-notification-close",
            onClick: onDismiss,
            children: "×"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-notification-actions", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          UxPActionButton$3,
          {
            quiet: true,
            className: "error-notification-button",
            onClick: () => setIsExpanded(!isExpanded),
            children: isExpanded ? "收起详情" : "查看详情"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          UxPActionButton$3,
          {
            quiet: true,
            className: "error-notification-button",
            onClick: handleCopyLog,
            children: isCopied ? "已复制" : "复制日志"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          UxPActionButton$3,
          {
            className: "error-notification-button primary",
            onClick: handleExportReport,
            children: "一键反馈"
          }
        )
      ] }),
      isExpanded && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-notification-details", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-detail-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: "错误码:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { children: error.code })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-detail-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: "错误类型:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { children: error.category })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-detail-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: "错误级别:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { children: error.level })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-detail-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: "原始错误:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { children: error.message })
        ] }),
        error.stack && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "error-detail-stack", children: /* @__PURE__ */ jsxRuntimeExports.jsx("pre", { children: error.stack }) })
      ] })
    ] });
  };
  const ErrorNotificationContainer = ({
    position = "top",
    maxErrors = 3
  }) => {
    const [errors, setErrors] = reactExports.useState([]);
    reactExports.useEffect(() => {
      const unsubscribe = errorCollector.onError((error) => {
        setErrors((prev) => {
          const newErrors = [error, ...prev];
          return newErrors.slice(0, maxErrors);
        });
      });
      return unsubscribe;
    }, [maxErrors]);
    const handleDismiss = (errorId) => {
      setErrors((prev) => prev.filter((e) => e.id !== errorId));
    };
    if (errors.length === 0) {
      return null;
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `error-notification-container ${position}`, children: errors.map((error) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      ErrorNotification,
      {
        error,
        onDismiss: () => handleDismiss(error.id),
        onShowDetails: () => {
        },
        onCopyLog: () => {
        },
        onExportReport: () => {
        }
      },
      error.id
    )) });
  };
  function initializeErrorHandling() {
    errorCollector.initialize();
    console.log("[ErrorHandler] Error handling system initialized");
  }
  const ASPECT_RATIOS = [
    { label: "1:1 (1024x1024)", value: "1：1（1024x1024）", width: 1024, height: 1024 },
    { label: "1:2 (720x1456)", value: "1：2（720x1456）", width: 720, height: 1456 },
    { label: "3:5 (800x1328)", value: "3：5（800x1328）", width: 800, height: 1328 },
    { label: "5:3 (1328x800)", value: "5：3（1328x800）", width: 1328, height: 800 },
    { label: "2:1 (1456x720)", value: "2：1（1456x720）", width: 1456, height: 720 },
    { label: "3:1 (1536x512)", value: "3：1（1536x512）", width: 1536, height: 512 },
    { label: "1:3 (512x1536)", value: "1：3（512x1536）", width: 512, height: 1536 },
    { label: "9:16 (752x1392)", value: "9：16（752x1392）", width: 752, height: 1392 },
    { label: "16:9 (1392x752)", value: "16：9（1392x752）", width: 1392, height: 752 },
    { label: "3:4 (880x1204)", value: "3：4（880x1204）", width: 880, height: 1204 },
    { label: "4:3 (1184x880)", value: "4：3（1184x880）", width: 1184, height: 880 },
    { label: "2:3 (832x1248)", value: "2：3（832x1248）", width: 832, height: 1248 },
    { label: "3:2 (1248x832)", value: "3：2（1248x832）", width: 1248, height: 832 },
    { label: "9:21 (672x1568)", value: "9：21（672x1568）", width: 672, height: 1568 },
    { label: "21:9 (1568x672)", value: "21：9（1568x672）", width: 1568, height: 672 },
    { label: "原始比例", value: "original", width: 0, height: 0 }
  ];
  function findClosestAspectRatio(canvasWidth, canvasHeight) {
    const canvasRatio = canvasWidth / canvasHeight;
    let closest = ASPECT_RATIOS[0];
    let minDiff = Infinity;
    for (const ratio of ASPECT_RATIOS) {
      if (ratio.value === "original") continue;
      const ratioValue = ratio.width / ratio.height;
      const diff = Math.abs(canvasRatio - ratioValue);
      if (diff < minDiff) {
        minDiff = diff;
        closest = ratio;
      }
    }
    return closest;
  }
  const getAuthToken = () => {
    try {
      return localStorage.getItem("ps_plugin_token");
    } catch {
      return null;
    }
  };
  const generateRequestId = () => {
    return `gen_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  };
  const getModelForRequest = (model, lora) => {
    if (model === "Anima" && lora === "trubo") {
      return "Anima Turbo";
    }
    return model;
  };
  const proxyFetchToBizyAir = async (url, headers, data, signal, model, generationId) => {
    const reqHeaders = {
      "Content-Type": "application/json"
    };
    const token = getAuthToken();
    if (token) {
      reqHeaders["Authorization"] = `Bearer ${token}`;
    }
    return fetch(`${getProxyBaseURL()}/api/generate/proxy`, {
      method: "POST",
      headers: reqHeaders,
      body: JSON.stringify({
        url,
        headers,
        data,
        model: model || void 0,
        generation_id: generateRequestId()
      }),
      signal
    });
  };
  const resolveAuthorization = async (authorization) => {
    return authorization;
  };
  const parseResponseBody = (raw) => {
    try {
      return JSON.parse(raw);
    } catch {
      return raw;
    }
  };
  const getErrorMessageFromBody = (body) => {
    if (typeof body === "string") return body;
    if (!body || typeof body !== "object") return "Unknown error";
    const anyBody = body;
    return anyBody.error_msg || anyBody.error || anyBody.message || anyBody.detail || "Unknown error";
  };
  const extractFailedError = (result) => {
    var _a2, _b2;
    if (result && result.status === "Failed") {
      const outputs = result.outputs || [];
      return ((_a2 = outputs[0]) == null ? void 0 : _a2.error_msg) || ((_b2 = outputs[0]) == null ? void 0 : _b2.error) || result.error_msg || result.error || "Task failed";
    }
    return null;
  };
  const WORKFLOW_PATHS = {
    text_to_image: {
      OneRemoval: "/assets/Workflows/05-Inpainting/Z-Image_inpainting.json",
      Outpainting: "/assets/Workflows/05-Inpainting/Z-Image_outpainting.json",
      Anima: (lora) => lora === "trubo" ? "/assets/Workflows/01-Text2Image/Anima_trubo_text-to-image.json" : "/assets/Workflows/01-Text2Image/Anima_text-to-image.json",
      "GPT-2 Text-to-Image": "/assets/Workflows/01-Text2Image/GPT-Image-2_text-to-image.json",
      "Nano Banana": "/assets/Workflows/01-Text2Image/Nanobanana-2_text-to-image.json",
      "Seedream 5.0": "/assets/Workflows/01-Text2Image/seedream5.0_text-to-image.json",
      "Z-Image Base": "/assets/Workflows/01-Text2Image/Z-Image_text-to-image_base.json"
    },
    edit_image: {
      Qwen: "/assets/Workflows/02-Edit-Image/Z-Image_edit_image_qwen.json",
      "Nano Banana": "/assets/Workflows/02-Edit-Image/Nanobanana-2_edit-image.json",
      "Gpt-image-2": "/assets/Workflows/02-Edit-Image/Z-Image_edit_image_gptimage2.json",
      "Flux-Klenin": "/assets/Workflows/02-Edit-Image/Z-Image_edit_image_fluxklenin.json",
      "Kein角色编辑": "/assets/Workflows/02-Edit-Image/kein-character-edit.json",
      "Seedream 5.0": "/assets/Workflows/02-Edit-Image/seedream5.0.json"
    },
    upscale: {
      "Seed Face 2K": "/assets/Workflows/03-Upscale-Image/seed_face_2K.json",
      "Seed Face 4K": "/assets/Workflows/03-Upscale-Image/seed_face_4k.json",
      "面部形象修复": "/assets/Workflows/03-Upscale-Image/Nanobanan_face_restore.json",
      "Klein4K清晰": "/assets/Workflows/03-Upscale-Image/Z-Image_klein4k.json",
      "Z-image动漫放大": "/assets/Workflows/03-Upscale-Image/Z-Image_anime_upscale.json"
    },
    remove_background: {
      Targeted: "/assets/Workflows/04-Remove-Background/Z-Image_remove_background_targeted.json",
      Universal: "/assets/Workflows/04-Remove-Background/Z-Image_remove_background_universal.json"
    }
  };
  const getModelConfigPath = (model, mode = "text_to_image", lora) => {
    const modeMap = WORKFLOW_PATHS[mode];
    if (!modeMap) throw new Error(`Unknown mode: ${mode}`);
    const pathOrFn = modeMap[model];
    if (!pathOrFn) {
      if (mode === "text_to_image") return WORKFLOW_PATHS.text_to_image["Z-Image Base"];
      throw new Error(`Unknown ${mode} model: ${model}`);
    }
    return typeof pathOrFn === "function" ? pathOrFn(lora) : pathOrFn;
  };
  const loadWorkflowConfig = async (model = "Z-Image Base", mode = "text_to_image", lora) => {
    const configPath = getModelConfigPath(model, mode, lora);
    console.log("[API] 加载工作流配置:", configPath, "模型:", model, "模式:", mode, "LoRA:", lora);
    const response = await fetch(configPath);
    if (!response.ok) {
      console.error("[API] 加载工作流配置失败:", response.status, response.statusText);
      throw new Error("Failed to load workflow configuration");
    }
    const config = await response.json();
    config.headers.Authorization = await resolveAuthorization(config.headers.Authorization);
    console.log("[API] Authorization configured:", !!config.headers.Authorization);
    return config;
  };
  const generateImage = async (request) => {
    console.log("[API] ========== 开始生成图片 ==========");
    console.log("[API] 请求参数:", { prompt: request.prompt, width: request.width, height: request.height });
    try {
      const model = request.model || "Z-Image Base";
      const config = await loadWorkflowConfig(model, "text_to_image", request.lora);
      console.log("[API] 选择的模型:", model, "LoRA:", request.lora);
      let inputValues = { ...config.data.input_values };
      if (model === "OneRemoval") {
        if (!request.imageUrl) {
          console.warn(`[API] Warning: ${model} requires imageUrl, but none provided.`);
        }
        if (!request.maskImageUrl) {
          console.warn(`[API] Warning: ${model} requires maskImageUrl, but none provided.`);
        }
        inputValues["63:LoadImage.image"] = request.imageUrl || "";
        inputValues["61:CLIPTextEncode.text"] = request.prompt || "";
        inputValues["79:LoadImage.image"] = request.maskImageUrl || "";
      } else if (model === "Outpainting") {
        if (!request.imageUrl) {
          console.warn(`[API] Warning: ${model} requires imageUrl, but none provided.`);
        }
        if (!request.maskImageUrl) {
          console.warn(`[API] Warning: ${model} requires maskImageUrl, but none provided.`);
        }
        const longestSide = request.longestSide || Math.max(request.width || 1024, request.height || 1024);
        inputValues["62:LoadImage.image"] = request.imageUrl || "";
        inputValues["82:LoadImage.image"] = request.maskImageUrl || "";
        inputValues["49:ImpactInt.value"] = longestSide;
        inputValues["72:CR Text.text"] = request.prompt || "";
      } else if (model === "Anima") {
        console.log("[API] 进入 Anima 分支，设置工作流参数...");
        const isTrubo = request.lora === "trubo";
        const textNode = isTrubo ? "20:CR Text.text" : "36:CR Text.text";
        const ratioNode = isTrubo ? "83:AspectRatioSizeNodeOfUtils.aspect_ratio" : "46:AspectRatioSizeNodeOfUtils.aspect_ratio";
        const seedNode = isTrubo ? "78:Seed_.seed" : "30:Seed_.seed";
        const batchNode = isTrubo ? "80:EmptyLatentImage.batch_size" : "39:EmptyLatentImage.batch_size";
        inputValues[textNode] = request.prompt || "";
        let selectedRatio;
        if (request.aspectRatio && request.aspectRatio !== "original") {
          selectedRatio = ASPECT_RATIOS.find((r) => r.value === request.aspectRatio) || ASPECT_RATIOS[0];
          const ratioMatch = selectedRatio.value.match(/(\d+)[：:](\d+)/);
          inputValues[ratioNode] = ratioMatch ? `${ratioMatch[1]}:${ratioMatch[2]}` : selectedRatio.value;
          console.log("[API] Anima 使用固定比例:", selectedRatio.label, "=>", inputValues[ratioNode]);
        } else {
          selectedRatio = findClosestAspectRatio(request.width || 1024, request.height || 1024);
          const ratioMatch = selectedRatio.value.match(/(\d+)[：:](\d+)/);
          inputValues[ratioNode] = ratioMatch ? `${ratioMatch[1]}:${ratioMatch[2]}` : selectedRatio.value;
          console.log("[API] Anima 原始比例，匹配最近预设:", selectedRatio.label, "=>", inputValues[ratioNode]);
        }
        inputValues[seedNode] = request.seed ?? Math.floor(Math.random() * 1e12);
        inputValues[batchNode] = request.batchSize ?? 1;
        if (isTrubo) {
          inputValues["80:EmptyLatentImage.width"] = selectedRatio.width;
          inputValues["80:EmptyLatentImage.height"] = selectedRatio.height;
          console.log("[API] Anima trubo 设置尺寸:", selectedRatio.width, "x", selectedRatio.height);
        }
        console.log("[API] Anima 最终 input_values:", JSON.stringify(inputValues, null, 2));
      } else if (model === "GPT-2 Text-to-Image") {
        console.log("[API] 进入 GPT-2 Text-to-Image 分支，设置工作流参数...");
        inputValues["19:BizyAirSiliconCloudLLMAPI.user_prompt"] = request.prompt || "";
        let ratioStr = "1:1";
        if (request.aspectRatio && request.aspectRatio !== "original") {
          const match = request.aspectRatio.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        } else {
          const closest = findClosestAspectRatio(request.width || 1024, request.height || 1024);
          const match = closest.value.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        }
        inputValues["17:BizyAir_GPT_IMAGE_2_T2I_API.aspect_ratio"] = ratioStr;
        console.log("[API] GPT-2 Text-to-Image 最终 input_values:", JSON.stringify(inputValues, null, 2));
      } else if (model === "Nano Banana") {
        console.log("[API] 进入 Nano Banana 分支，设置工作流参数...");
        inputValues["17:BizyAir_NanoBanana2.prompt"] = request.prompt || "";
        let ratioStr = "1:1";
        if (request.aspectRatio && request.aspectRatio !== "original") {
          const match = request.aspectRatio.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        } else {
          const closest = findClosestAspectRatio(request.width || 1024, request.height || 1024);
          const match = closest.value.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        }
        inputValues["17:BizyAir_NanoBanana2.aspect_ratio"] = ratioStr;
        console.log("[API] Nano Banana 最终 input_values:", JSON.stringify(inputValues, null, 2));
      } else if (model === "Seedream 5.0") {
        console.log("[API] 进入 Seedream 5.0 分支，设置工作流参数...");
        inputValues["17:BizyAir_Seedream5.prompt"] = request.prompt || "";
        let ratioStr = "1:1";
        if (request.aspectRatio && request.aspectRatio !== "original") {
          const match = request.aspectRatio.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        } else {
          const closest = findClosestAspectRatio(request.width || 1024, request.height || 1024);
          const match = closest.value.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        }
        inputValues["19:AspectRatioSizeNodeOfUtils.aspect_ratio"] = ratioStr;
        inputValues["19:AspectRatioSizeNodeOfUtils.batch_size"] = request.batchSize ?? 1;
        console.log("[API] Seedream 5.0 最终 input_values:", JSON.stringify(inputValues, null, 2));
      } else if (model === "Z-Image Base") {
        console.log("[API] 进入 Z-Image Base 分支，设置工作流参数...");
        inputValues["31:BizyAirSiliconCloudLLMAPI.user_prompt"] = request.prompt || "";
        let ratioStr = "1:1";
        if (request.aspectRatio && request.aspectRatio !== "original") {
          const match = request.aspectRatio.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        } else {
          const closest = findClosestAspectRatio(request.width || 1024, request.height || 1024);
          const match = closest.value.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        }
        inputValues["32:AspectRatioSizeNodeOfUtils.aspect_ratio"] = ratioStr;
        inputValues["20:KSampler.seed"] = request.seed ?? Math.floor(Math.random() * 1e12);
        inputValues["30:EmptyLatentImage.batch_size"] = request.batchSize ?? 1;
        console.log("[API] Z-Image Base 最终 input_values:", JSON.stringify(inputValues, null, 2));
      } else {
        inputValues["6:CLIPTextEncode.text"] = request.prompt || "";
        inputValues["13:EmptySD3LatentImage.width"] = request.width || 1024;
        inputValues["13:EmptySD3LatentImage.height"] = request.height || 1024;
      }
      const requestData = {
        ...config.data,
        input_values: inputValues
      };
      console.log("[API] API URL:", config.url);
      console.log("[API] 请求数据:", JSON.stringify(requestData, null, 2));
      const fetchWithTimeout = (url, options, timeoutMs2) => {
        return Promise.race([
          fetch(url, options),
          new Promise(
            (_, reject) => setTimeout(() => reject(new Error(`Request timeout after ${timeoutMs2}ms`)), timeoutMs2)
          )
        ]);
      };
      const batchSize = request.batchSize ?? 1;
      const SLOW_MODELS = ["GPT-2 Text-to-Image", "Z-Image Base", "Anima", "Nano Banana", "Seedream 5.0"];
      const VERY_SLOW_MODELS = ["GPT-2 Text-to-Image"];
      const baseTimeout = VERY_SLOW_MODELS.includes(model) ? 6e5 : SLOW_MODELS.includes(model) ? 3e5 : 18e4;
      const timeoutMs = baseTimeout + (batchSize - 1) * 12e4;
      console.log(`[API] 请求超时设置: ${timeoutMs}ms (model=${model}, batch_size=${batchSize})`);
      let response;
      try {
        response = await fetchWithTimeout(`${getProxyBaseURL()}/api/generate/proxy`, {
          method: "POST",
          headers: (() => {
            const h = { "Content-Type": "application/json" };
            const token = getAuthToken();
            if (token) h["Authorization"] = `Bearer ${token}`;
            return h;
          })(),
          body: JSON.stringify({
            url: config.url,
            headers: config.headers,
            data: requestData,
            model: getModelForRequest(model, request.lora),
            generation_id: generateRequestId()
          }),
          signal: request.signal
        }, timeoutMs);
      } catch (fetchErr) {
        console.error("[API] fetch 失败或超时:", (fetchErr == null ? void 0 : fetchErr.message) || fetchErr);
        throw new Error((fetchErr == null ? void 0 : fetchErr.message) || "Network request failed");
      }
      console.log("[API] 响应状态:", response.status, response.statusText);
      const raw = await response.text();
      const result = parseResponseBody(raw);
      if (typeof result === "object") {
        console.log("[API] API 响应数据:", JSON.stringify(result, null, 2));
      } else {
        console.log("[API] API 响应数据:", String(result));
      }
      if (response.status === 202 && typeof result === "object" && result && result.requestId) {
        console.log("[API] 收到异步任务，requestId:", result.requestId);
        console.log("[API] 开始轮询任务状态...");
        const taskResult = await pollTaskStatus(result.requestId, config.headers, request.onProgress);
        if (taskResult.success && (taskResult.data || taskResult.urls)) {
          return {
            success: true,
            data: taskResult.data,
            urls: taskResult.urls
          };
        } else {
          return {
            success: false,
            error: taskResult.error || "Task failed"
          };
        }
      }
      if (!response.ok) {
        const errMsg = getErrorMessageFromBody(result);
        throw new Error(`API request failed with status ${response.status}: ${errMsg}`);
      }
      const failedError = extractFailedError(result);
      if (failedError) {
        return { success: false, error: failedError };
      }
      if (typeof result === "object" && result && result.outputs && result.outputs.length > 0) {
        const outputs = result.outputs;
        const imageUrls = outputs.map((o) => o.object_url).filter(Boolean);
        if (imageUrls.length > 0) {
          console.log("[API] 收到图片URLs:", imageUrls);
          return {
            success: true,
            data: imageUrls[0],
            urls: imageUrls
          };
        }
      }
      console.error("[API] 响应中没有图片数据");
      return {
        success: false,
        error: "No image data in response"
      };
    } catch (error) {
      console.error("[API] 生成图片出错:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred"
      };
    }
  };
  const editImage = async (request) => {
    console.log("[API] ========== 开始编辑图片 ==========");
    console.log("[API] 请求参数:", {
      prompt: request.prompt,
      editModel: request.editModel,
      imageUrl: request.imageUrl,
      hasLocalFile: !!request.localFile
    });
    if (!request.editModel) {
      throw new Error("Edit Image model is required");
    }
    if (request.localFile) {
      console.log("[API] 检测到本地文件，开始上传到 BizyAir OSS...");
      const { uploadFileToBizyAir: uploadFileToBizyAir2 } = await __vitePreload(async () => {
        const { uploadFileToBizyAir: uploadFileToBizyAir3 } = await Promise.resolve().then(() => fileUpload);
        return { uploadFileToBizyAir: uploadFileToBizyAir3 };
      }, false ? __VITE_PRELOAD__ : void 0, _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("assets/main.js", document.baseURI).href);
      const uploadResult = await uploadFileToBizyAir2(request.localFile, 3);
      if (!uploadResult.success) {
        return {
          success: false,
          error: `文件上传失败: ${uploadResult.error}`
        };
      }
      console.log("[API] 文件上传成功，URL:", uploadResult.url);
      request.imageUrl = uploadResult.url;
    }
    const isMultiImageEdit = request.editModel === "Nano Banana" || request.editModel === "Gpt-image-2" || request.editModel === "Kein角色编辑" || request.editModel === "Seedream 5.0";
    const hasImages = isMultiImageEdit ? request.imageUrls && request.imageUrls.length > 0 || !!request.imageUrl : !!request.imageUrl;
    if (!hasImages) {
      throw new Error("Input image URL is required (请提供 imageUrl 或 localFile)");
    }
    try {
      const config = await loadWorkflowConfig(request.editModel, "edit_image");
      console.log("[API] 选择的模型:", request.editModel);
      let requestData;
      if (request.editModel === "Nano Banana") {
        const imageUrls = request.imageUrls || (request.imageUrl ? [request.imageUrl] : []);
        if (imageUrls.length === 0) {
          throw new Error("Nano Banana 编辑模式至少需要一张输入图片");
        }
        const inputValues = {
          "17:BizyAir_NanoBanana2.prompt": request.prompt || "",
          "17:BizyAir_NanoBanana2.inputcount": imageUrls.length,
          "17:BizyAir_NanoBanana2.aspect_ratio": "auto"
        };
        const NODE_IDS = [19, 21, 22, 23, 24];
        imageUrls.forEach((url, index) => {
          const nodeId = NODE_IDS[index];
          if (nodeId !== void 0) {
            inputValues[`${nodeId}:LoadImage.image`] = url;
          }
        });
        requestData = {
          ...config.data,
          input_values: inputValues
        };
        console.log("[API] Nano Banana 多图模式，图片数量:", imageUrls.length);
      } else if (request.editModel === "Gpt-image-2") {
        const imageUrls = request.imageUrls || (request.imageUrl ? [request.imageUrl] : []);
        if (imageUrls.length === 0) {
          throw new Error("Gpt-image-2 编辑模式至少需要一张输入图片");
        }
        const inputValues = {
          "20:BizyAir_GPT_IMAGE_2_I2I_API.prompt": request.prompt || ""
        };
        let ratioStr = "1:1";
        if (request.aspectRatio && request.aspectRatio !== "original") {
          const match = request.aspectRatio.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        } else {
          const closest = findClosestAspectRatio(request.width || 1024, request.height || 1024);
          const match = closest.value.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        }
        inputValues["20:BizyAir_GPT_IMAGE_2_I2I_API.aspect_ratio"] = ratioStr;
        const NODE_IDS = [19, 21, 22, 23, 24];
        imageUrls.forEach((url, index) => {
          const nodeId = NODE_IDS[index];
          if (nodeId !== void 0) {
            inputValues[`${nodeId}:LoadImage.image`] = url;
          }
        });
        requestData = {
          ...config.data,
          input_values: inputValues
        };
        console.log("[API] Gpt-image-2 多图模式，图片数量:", imageUrls.length, "比例:", ratioStr);
      } else if (request.editModel === "Kein角色编辑") {
        const imageUrls = request.imageUrls || (request.imageUrl ? [request.imageUrl] : []);
        if (imageUrls.length === 0) {
          throw new Error("Kein角色编辑模式至少需要1张输入图片");
        }
        const inputValues = {
          ...config.data.input_values,
          "133:CLIPTextEncode.text": request.prompt || ""
        };
        if (request.aspectRatio && request.aspectRatio !== "original") {
          const ratioMatch = request.aspectRatio.match(/(\d+)[：:](\d+)/);
          inputValues["145:AspectRatioSizeNodeOfUtils.aspect_ratio"] = ratioMatch ? `${ratioMatch[1]}:${ratioMatch[2]}` : request.aspectRatio;
        }
        inputValues["136:LoadImage.image"] = imageUrls[0];
        inputValues["142:LoadImage.image"] = imageUrls[1] || imageUrls[0];
        inputValues["143:LoadImage.image"] = imageUrls[2] || imageUrls[1] || imageUrls[0];
        requestData = {
          ...config.data,
          input_values: inputValues
        };
        console.log("[API] Kein角色编辑模式，图片数量:", imageUrls.length, "尺寸:", request.aspectRatio);
      } else if (request.editModel === "Seedream 5.0") {
        const imageUrls = request.imageUrls || (request.imageUrl ? [request.imageUrl] : []);
        if (imageUrls.length === 0) {
          throw new Error("Seedream 5.0 编辑模式至少需要一张输入图片");
        }
        const inputValues = {
          "17:BizyAir_Seedream5.prompt": request.prompt || ""
        };
        let ratioStr = "1:1";
        if (request.aspectRatio && request.aspectRatio !== "original") {
          const match = request.aspectRatio.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        } else {
          const closest = findClosestAspectRatio(request.width || 1024, request.height || 1024);
          const match = closest.value.match(/(\d+)[：:](\d+)/);
          if (match) ratioStr = `${match[1]}:${match[2]}`;
        }
        inputValues["24:AspectRatioSizeNodeOfUtils.aspect_ratio"] = ratioStr;
        const NODE_IDS = [18, 20, 21, 22, 23];
        imageUrls.forEach((url, index) => {
          const nodeId = NODE_IDS[index];
          if (nodeId !== void 0) {
            inputValues[`${nodeId}:LoadImage.image`] = url;
          }
        });
        requestData = {
          ...config.data,
          input_values: inputValues
        };
        console.log("[API] Seedream 5.0 多图模式，图片数量:", imageUrls.length, "比例:", ratioStr);
      } else {
        const imageKey = request.editModel === "Flux-Klenin" ? "76:LoadImage.image" : "41:LoadImage.image";
        const promptKey = request.editModel === "Flux-Klenin" ? "108:CLIPTextEncode.text" : "68:TextEncodeQwenImageEditPlus.prompt";
        console.log("[API] 使用参数键名:", { imageKey, promptKey });
        requestData = {
          ...config.data,
          input_values: {
            ...config.data.input_values,
            [imageKey]: request.imageUrl,
            [promptKey]: request.prompt
          }
        };
      }
      console.log("[API] API URL:", config.url);
      console.log("[API] 请求数据:", JSON.stringify(requestData, null, 2));
      const response = await proxyFetchToBizyAir(config.url, config.headers, requestData, request.signal, request.editModel);
      console.log("[API] 响应状态:", response.status, response.statusText);
      const raw = await response.text();
      const result = parseResponseBody(raw);
      if (typeof result === "object") {
        console.log("[API] API 响应数据:", JSON.stringify(result, null, 2));
      } else {
        console.log("[API] API 响应数据:", String(result));
      }
      if (response.status === 202 && typeof result === "object" && result && result.requestId) {
        console.log("[API] 收到异步任务，requestId:", result.requestId);
        console.log("[API] 开始轮询任务状态...");
        const taskResult = await pollTaskStatus(result.requestId, config.headers, request.onProgress);
        if (taskResult.success && taskResult.data) {
          return {
            success: true,
            data: taskResult.data
          };
        } else {
          return {
            success: false,
            error: taskResult.error || "Task failed"
          };
        }
      }
      if (!response.ok) {
        const errMsg = getErrorMessageFromBody(result);
        throw new Error(`API request failed with status ${response.status}: ${errMsg}`);
      }
      const failedError = extractFailedError(result);
      if (failedError) {
        return { success: false, error: failedError };
      }
      if (typeof result === "object" && result && result.outputs && result.outputs.length > 0) {
        const imageUrl = result.outputs[0].object_url;
        if (imageUrl) {
          console.log("[API] 收到图片URL:", imageUrl);
          return {
            success: true,
            data: imageUrl
          };
        }
      }
      console.error("[API] 响应中没有图片数据");
      return {
        success: false,
        error: "No image data in response"
      };
    } catch (error) {
      console.error("[API] 编辑图片出错:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred"
      };
    }
  };
  const upscaleImage = async (request) => {
    console.log("[API] ========== 开始放大图片 ==========");
    console.log("[API] 请求参数:", {
      upscaleModel: request.upscaleModel,
      imageUrl: request.imageUrl,
      hasLocalFile: !!request.localFile
    });
    if (!request.upscaleModel) {
      throw new Error("Upscale model is required");
    }
    if (request.localFile) {
      console.log("[API] 检测到本地文件，开始上传到 BizyAir OSS...");
      const { uploadFileToBizyAir: uploadFileToBizyAir2 } = await __vitePreload(async () => {
        const { uploadFileToBizyAir: uploadFileToBizyAir3 } = await Promise.resolve().then(() => fileUpload);
        return { uploadFileToBizyAir: uploadFileToBizyAir3 };
      }, false ? __VITE_PRELOAD__ : void 0, _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("assets/main.js", document.baseURI).href);
      const uploadResult = await uploadFileToBizyAir2(request.localFile, 3);
      if (!uploadResult.success) {
        return {
          success: false,
          error: `文件上传失败: ${uploadResult.error}`
        };
      }
      console.log("[API] 文件上传成功，URL:", uploadResult.url);
      request.imageUrl = uploadResult.url;
    }
    if (!request.imageUrl) {
      throw new Error("Input image URL is required (请提供 imageUrl 或 localFile)");
    }
    try {
      const config = await loadWorkflowConfig(request.upscaleModel, "upscale");
      console.log("[API] 选择的模型:", request.upscaleModel);
      const inputValues = { ...config.data.input_values };
      const imageKey = Object.keys(inputValues).find((k) => k.includes("LoadImage.image"));
      if (imageKey) {
        inputValues[imageKey] = request.imageUrl;
      } else {
        console.warn("[API] 未找到 LoadImage.image 键名，使用默认键");
        inputValues["21:LoadImage.image"] = request.imageUrl;
      }
      console.log("[API] 使用参数键名:", { imageKey: imageKey || "21:LoadImage.image (default)" });
      const requestData = {
        ...config.data,
        input_values: inputValues
      };
      console.log("[API] API URL:", config.url);
      console.log("[API] 请求数据:", JSON.stringify(requestData, null, 2));
      const response = await proxyFetchToBizyAir(config.url, config.headers, requestData, request.signal, request.upscaleModel);
      console.log("[API] 响应状态:", response.status, response.statusText);
      const raw = await response.text();
      const result = parseResponseBody(raw);
      if (typeof result === "object") {
        console.log("[API] API 响应数据:", JSON.stringify(result, null, 2));
      } else {
        console.log("[API] API 响应数据:", String(result));
      }
      if (response.status === 202 && typeof result === "object" && result && result.requestId) {
        console.log("[API] 收到异步任务，requestId:", result.requestId);
        console.log("[API] 开始轮询任务状态...");
        const taskResult = await pollTaskStatus(result.requestId, config.headers, request.onProgress);
        if (taskResult.success && taskResult.data) {
          return {
            success: true,
            data: taskResult.data
          };
        } else {
          return {
            success: false,
            error: taskResult.error || "Task failed"
          };
        }
      }
      if (!response.ok) {
        const errMsg = getErrorMessageFromBody(result);
        throw new Error(`API request failed with status ${response.status}: ${errMsg}`);
      }
      const failedError = extractFailedError(result);
      if (failedError) {
        return { success: false, error: failedError };
      }
      if (typeof result === "object" && result && result.outputs && result.outputs.length > 0) {
        const imageUrl = result.outputs[0].object_url;
        if (imageUrl) {
          console.log("[API] 收到图片URL:", imageUrl);
          return {
            success: true,
            data: imageUrl
          };
        }
      }
      console.error("[API] 响应中没有图片数据");
      return {
        success: false,
        error: "No image data in response"
      };
    } catch (error) {
      console.error("[API] 放大图片出错:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred"
      };
    }
  };
  const removeBackground = async (request) => {
    console.log("[API] ========== 开始抠图 ==========");
    console.log("[API] 请求参数:", {
      removeBackgroundModel: request.removeBackgroundModel,
      prompt: request.prompt,
      imageUrl: request.imageUrl,
      hasLocalFile: !!request.localFile
    });
    if (!request.removeBackgroundModel) {
      throw new Error("Remove Background model is required");
    }
    if (request.localFile) {
      console.log("[API] 检测到本地文件，开始上传到 BizyAir OSS...");
      const { uploadFileToBizyAir: uploadFileToBizyAir2 } = await __vitePreload(async () => {
        const { uploadFileToBizyAir: uploadFileToBizyAir3 } = await Promise.resolve().then(() => fileUpload);
        return { uploadFileToBizyAir: uploadFileToBizyAir3 };
      }, false ? __VITE_PRELOAD__ : void 0, _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("assets/main.js", document.baseURI).href);
      const uploadResult = await uploadFileToBizyAir2(request.localFile, 3);
      if (!uploadResult.success) {
        return {
          success: false,
          error: `文件上传失败: ${uploadResult.error}`
        };
      }
      console.log("[API] 文件上传成功，URL:", uploadResult.url);
      request.imageUrl = uploadResult.url;
    }
    if (!request.imageUrl) {
      throw new Error("Input image URL is required (请提供 imageUrl 或 localFile)");
    }
    try {
      const config = await loadWorkflowConfig(request.removeBackgroundModel, "remove_background");
      console.log("[API] 选择的模型:", request.removeBackgroundModel);
      let inputValues = { ...config.data.input_values };
      if (request.removeBackgroundModel === "Targeted") {
        inputValues["38:LoadImage.image"] = request.imageUrl;
        inputValues["12:PrimitiveString.value"] = request.prompt || "";
      } else if (request.removeBackgroundModel === "Universal") {
        inputValues["11:LoadImage.image"] = request.imageUrl;
      }
      const requestData = {
        ...config.data,
        input_values: inputValues
      };
      console.log("[API] API URL:", config.url);
      console.log("[API] 请求数据:", JSON.stringify(requestData, null, 2));
      const response = await proxyFetchToBizyAir(config.url, config.headers, requestData, request.signal, request.removeBackgroundModel);
      console.log("[API] 响应状态:", response.status, response.statusText);
      const raw = await response.text();
      const result = parseResponseBody(raw);
      if (typeof result === "object") {
        console.log("[API] API 响应数据:", JSON.stringify(result, null, 2));
      } else {
        console.log("[API] API 响应数据:", String(result));
      }
      if (response.status === 202 && typeof result === "object" && result && result.requestId) {
        console.log("[API] 收到异步任务，requestId:", result.requestId);
        console.log("[API] 开始轮询任务状态...");
        const taskResult = await pollTaskStatus(result.requestId, config.headers, request.onProgress);
        if (taskResult.success && taskResult.data) {
          return {
            success: true,
            data: taskResult.data
          };
        } else {
          return {
            success: false,
            error: taskResult.error || "Task failed"
          };
        }
      }
      if (!response.ok) {
        const errMsg = getErrorMessageFromBody(result);
        throw new Error(`API request failed with status ${response.status}: ${errMsg}`);
      }
      const failedError = extractFailedError(result);
      if (failedError) {
        return { success: false, error: failedError };
      }
      if (typeof result === "object" && result && result.outputs && result.outputs.length > 0) {
        const imageUrl = result.outputs[0].object_url;
        if (imageUrl) {
          console.log("[API] 收到图片URL:", imageUrl);
          return {
            success: true,
            data: imageUrl
          };
        }
      }
      console.error("[API] 响应中没有图片数据");
      return {
        success: false,
        error: "No image data in response"
      };
    } catch (error) {
      console.error("[API] 抠图出错:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred"
      };
    }
  };
  const pollTaskStatus = async (requestId, headers, onProgress, options) => {
    const maxAttempts = 60;
    const interval = 2e3;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      console.log(`[API] 轮询任务状态 (${attempt}/${maxAttempts})...`);
      try {
        const response = await Promise.race([
          fetch(
            `${getProxyBaseURL()}/api/generate/proxy/result?request_id=${requestId}`,
            {
              method: "GET",
              headers: (() => {
                const h = {};
                const token = getAuthToken();
                if (token) h["Authorization"] = `Bearer ${token}`;
                return h;
              })()
            }
          ),
          new Promise(
            (_, reject) => setTimeout(() => reject(new Error("Poll timeout after 30000ms")), 3e4)
          )
        ]);
        if (!response.ok) {
          const raw2 = await response.text().catch(() => "");
          const body = parseResponseBody(raw2);
          const message = getErrorMessageFromBody(body);
          if (response.status === 401 || response.status === 403) {
            return { success: false, error: `Auth failed: ${message}` };
          }
          console.error("[API] 轮询失败:", response.status, response.statusText, message);
          await new Promise((resolve) => setTimeout(resolve, interval));
          continue;
        }
        const raw = await response.text();
        const result = parseResponseBody(raw);
        console.log("[API] 任务状态:", result == null ? void 0 : result.status);
        if (result.status === "Success" && result.outputs && result.outputs.length > 0) {
          const textOutputs = result.outputs.map((o) => o.text).filter((t2) => typeof t2 === "string" && t2.length > 0);
          if (textOutputs.length > 0) {
            console.log("[API] 任务完成，文本输出:", textOutputs[0]);
            if (onProgress) onProgress(100);
            return { success: true, data: textOutputs[0] };
          }
          const imageUrls = result.outputs.map((o) => o.object_url).filter(Boolean);
          console.log("[API] 任务完成，图片URLs:", imageUrls);
          if (onProgress) onProgress(100);
          return {
            success: true,
            data: imageUrls[0],
            urls: imageUrls
          };
        }
        if (result.status === "Failed") {
          console.error("[API] 任务失败:", result);
          return {
            success: false,
            error: result.error_msg || "Task failed"
          };
        }
        if (onProgress) {
          const progress = Math.min(Math.floor(attempt / maxAttempts * 90), 90);
          onProgress(progress);
        }
        await new Promise((resolve) => setTimeout(resolve, interval));
      } catch (error) {
        console.error("[API] 轮询出错:", error);
        await new Promise((resolve) => setTimeout(resolve, interval));
      }
    }
    return {
      success: false,
      error: "Task timeout"
    };
  };
  const translatePrompt = async (text) => {
    console.log("[Translate] 发送请求到云端代理...");
    console.log("[Translate] Input text:", text);
    const url = `${getProxyBaseURL()}/api/translate`;
    try {
      const responseText = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.timeout = 6e4;
        xhr.onload = function() {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve(xhr.responseText);
          } else {
            reject(new Error(`HTTP ${xhr.status}: ${xhr.responseText}`));
          }
        };
        xhr.onerror = () => reject(new Error("Network error"));
        xhr.ontimeout = () => reject(new Error("Request timeout after 60000ms"));
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        try {
          const token = localStorage.getItem("ps_plugin_token");
          if (token) {
            xhr.setRequestHeader("Authorization", `Bearer ${token}`);
          }
        } catch {
        }
        xhr.send(JSON.stringify({ text }));
      });
      let result;
      try {
        result = JSON.parse(responseText);
      } catch {
        result = responseText;
      }
      console.log("[Translate] Raw response:", JSON.stringify(result, null, 2));
      const translatedText = result.translated || result.translatedText;
      if (result.success && typeof translatedText === "string") {
        return {
          success: true,
          translated: translatedText
        };
      }
      return {
        success: false,
        error: (result == null ? void 0 : result.error) || "Invalid response from translation API"
      };
    } catch (error) {
      console.error("[Translate] 请求失败:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Translation service unavailable"
      };
    }
  };
  async function downloadAndProcessImage(remoteUrl, customFileName, prompt = "", folderName = "generate") {
    const { storage } = require("uxp");
    const fs2 = storage.localFileSystem;
    console.log(`[Service] Start downloading: ${remoteUrl} to folder: ${folderName}`);
    try {
      const MAX_RETRIES = 3;
      const TIMEOUT_MS = 3e4;
      let lastError;
      let response;
      for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
          console.log(`[Service] Download attempt ${attempt}/${MAX_RETRIES} for: ${remoteUrl}`);
          const fetchWithTimeout = Promise.race([
            fetch(remoteUrl, {
              method: "GET",
              headers: {
                "Accept": "image/png,image/webp,image/*,*/*"
              }
            }),
            new Promise(
              (_, reject) => setTimeout(() => reject(new Error(`Download timeout after ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
            )
          ]);
          response = await fetchWithTimeout;
          if (response.ok) {
            break;
          } else {
            throw new Error(`Download failed: ${response.status} ${response.statusText}`);
          }
        } catch (err) {
          lastError = err;
          console.warn(`[Service] Download attempt ${attempt} failed:`, err);
          if (attempt < MAX_RETRIES) {
            const delay = attempt * 1e3;
            console.log(`[Service] Retrying in ${delay}ms...`);
            await new Promise((resolve) => setTimeout(resolve, delay));
          }
        }
      }
      if (!response || !response.ok) {
        throw lastError || new Error("All download attempts failed");
      }
      const blob = await response.blob();
      const arrayBuffer = await blob.arrayBuffer();
      console.log(`[Service] Downloaded ${arrayBuffer.byteLength} bytes`);
      const dataFolder = await fs2.getDataFolder();
      let galleryFolder;
      try {
        const galleryRoot = await dataFolder.getEntry("gallery");
        console.log(`[Service] Found gallery root: ${galleryRoot.nativePath}`);
        try {
          galleryFolder = await galleryRoot.getEntry(folderName);
          console.log(`[Service] Found folder: ${folderName}`);
        } catch {
          galleryFolder = await galleryRoot.createFolder(folderName);
          console.log(`[Service] Created folder: ${folderName}`);
        }
      } catch {
        try {
          const galleryRoot = await dataFolder.createFolder("gallery");
          galleryFolder = await galleryRoot.createFolder(folderName);
          console.log(`[Service] Created gallery root and folder: ${folderName}`);
        } catch (e) {
          const galleryRoot = await dataFolder.getEntry("gallery");
          galleryFolder = await galleryRoot.createFolder(folderName);
          console.log(`[Service] Fallback: Created folder: ${folderName}`);
        }
      }
      let fileBaseName = `img_${Date.now()}`;
      if (customFileName) ;
      const pngFileName = `${fileBaseName}.png`;
      const jsonFileName = `${fileBaseName}.json`;
      const fileEntry = await galleryFolder.createFile(pngFileName, { overwrite: true });
      await fileEntry.write(arrayBuffer, { format: storage.formats.binary });
      console.log(`[Service] Saved image to disk: ${fileEntry.nativePath}`);
      const timestamp = Date.now();
      const jsonContent = JSON.stringify({
        id: fileBaseName,
        prompt,
        createdAt: timestamp,
        width: 1024,
        // Ideally passed from caller, but default for now
        height: 1024,
        model: "ComfyUI",
        source: "generate"
      }, null, 2);
      const jsonFile = await galleryFolder.createFile(jsonFileName, { overwrite: true });
      await jsonFile.write(jsonContent, { format: storage.formats.utf8 });
      console.log(`[Service] Saved metadata to disk: ${jsonFile.nativePath}`);
      const displayUrl = URL.createObjectURL(blob);
      const sessionToken = await fs2.createSessionToken(fileEntry);
      console.log(`[Service] Processing complete. displayUrl: ${displayUrl}, localPath: ${fileEntry.nativePath}`);
      return {
        success: true,
        displayUrl,
        // ✅ Short string
        sessionToken,
        // ✅ Object
        localPath: fileEntry.nativePath,
        fileName: pngFileName
      };
    } catch (error) {
      console.error("[Service] Image processing failed:", error);
      throw error;
    }
  }
  const FOLDER_CONFIGS = [
    {
      name: "inpainting",
      description: "Local image inpainting/removal results",
      icon: "brush",
      color: "#FF6B6B",
      readmeContent: "# Inpainting Folder\n\nThis folder stores images generated by the Inpainting (局部重绘) feature.\n\n## Usage\n- Stores images created using mask-based local editing\n- Contains before/after comparison images\n\n## File Types\n- PNG images (*.png)\n- Metadata JSON files (*.json)\n"
    },
    {
      name: "edit-image",
      description: "AI image editing results",
      icon: "edit",
      color: "#4ECDC4",
      readmeContent: "# Edit Image Folder\n\nThis folder stores images generated by the Edit Image (编辑图片) feature.\n\n## Usage\n- Stores images created using AI editing models (Qwen, Nanobanana, Flux-Klenin)\n- Contains edited versions of source images\n\n## File Types\n- PNG images (*.png)\n- Metadata JSON files (*.json)\n"
    },
    {
      name: "upscale-image",
      description: "Image upscaling/enlargement results",
      icon: "zoom",
      color: "#45B7D1",
      readmeContent: "# Upscale Image Folder\n\nThis folder stores images generated by the Upscale Image (图片放大) feature.\n\n## Usage\n- Stores images enlarged using Seed Face 2K or Seed Face 4K upscaling\n- Contains high-resolution versions of source images\n\n## File Types\n- PNG images (*.png)\n- Metadata JSON files (*.json)\n"
    },
    {
      name: "remove-background",
      description: "Background removal results",
      icon: "layers",
      color: "#96CEB4",
      readmeContent: "# Remove Background Folder\n\nThis folder stores images generated by the Remove Background (移除背景) feature.\n\n## Usage\n- Stores images with backgrounds removed\n- Supports Universal and Targeted removal modes\n\n## File Types\n- PNG images with transparency (*.png)\n- Metadata JSON files (*.json)\n"
    },
    {
      name: "generate",
      description: "Gallery text-to-image generation results",
      icon: "image",
      color: "#DDA0DD",
      readmeContent: "# Generate Folder\n\nThis folder stores images generated by the Gallery Text-to-Image (文生图) feature.\n\n## Usage\n- Stores images created from text prompts\n- Contains AI-generated artwork based on descriptions\n\n## File Types\n- PNG images (*.png)\n- Metadata JSON files (*.json)\n"
    }
  ];
  const FOLDER_DISPLAY_NAMES = {
    "inpainting": "局部重绘",
    "edit-image": "编辑图片",
    "upscale-image": "图片放大",
    "remove-background": "移除背景",
    "generate": "文生图"
  };
  const INDEX_FILE_NAME = "index.json";
  const SUPPORTED_IMAGE_FORMATS = [".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"];
  function isImageFile(filename) {
    const ext = filename.toLowerCase().slice(filename.lastIndexOf("."));
    return SUPPORTED_IMAGE_FORMATS.includes(ext);
  }
  function getImageFormat(filename) {
    const ext = filename.toLowerCase().slice(filename.lastIndexOf(".") + 1);
    const formatMap = {
      "jpg": "jpeg",
      "jpeg": "jpeg",
      "png": "png",
      "gif": "gif",
      "webp": "webp",
      "bmp": "bmp"
    };
    return formatMap[ext] || "png";
  }
  const HistoryManager = {
    async initializeFolders() {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      let galleryFolder;
      try {
        galleryFolder = await dataFolder.getEntry("gallery");
      } catch {
        galleryFolder = await dataFolder.createFolder("gallery");
      }
      const existingEntries = await galleryFolder.getEntries();
      const existingFolderNames = /* @__PURE__ */ new Set();
      for (const entry of existingEntries) {
        if (entry.isFolder) {
          existingFolderNames.add(entry.name);
        }
      }
      const timestamp = Date.now();
      const indexData = {
        version: "1.0",
        lastUpdated: timestamp,
        folders: []
      };
      for (const config of FOLDER_CONFIGS) {
        let folderName = config.name;
        let folder;
        let isNew = false;
        if (existingFolderNames.has(folderName)) {
          let counter = 1;
          while (existingFolderNames.has(`${folderName}_${counter}`)) {
            counter++;
          }
          if (counter > 1) {
            folderName = `${folderName}_${counter}`;
          }
        }
        try {
          folder = await galleryFolder.getEntry(folderName);
        } catch {
          folder = await galleryFolder.createFolder(folderName);
          isNew = true;
        }
        const readmeName = "README.md";
        let readmeExists = false;
        try {
          await folder.getEntry(readmeName);
          readmeExists = true;
        } catch {
        }
        if (!readmeExists) {
          const readmeFile = await folder.createFile(readmeName, { overwrite: true });
          await readmeFile.write(config.readmeContent, { format: formats2.utf8 });
        }
        indexData.folders.push({
          name: folderName,
          description: config.description,
          createdAt: isNew ? timestamp : timestamp,
          hasReadme: true
        });
      }
      const sortedFolders = indexData.folders.sort(
        (a, b) => a.name.localeCompare(b.name)
      );
      indexData.folders = sortedFolders;
      try {
        const indexFile = await galleryFolder.getEntry(INDEX_FILE_NAME);
        await indexFile.write(JSON.stringify(indexData, null, 2), { format: formats2.utf8 });
      } catch {
        const indexFile = await galleryFolder.createFile(INDEX_FILE_NAME, { overwrite: true });
        await indexFile.write(JSON.stringify(indexData, null, 2), { format: formats2.utf8 });
      }
      console.log("[HistoryManager] Folder initialization complete");
    },
    async getFolders() {
      const { localFileSystem: localFileSystem2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      let galleryFolder;
      try {
        galleryFolder = await dataFolder.getEntry("gallery");
      } catch {
        galleryFolder = await dataFolder.createFolder("gallery");
      }
      const folders = [];
      for (const config of FOLDER_CONFIGS) {
        try {
          const folder = await galleryFolder.getEntry(config.name);
          folders.push({
            id: folder.name,
            name: folder.name,
            path: folder.nativePath
          });
        } catch {
          const newFolder = await galleryFolder.createFolder(config.name);
          folders.push({
            id: newFolder.name,
            name: newFolder.name,
            path: newFolder.nativePath
          });
        }
      }
      return folders;
    },
    async getFolderStatuses() {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      let galleryFolder;
      try {
        galleryFolder = await dataFolder.getEntry("gallery");
      } catch {
        return [];
      }
      const entries = await galleryFolder.getEntries();
      const existingFolderNames = /* @__PURE__ */ new Set();
      for (const entry of entries) {
        if (entry.isFolder) {
          existingFolderNames.add(entry.name);
        }
      }
      const statuses = [];
      for (const config of FOLDER_CONFIGS) {
        const folderName = config.name;
        let itemCount = 0;
        let lastUpdated = null;
        const isActive = existingFolderNames.has(folderName);
        if (isActive) {
          try {
            const folder = await galleryFolder.getEntry(folderName);
            const folderEntries = await folder.getEntries();
            const jsonFiles = folderEntries.filter((e) => e.name.endsWith(".json"));
            itemCount = jsonFiles.length;
            if (itemCount > 0) {
              let latestTime = 0;
              for (const jsonFile of jsonFiles) {
                try {
                  const content = await jsonFile.read({ format: formats2.utf8 });
                  const meta = JSON.parse(content);
                  if (meta.createdAt && meta.createdAt > latestTime) {
                    latestTime = meta.createdAt;
                  }
                } catch {
                }
              }
              lastUpdated = latestTime || null;
            }
          } catch {
          }
        }
        statuses.push({
          name: folderName,
          displayName: FOLDER_DISPLAY_NAMES[folderName] || folderName,
          description: config.description,
          icon: config.icon || "folder",
          color: config.color || "#95A5A6",
          itemCount,
          lastUpdated,
          isActive
        });
      }
      return statuses;
    },
    async createFolder(name) {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      let galleryFolder = await dataFolder.getEntry("gallery");
      const trimmedName = name.trim();
      if (!trimmedName) {
        throw new Error("文件夹名称不能为空");
      }
      const invalidChars = /[<>:"/\\|?*]/;
      if (invalidChars.test(trimmedName)) {
        throw new Error('文件夹名称包含非法字符: < > : " / \\ | ? *');
      }
      if (trimmedName.length > 100) {
        throw new Error("文件夹名称过长（最多100个字符）");
      }
      const reservedNames = ["CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"];
      const upperName = trimmedName.toUpperCase();
      if (reservedNames.includes(upperName)) {
        throw new Error(`"${trimmedName}" 是系统保留名称，无法使用`);
      }
      const existingEntries = await galleryFolder.getEntries();
      const existingFolderNames = /* @__PURE__ */ new Set();
      for (const entry of existingEntries) {
        if (entry.isFolder) {
          existingFolderNames.add(entry.name.toLowerCase());
        }
      }
      if (existingFolderNames.has(trimmedName.toLowerCase())) {
        throw new Error(`文件夹 "${trimmedName}" 已存在，请使用其他名称`);
      }
      let newFolder = null;
      let created = false;
      try {
        newFolder = await galleryFolder.createFolder(trimmedName);
        created = true;
        const readmeName = "README.md";
        const readmeFile = await newFolder.createFile(readmeName, { overwrite: true });
        await readmeFile.write(`# ${trimmedName}

User-created folder.
`, { format: formats2.utf8 });
        try {
          const indexFile = await galleryFolder.getEntry(INDEX_FILE_NAME);
          const content = await indexFile.read({ format: formats2.utf8 });
          const indexData = JSON.parse(content);
          indexData.folders.push({
            name: trimmedName,
            description: "User-created folder",
            createdAt: Date.now(),
            hasReadme: true
          });
          indexData.lastUpdated = Date.now();
          indexData.folders.sort((a, b) => a.name.localeCompare(b.name));
          await indexFile.write(JSON.stringify(indexData, null, 2), { format: formats2.utf8 });
        } catch (err) {
          console.warn("[HistoryManager] Failed to update index.json:", err);
        }
        return {
          id: newFolder.name,
          name: newFolder.name,
          path: newFolder.nativePath
        };
      } catch (err) {
        if (created && newFolder) {
          try {
            await newFolder.delete();
          } catch {
            console.error("[HistoryManager] Rollback failed: could not delete created folder");
          }
        }
        throw err;
      }
    },
    async getItemsInFolder(folderName) {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      const galleryFolder = await dataFolder.getEntry("gallery");
      console.log(`[HistoryManager] Getting items for folder: ${folderName}`);
      let targetFolder;
      if (folderName === "root") {
        targetFolder = galleryFolder;
      } else {
        try {
          targetFolder = await galleryFolder.getEntry(folderName);
          console.log(`[HistoryManager] Found target folder: ${targetFolder.nativePath}`);
        } catch {
          console.log(`[HistoryManager] Folder not found: ${folderName}`);
          return [];
        }
      }
      const entries = await targetFolder.getEntries();
      console.log(`[HistoryManager] Total entries in folder ${folderName}:`, entries.length);
      const metaFiles = entries.filter((e) => e.name.endsWith(".json"));
      console.log(`[HistoryManager] Found ${metaFiles.length} JSON files`);
      const itemPromises = metaFiles.map(async (metaFile) => {
        try {
          const content = await metaFile.read({ format: formats2.utf8 });
          const meta = JSON.parse(content);
          const imageFileName = `${meta.id}.png`;
          const imageFile = await targetFolder.getEntry(imageFileName);
          const arrayBuffer = await imageFile.read({ format: formats2.binary });
          const base64 = base64ArrayBuffer(arrayBuffer);
          const format = detectImageFormat(arrayBuffer);
          const dataUrl = `data:image/${format};base64,${base64}`;
          return {
            ...meta,
            dataUrl,
            savedPath: imageFile.nativePath,
            metaPath: metaFile.nativePath
          };
        } catch (err) {
          console.error(`[HistoryManager] Failed to load item ${metaFile.name}:`, err);
          return null;
        }
      });
      const results = await Promise.all(itemPromises);
      const items = results.filter((item) => item !== null);
      console.log(`[HistoryManager] Returning ${items.length} items for folder ${folderName}`);
      return items.sort((a, b) => b.createdAt - a.createdAt);
    },
    /**
     * Lightweight version: only reads metadata JSON files, does NOT read image data.
     * Returns items without dataUrl for fast initial listing.
     */
    async getItemsInFolderLite(folderName) {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      const galleryFolder = await dataFolder.getEntry("gallery");
      let targetFolder;
      if (folderName === "root") {
        targetFolder = galleryFolder;
      } else {
        try {
          targetFolder = await galleryFolder.getEntry(folderName);
        } catch {
          return [];
        }
      }
      const entries = await targetFolder.getEntries();
      const metaFiles = entries.filter((e) => e.name.endsWith(".json"));
      const itemPromises = metaFiles.map(async (metaFile) => {
        try {
          const content = await metaFile.read({ format: formats2.utf8 });
          const meta = JSON.parse(content);
          const imageFileName = `${meta.id}.png`;
          const imageFile = await targetFolder.getEntry(imageFileName);
          return {
            id: meta.id,
            dataUrl: "",
            createdAt: meta.createdAt || Date.now(),
            prompt: meta.prompt || "",
            savedPath: imageFile.nativePath,
            metaPath: metaFile.nativePath,
            width: meta.width,
            height: meta.height,
            source: meta.source || "generate",
            name: meta.name || "",
            type: meta.type || "",
            size: meta.size
          };
        } catch {
          return null;
        }
      });
      const results = await Promise.all(itemPromises);
      const items = results.filter((item) => item !== null);
      return items.sort((a, b) => b.createdAt - a.createdAt);
    },
    /**
     * Load a single image's dataUrl from a specific folder.
     */
    async getItemDataUrl(folderName, itemId) {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      const galleryFolder = await dataFolder.getEntry("gallery");
      let targetFolder;
      if (folderName === "root") {
        targetFolder = galleryFolder;
      } else {
        targetFolder = await galleryFolder.getEntry(folderName);
      }
      const imageFile = await targetFolder.getEntry(`${itemId}.png`);
      const arrayBuffer = await imageFile.read({ format: formats2.binary });
      const format = detectImageFormat(arrayBuffer);
      return `data:image/${format};base64,${base64ArrayBuffer(arrayBuffer)}`;
    },
    /**
     * Load a single image's raw ArrayBuffer from a specific folder.
     * Useful for creating Blob URLs without expensive base64 encoding.
     */
    async getItemBuffer(folderName, itemId) {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      const galleryFolder = await dataFolder.getEntry("gallery");
      let targetFolder;
      if (folderName === "root") {
        targetFolder = galleryFolder;
      } else {
        targetFolder = await galleryFolder.getEntry(folderName);
      }
      const imageFile = await targetFolder.getEntry(`${itemId}.png`);
      return await imageFile.read({ format: formats2.binary });
    },
    async saveItemToFolder(item, folderName = "generate") {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      const dataFolder = await localFileSystem2.getDataFolder();
      const galleryFolder = await dataFolder.getEntry("gallery");
      let targetFolder;
      try {
        targetFolder = await galleryFolder.getEntry(folderName);
      } catch {
        targetFolder = await galleryFolder.createFolder(folderName);
      }
      const pngFile = await targetFolder.createFile(`${item.id}.png`, { overwrite: true });
      const buffer = dataUrlToArrayBuffer(item.dataUrl);
      await pngFile.write(buffer, { format: formats2.binary });
      const metaFile = await targetFolder.createFile(`${item.id}.json`, { overwrite: true });
      const meta = {
        id: item.id,
        createdAt: item.createdAt,
        prompt: item.prompt || "",
        width: item.width || null,
        height: item.height || null,
        source: item.source,
        name: item.name || "",
        type: item.type || "",
        size: item.size || null
      };
      await metaFile.write(JSON.stringify(meta), { format: formats2.utf8 });
      return { savedPath: pngFile.nativePath, metaPath: metaFile.nativePath };
    },
    async deleteItemFromFolder(itemId, folderName) {
      const { localFileSystem: localFileSystem2 } = require("uxp").storage;
      try {
        const dataFolder = await localFileSystem2.getDataFolder();
        const galleryFolder = await dataFolder.getEntry("gallery");
        const targetFolder = await galleryFolder.getEntry(folderName);
        try {
          const pngFile = await targetFolder.getEntry(`${itemId}.png`);
          await pngFile.delete();
        } catch (e) {
        }
        try {
          const metaFile = await targetFolder.getEntry(`${itemId}.json`);
          await metaFile.delete();
        } catch (e) {
        }
        console.log(`[HistoryManager] Deleted item ${itemId} from folder ${folderName}`);
        return true;
      } catch (err) {
        console.error(`[HistoryManager] Failed to delete item ${itemId}:`, err);
        return false;
      }
    },
    async getTextFolderImages(customPath) {
      const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
      try {
        let targetFolder;
        if (customPath) {
          const token = localStorage.getItem("watch_folder_token");
          if (token) {
            try {
              targetFolder = await localFileSystem2.getEntryForPersistentToken(token);
              console.log("[HistoryManager] 通过 token 获取文件夹:", (targetFolder == null ? void 0 : targetFolder.name) || (targetFolder == null ? void 0 : targetFolder.nativePath));
            } catch (err) {
              console.error("[HistoryManager] Token 失效:", (err == null ? void 0 : err.message) || err);
              return { images: [], error: "文件夹权限已失效，请重新选择" };
            }
          } else {
            console.warn("[HistoryManager] 没有 watch_folder_token");
            return { images: [], error: "请先选择监控文件夹" };
          }
        } else {
          const dataFolder = await localFileSystem2.getDataFolder();
          try {
            targetFolder = await dataFolder.getEntry("text");
          } catch {
            try {
              targetFolder = await dataFolder.createFolder("text");
            } catch (err) {
              return { images: [], error: "无法创建 text 文件夹" };
            }
          }
        }
        const entries = await targetFolder.getEntries();
        console.log("[HistoryManager] 文件夹条目总数:", entries.length);
        const imageFiles = entries.filter((e) => {
          const isFile = e.isFile !== void 0 ? e.isFile : !e.isFolder;
          const isImage = isImageFile(e.name);
          console.log(`[HistoryManager] 条目: ${e.name}, isFile=${isFile}, isImage=${isImage}`);
          return isFile && isImage;
        });
        console.log("[HistoryManager] 图片文件数量:", imageFiles.length);
        const imagePromises = imageFiles.map(async (file) => {
          try {
            console.log(`[HistoryManager] 开始读取: ${file.name}`);
            const arrayBuffer = await file.read({ format: formats2.binary });
            console.log(`[HistoryManager] 读取成功: ${file.name}, size=${(arrayBuffer == null ? void 0 : arrayBuffer.byteLength) || 0}`);
            const base64 = base64ArrayBuffer(arrayBuffer);
            const format = getImageFormat(file.name);
            const mimeType = `image/${format}`;
            const dataUrl = `data:${mimeType};base64,${base64}`;
            return {
              id: file.name.replace(/\.[^/.]+$/, ""),
              name: file.name,
              url: dataUrl,
              path: file.nativePath,
              format
            };
          } catch (err) {
            console.error(`[HistoryManager] Failed to read image ${file.name}:`, (err == null ? void 0 : err.message) || err);
            return null;
          }
        });
        const results = await Promise.all(imagePromises);
        const images = results.filter((img) => img !== null);
        console.log("[HistoryManager] 成功加载图片数量:", images.length);
        images.sort((a, b) => b.name.localeCompare(a.name));
        return { images };
      } catch (err) {
        console.error("[HistoryManager] Error loading text folder:", err);
        return { images: [], error: err.message || "无法访问文件夹" };
      }
    },
    async selectWatchFolder() {
      const { localFileSystem: localFileSystem2 } = require("uxp").storage;
      try {
        const folder = await localFileSystem2.getFolder();
        if (!folder) {
          return { success: false, error: "未选择文件夹" };
        }
        const token = await localFileSystem2.createPersistentToken(folder);
        localStorage.setItem("watch_folder_token", token);
        localStorage.setItem("watch_folder_name", folder.name);
        return { success: true, path: folder.nativePath };
      } catch (err) {
        console.error("[HistoryManager] Error selecting folder:", err);
        return { success: false, error: err.message || "选择文件夹失败" };
      }
    },
    getWatchFolderName() {
      return localStorage.getItem("watch_folder_name");
    },
    clearWatchFolder() {
      localStorage.removeItem("watch_folder_token");
      localStorage.removeItem("watch_folder_name");
    }
  };
  function detectImageFormat(arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer.slice(0, 12));
    if (bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) {
      return "png";
    }
    if (bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) {
      return "jpeg";
    }
    if (bytes[0] === 82 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 70 && bytes[8] === 87 && bytes[9] === 69 && bytes[10] === 66 && bytes[11] === 80) {
      return "webp";
    }
    if (bytes[0] === 71 && bytes[1] === 73 && bytes[2] === 70) {
      return "gif";
    }
    return "png";
  }
  function base64ArrayBuffer(arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer);
    const chunkSize = 32768;
    let binary = "";
    for (let i = 0; i < bytes.length; i += chunkSize) {
      const chunk = bytes.subarray(i, i + chunkSize);
      binary += String.fromCharCode.apply(null, chunk);
    }
    return btoa(binary);
  }
  function dataUrlToArrayBuffer(dataUrl) {
    const base64Content = dataUrl.split(",")[1] || "";
    const binaryString = atob(base64Content);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  }
  const LANGUAGE_KEY = "ps_plugin_language";
  const getLanguage = () => {
    try {
      const stored = localStorage.getItem(LANGUAGE_KEY);
      if (stored === "en" || stored === "zh") return stored;
    } catch {
    }
    return "zh";
  };
  const setLanguage = (lang) => {
    try {
      localStorage.setItem(LANGUAGE_KEY, lang);
    } catch {
    }
  };
  const translations = {
    zh: {
      // Profile
      "profile.activateTitle": "激活插件",
      "profile.activateDesc": "输入你的 License Key 以激活插件并使用全部功能",
      "profile.licensePlaceholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
      "profile.verifying": "验证中...",
      "profile.verifyActivate": "验证并激活",
      "profile.visitWebsite": "访问官网",
      "profile.activated": "已激活",
      "profile.licenseKey": "License Key",
      "profile.balance": "当前余额",
      "profile.expiresAt": "有效期至",
      "profile.routeSelect": "线路选择",
      "profile.current": "当前使用",
      "profile.timeout": "超时",
      "profile.refreshing": "刷新中...",
      "profile.refreshBalance": "刷新余额",
      "profile.logout": "退出登录",
      "profile.expired": "登录已过期，请重新输入 License Key",
      "profile.enterLicense": "请输入 License Key",
      "profile.verifyFailed": "验证失败，Key 无效",
      "profile.verifyError": "验证失败",
      "profile.refreshFailed": "刷新余额失败",
      "profile.refreshError": "刷新失败",
      "profile.noLicenseKey": "无法刷新：本地没有保存 License Key",
      "profile.language": "语言",
      "profile.languageZh": "中文",
      "profile.languageEn": "英文",
      // GenerationControl
      "generation.selectModel": "选择模型",
      "generation.aspectRatio": "比例",
      "generation.lora": "Lora",
      "generation.loraNone": "无",
      "generation.loraNoneEn": "无",
      "generation.loraTurbo": "trubo",
      "generation.loraKlein": "Klein角色编辑",
      "generation.seed": "Seed",
      "generation.batchSize": "Batch size",
      "generation.prompt": "提示词",
      "generation.translate": "翻译为英文",
      "generation.randomSeed": "随机 Seed",
      "generation.prevHistory": "上一条历史",
      "generation.nextHistory": "下一条历史",
      "generation.redrawStrength": "重绘强度",
      "generation.conservative": "保守",
      "generation.moderate": "适中",
      "generation.aggressive": "激进",
      "generation.promptPlaceholder": "请输入提示词，描述你想要生成的内容...",
      "generation.generate": "生成",
      "generation.cancel": "取消",
      "generation.output": "Output",
      // ImageUploader
      "uploader.referenceImage": "参考图片",
      "uploader.uploadImage": "上传图片",
      "uploader.delete": "删除",
      // Main toolbar (mode labels)
      "main.enterPrompt": "Enter a prompt...",
      "main.stop": "Stop",
      "main.generate": "Generate",
      "main.inpainting": "局部重绘",
      "main.editImage": "图像编辑",
      "main.upscaleImage": "图像放大",
      "main.removeBackground": "移除背景",
      "main.text2Image": "文生图",
      // Gallery / Common
      "common.close": "关闭",
      "common.loading": "加载中...",
      "common.noHistory": "暂无历史记录",
      "common.generatedPlaceholder": "Generated image will appear here",
      "common.addedToCanvas": "✓ 已添加到画布",
      "common.placingImage": "🔄 Placing image...",
      "common.addSuccess": "✅ Image successfully added to canvas",
      "common.copyFailed": "图片复制失败，请重试",
      "common.addedNImages": "已添加 {n} 张图片到 Edit 参考图",
      "common.addFailed": "添加到参考图失败，请重试",
      "common.deletedNImages": "已删除 {n} 张图片",
      "common.deleteFailed": "删除失败，请重试",
      "common.liveStart": "🚀 Live 模式启动...",
      "common.liveFailed": "❌ 图生图请求失败",
      "common.liveStopped": "已停止图生图",
      "common.liveDone": "✅ 图生图完成",
      "common.activateFirst": "请先前往 Profile 页面输入 License Key 激活插件",
      "common.selectFolder": "📂 选择文件夹",
      "common.folderSelected": "📁 已选择",
      "common.addToRef": "添加到参考图",
      "common.adding": "添加中...",
      "common.confirmDelete": "删除",
      "common.historyLabel": "History",
      "common.localFolder": "本地文件夹",
      "common.done": "完成",
      "common.selectImage": "选择图片",
      "common.taskFailed": "任务失败",
      "common.taskTimeout": "任务超时",
      // Model names
      "model.放大图片": "放大图片",
      "model.移除图片": "移除图片",
      "model.Seed Face 2K": "Seed Face 2K",
      "model.Seed Face 4K": "Seed Face 4K",
      "model.面部形象修复": "面部形象修复",
      "model.Klein4K清晰": "Klein4K清晰",
      "model.Z-image动漫放大": "Z-image动漫放大",
      "model.Seedream 5.0": "Seedream 5.0",
      // Errors / API
      "error.enterPrompt": "请输入提示词",
      "error.allFailed": "所有图片下载失败",
      "error.generateFailed": "生成图片失败",
      "error.noImage": "未返回图片",
      "error.unknown": "发生未知错误",
      "error.modeNotSupported": "模式暂不支持"
    },
    en: {
      // Profile
      "profile.activateTitle": "Activate Plugin",
      "profile.activateDesc": "Enter your License Key to activate the plugin and access all features",
      "profile.licensePlaceholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
      "profile.verifying": "Verifying...",
      "profile.verifyActivate": "Verify & Activate",
      "profile.visitWebsite": "Visit Website",
      "profile.activated": "Activated",
      "profile.licenseKey": "License Key",
      "profile.balance": "Balance",
      "profile.expiresAt": "Expires At",
      "profile.routeSelect": "Route",
      "profile.current": "Current",
      "profile.timeout": "Timeout",
      "profile.refreshing": "Refreshing...",
      "profile.refreshBalance": "Refresh Balance",
      "profile.logout": "Logout",
      "profile.expired": "Session expired, please re-enter your License Key",
      "profile.enterLicense": "Please enter your License Key",
      "profile.verifyFailed": "Verification failed, invalid Key",
      "profile.verifyError": "Verification failed",
      "profile.refreshFailed": "Failed to refresh balance",
      "profile.refreshError": "Refresh failed",
      "profile.noLicenseKey": "Unable to refresh: no License Key saved locally",
      "profile.language": "Language",
      "profile.languageZh": "中文",
      "profile.languageEn": "English",
      // GenerationControl
      "generation.selectModel": "Model",
      "generation.aspectRatio": "Aspect Ratio",
      "generation.lora": "Lora",
      "generation.loraNone": "None",
      "generation.loraNoneEn": "None",
      "generation.loraTurbo": "trubo",
      "generation.loraKlein": "Klein Character Edit",
      "generation.seed": "Seed",
      "generation.batchSize": "Batch Size",
      "generation.prompt": "Prompt",
      "generation.translate": "Translate to English",
      "generation.randomSeed": "Random Seed",
      "generation.prevHistory": "Previous",
      "generation.nextHistory": "Next",
      "generation.redrawStrength": "Redraw Strength",
      "generation.conservative": "Conservative",
      "generation.moderate": "Moderate",
      "generation.aggressive": "Aggressive",
      "generation.promptPlaceholder": "Enter a prompt describing what you want to generate...",
      "generation.generate": "Generate",
      "generation.cancel": "Cancel",
      "generation.output": "Output",
      // ImageUploader
      "uploader.referenceImage": "Reference Images",
      "uploader.uploadImage": "Upload Image",
      "uploader.delete": "Delete",
      // Main toolbar
      "main.enterPrompt": "Enter a prompt...",
      "main.stop": "Stop",
      "main.generate": "Generate",
      "main.inpainting": "Inpainting",
      "main.editImage": "Edit Image",
      "main.upscaleImage": "Upscale",
      "main.removeBackground": "Remove BG",
      "main.text2Image": "Text2Image",
      // Gallery / Common
      "common.close": "Close",
      "common.loading": "Loading...",
      "common.noHistory": "No history yet",
      "common.generatedPlaceholder": "Generated image will appear here",
      "common.addedToCanvas": "✓ Added to canvas",
      "common.placingImage": "🔄 Placing image...",
      "common.addSuccess": "✅ Image successfully added to canvas",
      "common.copyFailed": "Failed to copy image, please retry",
      "common.addedNImages": "Added {n} image(s) to Edit reference",
      "common.addFailed": "Failed to add to reference, please retry",
      "common.deletedNImages": "Deleted {n} image(s)",
      "common.deleteFailed": "Delete failed, please retry",
      "common.liveStart": "🚀 Live mode started...",
      "common.liveFailed": "❌ Img2img request failed",
      "common.liveStopped": "Img2img stopped",
      "common.liveDone": "✅ Img2img complete",
      "common.activateFirst": "Please go to Profile and enter your License Key to activate",
      "common.selectFolder": "📂 Select Folder",
      "common.folderSelected": "📁 Selected",
      "common.addToRef": "Add to Reference",
      "common.adding": "Adding...",
      "common.confirmDelete": "Delete",
      "common.historyLabel": "History",
      "common.localFolder": "Local Folder",
      "common.done": "Done",
      "common.selectImage": "Select Image",
      "common.taskFailed": "Task Failed",
      "common.taskTimeout": "Task Timeout",
      // Model names
      "model.放大图片": "Upscale Image",
      "model.移除图片": "Remove Image",
      "model.Seed Face 2K": "Seed Face 2K",
      "model.Seed Face 4K": "Seed Face 4K",
      "model.面部形象修复": "Face Restore",
      "model.Klein4K清晰": "Klein4K Clear",
      "model.Z-image动漫放大": "Anime Upscale",
      "model.Seedream 5.0": "Seedream 5.0",
      // Errors / API
      "error.enterPrompt": "Please enter a prompt",
      "error.allFailed": "All images failed to download",
      "error.generateFailed": "Failed to generate image",
      "error.noImage": "No image returned from API",
      "error.unknown": "An unknown error occurred",
      "error.modeNotSupported": "Mode not supported yet"
    }
  };
  const t = (key, vars) => {
    const lang = getLanguage();
    let text = translations[lang][key] ?? translations["en"][key] ?? key;
    return text;
  };
  const MODES = [
    "Inpainting",
    "Edit Image",
    "Upscale Image",
    "Remove Background",
    "Text2Image"
  ];
  const MODE_MODELS = {
    "Inpainting": ["OneRemoval", "Outpainting"],
    "Edit Image": ["Gpt-image-2", "Nano Banana", "Seedream 5.0", "Qwen", "Flux-Klenin", "OneRemoval", "Outpainting"],
    "Upscale Image": ["Seed Face 2K", "Seed Face 4K", "面部形象修复", "Klein4K清晰", "Z-image动漫放大"],
    "Remove Background": ["Universal", "Targeted"],
    "Text2Image": ["Z-Image Base", "GPT-2 Text-to-Image", "Nano Banana", "Seedream 5.0", "Anima"]
  };
  const INPAINTING_MODELS = ["OneRemoval", "Outpainting"];
  const isInpaintingModel = (modelLabel) => INPAINTING_MODELS.includes(modelLabel);
  const getFolderName = (modeIndex, modelLabel) => {
    if (isInpaintingModel(modelLabel)) return "inpainting";
    const folderMap = {
      0: "inpainting",
      1: "edit-image",
      2: "upscale-image",
      3: "remove-background",
      4: "generate"
    };
    return folderMap[modeIndex] || "generate";
  };
  const arrayBufferToBase64 = (buffer) => {
    const bytes = new Uint8Array(buffer);
    const CHUNK_SIZE = 32768;
    let binary = "";
    for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
      const chunk = bytes.subarray(i, i + CHUNK_SIZE);
      binary += String.fromCharCode.apply(null, chunk);
    }
    return btoa(binary);
  };
  const useGeneration = () => {
    reactExports.useEffect(() => {
      initializeErrorHandling();
      HistoryManager.initializeFolders().catch((err) => {
        console.error("[useGeneration] Failed to initialize folders:", err);
      });
    }, []);
    const [modeIndex, setModeIndex] = reactExports.useState(0);
    const [modelIndexMap, setModelIndexMap] = reactExports.useState({});
    const [prompt, setPrompt] = reactExports.useState("");
    const [isGenerating, setIsGenerating] = reactExports.useState(false);
    const [error, setError] = reactExports.useState(null);
    const [success, setSuccess] = reactExports.useState(null);
    const [progress, setProgress] = reactExports.useState(0);
    const [isProgressVisible, setIsProgressVisible] = reactExports.useState(false);
    const [uploadedImageUrl, setUploadedImageUrl] = reactExports.useState(null);
    const [generatedItems, setGeneratedItems] = reactExports.useState([]);
    const [aspectRatioMap, setAspectRatioMap] = reactExports.useState({
      1: ASPECT_RATIOS[15].value,
      // Edit Image 默认 original
      4: ASPECT_RATIOS[0].value
      // Text2Image 默认 1:1
    });
    const aspectRatio = aspectRatioMap[modeIndex] ?? ASPECT_RATIOS[0].value;
    const [seed, setSeed] = reactExports.useState(Math.floor(Math.random() * 1e12));
    const [seedMode, setSeedMode] = reactExports.useState("randomize");
    const [batchSize, setBatchSize] = reactExports.useState(1);
    const [lora, setLora] = reactExports.useState("无");
    const [referenceImages, setReferenceImages] = reactExports.useState([]);
    const [isTranslating, setIsTranslating] = reactExports.useState(false);
    const [promptHistory, setPromptHistory] = reactExports.useState([]);
    const [historyIndex, setHistoryIndex] = reactExports.useState(-1);
    const abortControllerRef = reactExports.useRef(null);
    const progressAnimationRef = reactExports.useRef(null);
    const successTimerRef = reactExports.useRef(null);
    const isGeneratingRef = reactExports.useRef(false);
    const referenceImagesRef = reactExports.useRef([]);
    const currentMode = MODES[modeIndex];
    const models = reactExports.useMemo(() => {
      return [...MODE_MODELS[currentMode]];
    }, [currentMode]);
    const modelIndex = modelIndexMap[modeIndex] ?? 0;
    const modelLabel = models[modelIndex] ?? models[0] ?? "";
    reactExports.useEffect(() => {
      return () => {
        if (progressAnimationRef.current) {
          cancelAnimationFrame(progressAnimationRef.current);
        }
        if (successTimerRef.current) {
          clearTimeout(successTimerRef.current);
        }
      };
    }, []);
    const startProgressAnimation = reactExports.useCallback(() => {
      setIsProgressVisible(true);
      setProgress(0);
      const initialProgress = 5 + Math.random() * 5;
      setProgress(initialProgress);
      const duration = 1e4 + Math.random() * 5e3;
      const startTime = Date.now();
      const startProgress = initialProgress;
      const targetProgress = 90;
      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progressRatio = Math.min(elapsed / duration, 1);
        const currentProgress = startProgress + (targetProgress - startProgress) * progressRatio;
        setProgress(currentProgress);
        if (progressRatio < 1) {
          progressAnimationRef.current = requestAnimationFrame(animate);
        }
      };
      progressAnimationRef.current = requestAnimationFrame(animate);
    }, []);
    const stopProgressAnimation = reactExports.useCallback((complete = false) => {
      if (progressAnimationRef.current) {
        cancelAnimationFrame(progressAnimationRef.current);
        progressAnimationRef.current = null;
      }
      if (complete) {
        setProgress(100);
        setTimeout(() => {
          setIsProgressVisible(false);
          setProgress(0);
        }, 300);
      } else {
        setIsProgressVisible(false);
        setProgress(0);
      }
    }, []);
    const showSuccess = reactExports.useCallback((message) => {
      setSuccess(message);
      if (successTimerRef.current) {
        clearTimeout(successTimerRef.current);
      }
      successTimerRef.current = window.setTimeout(() => {
        setSuccess(null);
        successTimerRef.current = null;
      }, 2e3);
    }, []);
    const setModelIndex = reactExports.useCallback((index) => {
      setModelIndexMap((prevMap) => {
        const current = prevMap[modeIndex] ?? 0;
        const next = typeof index === "function" ? index(current) : index;
        const newModelLabel = MODE_MODELS[currentMode][next];
        if (currentMode === "Edit Image" && newModelLabel === "Flux-Klenin") {
          setLora("none");
        } else {
          setLora(newModelLabel === "Anima" ? "none" : "无");
        }
        return { ...prevMap, [modeIndex]: next };
      });
    }, [modeIndex, currentMode]);
    const prevModel = reactExports.useCallback(() => {
      setModelIndex(
        (current) => models.length === 0 ? 0 : (current - 1 + models.length) % models.length
      );
    }, [models, setModelIndex]);
    const nextModel = reactExports.useCallback(() => {
      setModelIndex(
        (current) => models.length === 0 ? 0 : (current + 1) % models.length
      );
    }, [models, setModelIndex]);
    const nextMode = reactExports.useCallback(() => {
      setModeIndex((v) => (v + 1) % MODES.length);
    }, []);
    const addReferenceImages = reactExports.useCallback((newImages) => {
      setReferenceImages((prev) => {
        const combined = [...prev, ...newImages];
        const next = combined.slice(0, 5);
        referenceImagesRef.current = next;
        return next;
      });
    }, []);
    const removeReferenceImage = reactExports.useCallback((id) => {
      setReferenceImages((prev) => {
        const next = prev.filter((img) => img.id !== id);
        referenceImagesRef.current = next;
        return next;
      });
    }, []);
    const clearReferenceImages = reactExports.useCallback(() => {
      setReferenceImages([]);
      referenceImagesRef.current = [];
    }, []);
    const captureCanvasAsReference = reactExports.useCallback(async () => {
      try {
        const imageData = await captureCanvasUsingImagingAPI();
        const base64 = arrayBufferToBase64(imageData);
        const dataUrl = `data:image/jpeg;base64,${base64}`;
        const uploadedImage = {
          id: `canvas_${Date.now()}`,
          dataUrl,
          buffer: imageData,
          name: "画布截图"
        };
        addReferenceImages([uploadedImage]);
      } catch (err) {
        console.error("[useGeneration] 自动抓取画布失败:", err);
      }
    }, [addReferenceImages]);
    const handleTranslate = reactExports.useCallback(async () => {
      if (!prompt.trim() || isTranslating) return;
      setIsTranslating(true);
      try {
        const result = await translatePrompt(prompt.trim());
        if (result.success && result.translated) {
          setPrompt(result.translated);
          console.log("[useGeneration] 翻译成功:", result.translated);
        } else {
          console.error("[useGeneration] 翻译失败:", result.error);
        }
      } catch (err) {
        console.error("[useGeneration] 翻译出错:", err);
      } finally {
        setIsTranslating(false);
      }
    }, [prompt, isTranslating]);
    const prevPromptHistory = reactExports.useCallback(() => {
      setPromptHistory((prev) => {
        if (prev.length === 0) return prev;
        setHistoryIndex((current) => {
          const next = current < 0 ? 0 : Math.min(current + 1, prev.length - 1);
          setPrompt(prev[next] || "");
          return next;
        });
        return prev;
      });
    }, []);
    const nextPromptHistory = reactExports.useCallback(() => {
      setPromptHistory((prev) => {
        if (prev.length === 0) return prev;
        setHistoryIndex((current) => {
          const next = current <= 0 ? -1 : current - 1;
          if (next >= 0) {
            setPrompt(prev[next] || "");
          }
          return next;
        });
        return prev;
      });
    }, []);
    const handleGenerate = reactExports.useCallback(async (overrideModelLabel) => {
      var _a2;
      console.log("[useGeneration] handleGenerate called, isGenerating:", isGeneratingRef.current);
      if (isGeneratingRef.current) {
        console.log("[useGeneration] Cancelling generation");
        (_a2 = abortControllerRef.current) == null ? void 0 : _a2.abort();
        return;
      }
      const effectiveModelLabel = overrideModelLabel || modelLabel;
      const needsPrompt = currentMode !== "Upscale Image" && !(currentMode === "Remove Background" && effectiveModelLabel === "Universal");
      console.log("[useGeneration] needsPrompt:", needsPrompt, "prompt:", prompt.trim(), "currentMode:", currentMode);
      if (needsPrompt && !prompt.trim()) {
        console.log("[useGeneration] Prompt empty, returning");
        setError(t("error.enterPrompt"));
        return;
      }
      console.log("[useGeneration] Starting generation...");
      isGeneratingRef.current = true;
      setIsGenerating(true);
      setError(null);
      setSuccess(null);
      abortControllerRef.current = new AbortController();
      startProgressAnimation();
      try {
        let response;
        let dimensions;
        console.log("[useGeneration] currentMode branch:", currentMode);
        if (currentMode === "Edit Image") {
          dimensions = await getTargetDimensions();
          if (isInpaintingModel(effectiveModelLabel)) {
            const sourceImageData = await captureCanvasUsingImagingAPI();
            const maskResult = await exportMaskFromSelection();
            const maskImageData = maskResult.maskData;
            const selectionBounds = maskResult.bounds;
            const urls = await uploadInpaintingImages(sourceImageData, maskImageData);
            setUploadedImageUrl(urls.sourceUrl);
            const longestSide = Math.max(dimensions.width, dimensions.height);
            response = await generateImage({
              prompt: prompt.trim(),
              width: dimensions.width,
              height: dimensions.height,
              signal: abortControllerRef.current.signal,
              model: effectiveModelLabel,
              imageUrl: urls.sourceUrl,
              maskImageUrl: urls.maskUrl,
              longestSide
            });
            response.selectionBounds = selectionBounds;
          } else {
            let uploadedUrls = [];
            if (referenceImagesRef.current.length > 0) {
              const uploadPromises = referenceImagesRef.current.map((img) => uploadImageToBizyAir(img.buffer));
              uploadedUrls = await Promise.all(uploadPromises);
            } else {
              const imageData = await captureCanvasUsingImagingAPI();
              const uploadedUrl = await uploadImageToBizyAir(imageData);
              uploadedUrls = [uploadedUrl];
            }
            setUploadedImageUrl(uploadedUrls[0]);
            const isKeinCharacterEdit = effectiveModelLabel === "Flux-Klenin" && lora === "Klein角色编辑";
            if (effectiveModelLabel === "Nano Banana" || effectiveModelLabel === "Gpt-image-2" || effectiveModelLabel === "Seedream 5.0" || isKeinCharacterEdit) {
              response = await editImage({
                prompt: prompt.trim(),
                width: dimensions.width,
                height: dimensions.height,
                signal: abortControllerRef.current.signal,
                editModel: isKeinCharacterEdit ? "Kein角色编辑" : effectiveModelLabel,
                imageUrls: uploadedUrls,
                aspectRatio
              });
            } else {
              response = await editImage({
                prompt: prompt.trim(),
                width: dimensions.width,
                height: dimensions.height,
                signal: abortControllerRef.current.signal,
                editModel: effectiveModelLabel,
                imageUrl: uploadedUrls[0],
                aspectRatio
              });
            }
          }
        } else if (currentMode === "Upscale Image") {
          dimensions = await getTargetDimensions();
          const imageData = await captureCanvasUsingImagingAPI();
          const uploadedUrl = await uploadImageToBizyAir(imageData);
          setUploadedImageUrl(uploadedUrl);
          response = await upscaleImage({
            width: dimensions.width,
            height: dimensions.height,
            signal: abortControllerRef.current.signal,
            upscaleModel: effectiveModelLabel,
            imageUrl: uploadedUrl
          });
        } else if (currentMode === "Remove Background") {
          dimensions = await getTargetDimensions();
          const imageData = await captureCanvasUsingImagingAPI();
          const uploadedUrl = await uploadImageToBizyAir(imageData);
          setUploadedImageUrl(uploadedUrl);
          response = await removeBackground({
            prompt: prompt.trim(),
            width: dimensions.width,
            height: dimensions.height,
            signal: abortControllerRef.current.signal,
            removeBackgroundModel: effectiveModelLabel,
            imageUrl: uploadedUrl
          });
        } else if (currentMode === "Text2Image") {
          if (aspectRatio === "original") {
            dimensions = await getTargetDimensions().catch(() => ({ width: 1024, height: 1024 }));
          } else {
            const ratio = ASPECT_RATIOS.find((r) => r.value === aspectRatio);
            dimensions = { width: (ratio == null ? void 0 : ratio.width) || 1024, height: (ratio == null ? void 0 : ratio.height) || 1024 };
          }
          response = await generateImage({
            prompt: prompt.trim(),
            width: dimensions.width,
            height: dimensions.height,
            signal: abortControllerRef.current.signal,
            model: effectiveModelLabel,
            aspectRatio,
            seed,
            seedMode,
            batchSize,
            lora
          });
        } else {
          throw new Error(t("error.modeNotSupported"));
        }
        if (!response.success || !response.data) {
          throw new Error(response.error || t("error.generateFailed"));
        }
        const imageUrls = response.urls && response.urls.length > 0 ? response.urls : response.data ? [response.data] : [];
        if (imageUrls.length === 0) {
          throw new Error(t("error.noImage"));
        }
        const folderName = getFolderName(modeIndex, effectiveModelLabel);
        const newItems = [];
        for (let i = 0; i < imageUrls.length; i++) {
          const url = imageUrls[i];
          let dataUrl = url;
          let sessionToken = void 0;
          let savedPath = void 0;
          try {
            if (url.startsWith("http://") || url.startsWith("https://")) {
              const processResult = await downloadAndProcessImage(
                url,
                void 0,
                prompt.trim(),
                folderName
              );
              dataUrl = processResult.displayUrl;
              sessionToken = processResult.sessionToken;
              savedPath = processResult.localPath;
            }
            const item = {
              id: `${Date.now()}_${i}_${Math.random().toString(16).slice(2)}`,
              dataUrl,
              prompt: prompt.trim(),
              width: dimensions == null ? void 0 : dimensions.width,
              height: dimensions == null ? void 0 : dimensions.height,
              createdAt: Date.now(),
              source: "generate",
              selectionBounds: response.selectionBounds,
              sessionToken,
              savedPath,
              isTokenReady: true,
              isPixelsReady: true
            };
            newItems.push(item);
            eventBus.emit(GalleryEventType.IMAGE_GENERATED, {
              dataUrl,
              prompt: prompt.trim(),
              width: dimensions == null ? void 0 : dimensions.width,
              height: dimensions == null ? void 0 : dimensions.height,
              createdAt: Date.now(),
              selectionBounds: response.selectionBounds,
              sessionToken,
              savedPath
            });
          } catch (err) {
            console.error(`[useGeneration] Failed to process image ${i + 1}/${imageUrls.length}:`, err);
          }
        }
        if (newItems.length > 0) {
          setGeneratedItems(newItems);
        } else {
          throw new Error(t("error.allFailed"));
        }
        const trimmedPrompt = prompt.trim();
        if (trimmedPrompt) {
          setPromptHistory((prev) => {
            const filtered = prev.filter((p) => p !== trimmedPrompt);
            const next = [trimmedPrompt, ...filtered].slice(0, 10);
            return next;
          });
          setHistoryIndex(0);
        }
        if (currentMode === "Text2Image") {
          if (seedMode === "increment") {
            setSeed((s) => s + 1);
          } else if (seedMode === "decrement") {
            setSeed((s) => s - 1);
          } else if (seedMode === "randomize") {
            setSeed(Math.floor(Math.random() * 1e12));
          }
        }
        showSuccess(t("common.addSuccess"));
        stopProgressAnimation(true);
      } catch (err) {
        console.error("[useGeneration] Generation error:", err);
        if (err instanceof Error && err.name === "AbortError") {
          setError(null);
        } else {
          const errorMessage = err instanceof Error ? err.message : t("error.unknown");
          setError(errorMessage);
          errorCollector.collectError(err, {
            userActionPath: ["Generate", "API call failed"]
          });
        }
        stopProgressAnimation(false);
      } finally {
        isGeneratingRef.current = false;
        setIsGenerating(false);
        abortControllerRef.current = null;
      }
    }, [
      currentMode,
      modelLabel,
      prompt,
      modeIndex,
      aspectRatio,
      seed,
      seedMode,
      batchSize,
      lora,
      showSuccess,
      startProgressAnimation,
      stopProgressAnimation
    ]);
    return {
      // State
      modeIndex,
      modelIndex,
      prompt,
      isGenerating,
      error,
      success,
      progress,
      isProgressVisible,
      uploadedImageUrl,
      aspectRatio,
      seed,
      seedMode,
      batchSize,
      lora,
      referenceImages,
      isTranslating,
      promptHistory,
      historyIndex,
      // Setters
      setModeIndex,
      setModelIndex,
      setPrompt,
      setError,
      setSuccess,
      setAspectRatio: reactExports.useCallback((value) => {
        setAspectRatioMap((prev) => ({ ...prev, [modeIndex]: value }));
      }, [modeIndex]),
      setSeed,
      setSeedMode,
      setBatchSize,
      setLora,
      addReferenceImages,
      removeReferenceImage,
      clearReferenceImages,
      captureCanvasAsReference,
      // Derived
      currentMode,
      models,
      modelLabel,
      MODES,
      // Generated items
      generatedItems,
      clearGeneratedItems: () => setGeneratedItems([]),
      addGeneratedItem: (item) => setGeneratedItems([item]),
      // Actions
      prevModel,
      nextModel,
      nextMode,
      handleGenerate,
      handleTranslate,
      prevPromptHistory,
      nextPromptHistory
    };
  };
  const UxPActionButton$2 = ({
    onClick,
    disabled,
    quiet,
    title,
    className,
    children
  }) => {
    const ref = reactExports.useRef(null);
    const onClickRef = reactExports.useRef(onClick);
    const disabledRef = reactExports.useRef(disabled);
    onClickRef.current = onClick;
    disabledRef.current = disabled;
    reactExports.useEffect(() => {
      var _a2;
      const btn = (_a2 = ref.current) == null ? void 0 : _a2.querySelector("sp-action-button");
      if (!btn) return;
      const handler = (e) => {
        var _a3, _b2, _c2;
        if (disabledRef.current) return;
        (_a3 = e.preventDefault) == null ? void 0 : _a3.call(e);
        (_b2 = e.stopPropagation) == null ? void 0 : _b2.call(e);
        (_c2 = onClickRef.current) == null ? void 0 : _c2.call(onClickRef);
        if (typeof btn.blur === "function") {
          setTimeout(() => btn.blur(), 0);
        }
      };
      btn.addEventListener("click", handler);
      return () => btn.removeEventListener("click", handler);
    }, []);
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "sp-action-button",
      {
        class: className || "",
        quiet,
        title,
        disabled: disabled ? true : void 0,
        children
      }
    ) });
  };
  const useUxPPicker = (onChange) => {
    const ref = reactExports.useRef(null);
    const onChangeRef = reactExports.useRef(onChange);
    onChangeRef.current = onChange;
    reactExports.useEffect(() => {
      var _a2;
      const picker = (_a2 = ref.current) == null ? void 0 : _a2.querySelector("sp-picker");
      if (!picker) return;
      const handler = (e) => {
        var _a3, _b2;
        const value = (_a3 = e.target) == null ? void 0 : _a3.value;
        (_b2 = onChangeRef.current) == null ? void 0 : _b2.call(onChangeRef, value);
      };
      picker.addEventListener("change", handler);
      return () => picker.removeEventListener("change", handler);
    }, []);
    return ref;
  };
  const useUxPSlider = (onChange) => {
    const ref = reactExports.useRef(null);
    const onChangeRef = reactExports.useRef(onChange);
    onChangeRef.current = onChange;
    reactExports.useEffect(() => {
      var _a2;
      const slider = (_a2 = ref.current) == null ? void 0 : _a2.querySelector("sp-slider");
      if (!slider) return;
      const handler = (e) => {
        var _a3;
        (_a3 = onChangeRef.current) == null ? void 0 : _a3.call(onChangeRef, Number(e.target.value));
      };
      slider.addEventListener("input", handler);
      return () => slider.removeEventListener("input", handler);
    }, []);
    return ref;
  };
  const GenerationControl = React.memo(
    (props) => {
      const {
        modeIndex,
        modelIndex = 0,
        modelLabel,
        models,
        prompt,
        isGenerating,
        error,
        success,
        progress,
        isProgressVisible,
        preview,
        showParams = true,
        showPrompt = true,
        buttonLabel = "Generate",
        temperature,
        onTemperatureChange,
        allowInterrupt = false,
        aspectRatio = ASPECT_RATIOS[0].value,
        onAspectRatioChange,
        showAspectRatio = true,
        lora = "无",
        onLoraChange,
        seed,
        seedMode = "randomize",
        onSeedModeChange,
        onSeedChange,
        batchSize = 1,
        onBatchSizeChange,
        showSeedBatch = true,
        onPromptChange,
        onGenerate,
        onPrevModel,
        onNextModel,
        onModelIndexChange,
        onClearError,
        onClearSuccess,
        imageUploader,
        isTranslating = false,
        onTranslate,
        promptHistory = [],
        historyIndex = -1,
        onPrevPromptHistory,
        onNextPromptHistory,
        onRandomizeSeed
      } = props;
      const maxLength = 1e3;
      const modelPickerRef = useUxPPicker((value) => {
        const targetIndex = models.indexOf(value);
        if (targetIndex !== -1 && onModelIndexChange) {
          onModelIndexChange(targetIndex);
        }
      });
      const aspectRatioRef = useUxPPicker(onAspectRatioChange);
      const loraRef = useUxPPicker(onLoraChange);
      const batchRef = useUxPPicker((value) => onBatchSizeChange == null ? void 0 : onBatchSizeChange(Number(value)));
      const sliderRef = useUxPSlider(onTemperatureChange);
      const handlePromptInput = (e) => {
        onPromptChange(e.target.value);
      };
      const handleKeyDown = (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          onGenerate();
        }
      };
      const handleSeedDecrement = () => {
        if (seed !== void 0) {
          onSeedChange == null ? void 0 : onSeedChange(seed - 1);
          onSeedModeChange == null ? void 0 : onSeedModeChange("fixed");
        }
      };
      const handleSeedIncrement = () => {
        if (seed !== void 0) {
          onSeedChange == null ? void 0 : onSeedChange(seed + 1);
          onSeedModeChange == null ? void 0 : onSeedModeChange("fixed");
        }
      };
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "generation-control", children: [
        isProgressVisible && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "gc-progress-wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "sp-progressbar",
          {
            value: Math.round(progress),
            max: 100,
            class: "gc-progress"
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-section", ref: modelPickerRef, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("sp-label", { children: [
            t("generation.selectModel"),
            ": ",
            modelLabel
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-picker", { class: "gc-fullwidth", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-menu", { children: models.map((model, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "sp-menu-item",
            {
              value: model,
              selected: i === modelIndex ? true : void 0,
              children: (() => {
                const translated = t(`model.${model}`);
                return translated === `model.${model}` ? model : translated;
              })()
            },
            model
          )) }) })
        ] }),
        showParams && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-row", children: [
          showAspectRatio && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-col", ref: aspectRatioRef, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("generation.aspectRatio") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-picker", { class: "gc-fullwidth", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-menu", { children: ASPECT_RATIOS.map((ratio) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "sp-menu-item",
              {
                value: ratio.value,
                selected: aspectRatio === ratio.value ? true : void 0,
                children: ratio.label
              },
              ratio.value
            )) }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-col", ref: loraRef, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("generation.lora") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-picker", { class: "gc-fullwidth", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-menu", { children: modeIndex === 1 && modelLabel === "Flux-Klenin" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "sp-menu-item",
                {
                  value: "none",
                  selected: lora === "none" ? true : void 0,
                  children: t("generation.loraNoneEn")
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "sp-menu-item",
                {
                  value: "Klein角色编辑",
                  selected: lora === "Klein角色编辑" ? true : void 0,
                  children: t("generation.loraKlein")
                }
              )
            ] }) : modelLabel === "Anima" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "sp-menu-item",
                {
                  value: "none",
                  selected: lora === "none" ? true : void 0,
                  children: t("generation.loraNone")
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "sp-menu-item",
                {
                  value: "trubo",
                  selected: lora === "trubo" ? true : void 0,
                  children: t("generation.loraTurbo")
                }
              )
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
              "sp-menu-item",
              {
                value: "无",
                selected: lora === "无" ? true : void 0,
                children: t("generation.loraNone")
              }
            ) }) })
          ] })
        ] }),
        showParams && showSeedBatch && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-col", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("generation.seed") }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-seed-control", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                UxPActionButton$2,
                {
                  quiet: true,
                  onClick: handleSeedDecrement,
                  disabled: isGenerating || seed === void 0,
                  className: "gc-stepper-btn",
                  children: "−"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "S", class: "gc-seed-value", children: seed !== void 0 ? seed : "-" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                UxPActionButton$2,
                {
                  quiet: true,
                  onClick: handleSeedIncrement,
                  disabled: isGenerating || seed === void 0,
                  className: "gc-stepper-btn",
                  children: "+"
                }
              ),
              onRandomizeSeed && /* @__PURE__ */ jsxRuntimeExports.jsx(
                UxPActionButton$2,
                {
                  quiet: true,
                  onClick: onRandomizeSeed,
                  disabled: isGenerating,
                  title: t("generation.randomSeed"),
                  className: "gc-seed-random",
                  children: "🎲"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-col", ref: batchRef, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("generation.batchSize") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-picker", { class: "gc-fullwidth", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-menu", { children: [1, 2, 3, 4].map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "sp-menu-item",
              {
                value: String(n),
                selected: batchSize === n ? true : void 0,
                children: n
              },
              n
            )) }) })
          ] })
        ] }),
        showPrompt && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-section", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-prompt-header", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-prompt-title-wrap", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("generation.prompt") }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("sp-body", { size: "XS", class: "gc-prompt-counter", children: [
                prompt.length,
                "/",
                maxLength
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-prompt-actions", children: [
              onTranslate && /* @__PURE__ */ jsxRuntimeExports.jsx(
                UxPActionButton$2,
                {
                  quiet: true,
                  onClick: onTranslate,
                  disabled: isTranslating || !prompt.trim() || isGenerating,
                  title: t("generation.translate"),
                  className: "gc-translate-btn",
                  children: isTranslating ? "..." : "A"
                }
              ),
              promptHistory.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-history-group", children: [
                onPrevPromptHistory && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  UxPActionButton$2,
                  {
                    quiet: true,
                    onClick: onPrevPromptHistory,
                    disabled: historyIndex >= promptHistory.length - 1,
                    title: t("generation.prevHistory"),
                    children: "‹"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("sp-body", { size: "S", children: [
                  historyIndex >= 0 ? historyIndex + 1 : 0,
                  " /",
                  " ",
                  promptHistory.length
                ] }),
                onNextPromptHistory && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  UxPActionButton$2,
                  {
                    quiet: true,
                    onClick: onNextPromptHistory,
                    disabled: historyIndex <= 0,
                    title: t("generation.nextHistory"),
                    children: "›"
                  }
                )
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "sp-textarea",
            {
              class: "gc-prompt-textarea",
              placeholder: t("generation.promptPlaceholder"),
              value: prompt,
              onInput: handlePromptInput,
              onKeyDown: handleKeyDown,
              disabled: isGenerating ? true : void 0
            }
          )
        ] }),
        onTemperatureChange !== void 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-section", ref: sliderRef, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-slider-header", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("generation.redrawStrength") }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("sp-body", { size: "S", children: [
              temperature,
              "%"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "sp-slider",
            {
              min: 0,
              max: 100,
              value: temperature ?? 50,
              class: "gc-slider"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-slider-labels", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "XS", children: t("generation.conservative") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "XS", children: t("generation.moderate") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "XS", children: t("generation.aggressive") })
          ] })
        ] }),
        imageUploader,
        preview && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-section", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("generation.output") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "gc-preview-container", children: preview })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "sp-button",
          {
            variant: "cta",
            class: `gc-generate-btn ${isGenerating ? "gc-generating" : ""}`,
            onClick: onGenerate,
            children: isGenerating ? t("generation.cancel") : buttonLabel === "Generate" ? t("generation.generate") : buttonLabel
          }
        ),
        error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-alert gc-alert-error", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "S", children: error }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "sp-button",
            {
              class: "gc-alert-close",
              quiet: true,
              onClick: onClearError,
              children: "✕"
            }
          )
        ] }),
        success && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-alert gc-alert-success", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "S", children: success }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "sp-button",
            {
              class: "gc-alert-close",
              quiet: true,
              onClick: onClearSuccess,
              children: "✕"
            }
          )
        ] })
      ] });
    }
  );
  function createThumbnail(dataUrl, maxSize = 160) {
    return new Promise((resolve) => {
      const img = new Image();
      const timeout = setTimeout(() => {
        console.warn("[Thumbnail] Image load timeout, fallback to original");
        resolve(dataUrl);
      }, 3e3);
      img.onload = () => {
        clearTimeout(timeout);
        try {
          const canvas = document.createElement("canvas");
          const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
          canvas.width = Math.round(img.width * scale);
          canvas.height = Math.round(img.height * scale);
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            resolve(dataUrl);
            return;
          }
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const thumb = canvas.toDataURL("image/png");
          if (!thumb || thumb === "data:image/png;base64,") {
            resolve(dataUrl);
            return;
          }
          resolve(thumb);
        } catch {
          resolve(dataUrl);
        }
      };
      img.onerror = () => {
        clearTimeout(timeout);
        resolve(dataUrl);
      };
      img.src = dataUrl;
    });
  }
  const generateId$1 = () => `${Date.now()}_${Math.random().toString(16).slice(2, 8)}`;
  const getMimeType = (fileName) => {
    var _a2;
    const ext = (_a2 = fileName.split(".").pop()) == null ? void 0 : _a2.toLowerCase();
    switch (ext) {
      case "jpg":
      case "jpeg":
        return "image/jpeg";
      case "png":
        return "image/png";
      case "webp":
        return "image/webp";
      default:
        return "image/png";
    }
  };
  const arrayBufferToBlobUrl = (buffer, mimeType) => {
    return URL.createObjectURL(new Blob([buffer], { type: mimeType }));
  };
  const ImageThumb = React.memo(({ id, dataUrl, thumbnailUrl: propThumb, onRemove }) => {
    const [lazyThumb, setLazyThumb] = reactExports.useState(propThumb);
    const generatedRef = reactExports.useRef(false);
    reactExports.useEffect(() => {
      if (propThumb || lazyThumb || generatedRef.current) return;
      generatedRef.current = true;
      let cancelled = false;
      createThumbnail(dataUrl, 64).then((url) => {
        if (!cancelled) setLazyThumb(url);
      });
      return () => {
        cancelled = true;
      };
    }, [dataUrl, propThumb, lazyThumb]);
    const handleRemove = reactExports.useCallback(() => {
      if (dataUrl == null ? void 0 : dataUrl.startsWith("blob:")) {
        URL.revokeObjectURL(dataUrl);
      }
      if (lazyThumb == null ? void 0 : lazyThumb.startsWith("blob:")) {
        URL.revokeObjectURL(lazyThumb);
      }
      onRemove(id);
    }, [id, dataUrl, lazyThumb, onRemove]);
    const displayUrl = lazyThumb || propThumb || dataUrl;
    const style = reactExports.useMemo(() => ({ backgroundImage: `url(${displayUrl})` }), [displayUrl]);
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "iu-thumb-wrapper", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "iu-thumb", style }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "iu-remove", onClick: handleRemove, title: t("uploader.delete"), children: "✕" })
    ] });
  });
  const ImageUploader = React.memo(({
    images,
    maxCount = 5,
    onAdd,
    onRemove,
    disabled = false
  }) => {
    const isFull = images.length >= maxCount;
    const handleUpload = reactExports.useCallback(async () => {
      if (isFull || disabled) return;
      try {
        const { localFileSystem: localFileSystem2, formats: formats2 } = require("uxp").storage;
        const entries = await localFileSystem2.getFileForOpening({
          allowMultiple: true,
          types: ["png", "jpg", "jpeg", "webp"]
        });
        if (!entries) return;
        const files = Array.isArray(entries) ? entries : [entries];
        if (files.length === 0) return;
        const slotsLeft = maxCount - images.length;
        const filesToProcess = files.slice(0, slotsLeft);
        const buffers = await Promise.all(
          filesToProcess.map((file) => file.read({ format: formats2.binary }))
        );
        const newImages = filesToProcess.map((file, i) => {
          const buffer = buffers[i];
          const mimeType = getMimeType(file.name || "image.png");
          const blobUrl = arrayBufferToBlobUrl(buffer, mimeType);
          return {
            id: generateId$1(),
            dataUrl: blobUrl,
            buffer,
            name: file.name || "unknown"
          };
        });
        if (newImages.length > 0) {
          onAdd(newImages);
        }
      } catch (err) {
        console.error("[ImageUploader] 文件选择失败:", err);
      }
    }, [isFull, disabled, images.length, maxCount, onAdd]);
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "image-uploader", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "iu-header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("uploader.referenceImage") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "iu-counter", children: [
          images.length,
          "/",
          maxCount
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "iu-list", children: [
        images.map((img) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          ImageThumb,
          {
            id: img.id,
            dataUrl: img.dataUrl,
            thumbnailUrl: img.thumbnailUrl,
            onRemove
          },
          img.id
        )),
        !isFull && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: `iu-add-btn ${disabled ? "iu-add-btn-disabled" : ""}`,
            onClick: handleUpload,
            title: t("uploader.uploadImage"),
            children: "+"
          }
        )
      ] })
    ] });
  });
  const openURL = async (url) => {
    console.log("[UXP] openExternal:", url);
    try {
      await uxp.shell.openExternal(url);
    } catch (err) {
      console.error("[UXP] openExternal failed:", (err == null ? void 0 : err.message) || err);
      if (typeof window !== "undefined") {
        window.open(url, "_blank");
      }
    }
  };
  const UxPActionButton$1 = ({ onClick, disabled, quiet, className, children }) => {
    const ref = reactExports.useRef(null);
    const onClickRef = reactExports.useRef(onClick);
    const disabledRef = reactExports.useRef(disabled);
    onClickRef.current = onClick;
    disabledRef.current = disabled;
    reactExports.useEffect(() => {
      var _a2;
      const btn = (_a2 = ref.current) == null ? void 0 : _a2.querySelector("sp-action-button");
      if (!btn) return;
      const handler = (e) => {
        var _a3, _b2, _c2;
        if (disabledRef.current) return;
        (_a3 = e.preventDefault) == null ? void 0 : _a3.call(e);
        (_b2 = e.stopPropagation) == null ? void 0 : _b2.call(e);
        (_c2 = onClickRef.current) == null ? void 0 : _c2.call(onClickRef);
        if (typeof btn.blur === "function") {
          setTimeout(() => btn.blur(), 0);
        }
      };
      btn.addEventListener("click", handler);
      return () => btn.removeEventListener("click", handler);
    }, []);
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref, style: { display: "inline-block" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "sp-action-button",
      {
        class: className || "",
        quiet,
        disabled: disabled ? true : void 0,
        children
      }
    ) });
  };
  const UxPTextfield = ({ value, onChange, onKeyDown, placeholder, disabled, type, className }) => {
    const ref = reactExports.useRef(null);
    const onChangeRef = reactExports.useRef(onChange);
    const onKeyDownRef = reactExports.useRef(onKeyDown);
    onChangeRef.current = onChange;
    onKeyDownRef.current = onKeyDown;
    reactExports.useEffect(() => {
      var _a2;
      const input = (_a2 = ref.current) == null ? void 0 : _a2.querySelector("sp-textfield");
      if (!input) return;
      const inputHandler = (e) => {
        var _a3, _b2;
        (_b2 = onChangeRef.current) == null ? void 0 : _b2.call(onChangeRef, ((_a3 = e.target) == null ? void 0 : _a3.value) || "");
      };
      const keydownHandler = (e) => {
        var _a3;
        (_a3 = onKeyDownRef.current) == null ? void 0 : _a3.call(onKeyDownRef, e);
      };
      input.addEventListener("input", inputHandler);
      input.addEventListener("keydown", keydownHandler);
      return () => {
        input.removeEventListener("input", inputHandler);
        input.removeEventListener("keydown", keydownHandler);
      };
    }, []);
    reactExports.useEffect(() => {
      var _a2;
      const input = (_a2 = ref.current) == null ? void 0 : _a2.querySelector("sp-textfield");
      if (input && input.value !== value) {
        input.value = value;
      }
    }, [value]);
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref, style: { display: "flex", flex: 1 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "sp-textfield",
      {
        class: className || "",
        type: type || "text",
        placeholder,
        disabled: disabled ? true : void 0,
        value
      }
    ) });
  };
  const ROUTE_ENTRIES = Object.entries(ROUTE_CONFIG);
  const SUPABASE_URL = "https://fwusxlammxgowaxdubcm.supabase.co";
  const VERIFY_URL = `${SUPABASE_URL}/functions/v1/verify-key`;
  const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ3dXN4bGFtbXhnb3dheGR1YmNtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM3MzUzOTAsImV4cCI6MjA4OTMxMTM5MH0.nRjypOI0SOxqQF3ZbOOZDjGCmHzo0AoYct_QqMvQlpo";
  const TOKEN_KEY = "ps_plugin_token";
  const TOKEN_EXPIRY_KEY = "ps_plugin_token_expiry";
  const BALANCE_KEY = "ps_plugin_balance";
  const LICENSE_KEY = "ps_plugin_license";
  const getAuthState = () => {
    try {
      const token = localStorage.getItem(TOKEN_KEY);
      const expiry = localStorage.getItem(TOKEN_EXPIRY_KEY);
      const balance = localStorage.getItem(BALANCE_KEY);
      const license = localStorage.getItem(LICENSE_KEY);
      if (!token || !expiry) return null;
      if (/* @__PURE__ */ new Date() >= new Date(expiry)) {
        clearAuth();
        return null;
      }
      return {
        isVerified: true,
        licenseKey: license || "",
        balance: parseFloat(balance || "0"),
        expiresAt: expiry
      };
    } catch {
      return null;
    }
  };
  const clearAuth = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(TOKEN_EXPIRY_KEY);
    localStorage.removeItem(BALANCE_KEY);
    localStorage.removeItem(LICENSE_KEY);
  };
  const ProfileCenter = ({ onAuthChange }) => {
    const [licenseInput, setLicenseInput] = reactExports.useState("");
    const [isVerifying, setIsVerifying] = reactExports.useState(false);
    const [error, setError] = reactExports.useState(null);
    const [authState, setAuthState] = reactExports.useState(getAuthState);
    const [latencies, setLatencies] = reactExports.useState({});
    const [selectedRoute, setSelectedRoute] = reactExports.useState(getProxyRoute());
    const [showPassword, setShowPassword] = reactExports.useState(false);
    const langPickerRef = reactExports.useRef(null);
    reactExports.useEffect(() => {
      var _a2;
      const picker = (_a2 = langPickerRef.current) == null ? void 0 : _a2.querySelector("sp-picker");
      if (!picker) return;
      const handler = (e) => {
        var _a3;
        const value = (_a3 = e.target) == null ? void 0 : _a3.value;
        if (value && value !== getLanguage()) {
          setLanguage(value);
          window.location.reload();
        }
      };
      picker.addEventListener("change", handler);
      return () => picker.removeEventListener("change", handler);
    }, []);
    const testLatency = reactExports.useCallback(async (url) => {
      const start = performance.now();
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5e3);
        const res = await fetch(url, { method: "GET", signal: controller.signal });
        clearTimeout(timeout);
        const latency = Math.round(performance.now() - start);
        if (res.ok) {
          return latency;
        }
      } catch (err) {
        console.warn(`[Latency] ${url} → error:`, err.message || err);
      }
      return 0;
    }, []);
    reactExports.useEffect(() => {
      const testAll = async () => {
        const results = {};
        for (const [, config] of ROUTE_ENTRIES) {
          results[config.name] = await testLatency(config.healthUrl);
        }
        setLatencies(results);
      };
      testAll();
      const interval = setInterval(testAll, 1e4);
      return () => clearInterval(interval);
    }, [testLatency]);
    reactExports.useEffect(() => {
      onAuthChange == null ? void 0 : onAuthChange(authState);
    }, [authState, onAuthChange]);
    reactExports.useEffect(() => {
      const interval = setInterval(() => {
        const current = getAuthState();
        if (!current && authState) {
          setAuthState(null);
          setError(t("profile.expired"));
        }
      }, 6e4);
      return () => clearInterval(interval);
    }, [authState]);
    const handleVerify = reactExports.useCallback(async () => {
      const key = licenseInput.trim();
      if (!key) {
        setError(t("profile.enterLicense"));
        return;
      }
      setIsVerifying(true);
      setError(null);
      try {
        const res = await fetch(VERIFY_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
          },
          body: JSON.stringify({
            license_key: key,
            device_info: {
              plugin: "ps",
              os: "win",
              version: "1.0.0"
            }
          })
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || t("profile.verifyFailed"));
        }
        localStorage.setItem(TOKEN_KEY, data.token);
        localStorage.setItem(TOKEN_EXPIRY_KEY, data.expires_at);
        localStorage.setItem(BALANCE_KEY, String(data.balance || 0));
        localStorage.setItem(LICENSE_KEY, data.license_key);
        const newState = {
          isVerified: true,
          licenseKey: data.license_key,
          balance: parseFloat(String(data.balance || 0)),
          expiresAt: data.expires_at
        };
        setAuthState(newState);
        setLicenseInput("");
      } catch (err) {
        setError(err.message || t("profile.verifyError"));
      } finally {
        setIsVerifying(false);
      }
    }, [licenseInput]);
    const handleLogout = reactExports.useCallback(() => {
      clearAuth();
      setAuthState(null);
      setError(null);
    }, []);
    const handleRefreshBalance = reactExports.useCallback(async () => {
      const key = localStorage.getItem(LICENSE_KEY);
      if (!key) {
        setError(t("profile.noLicenseKey"));
        return;
      }
      setIsVerifying(true);
      setError(null);
      try {
        const res = await fetch(VERIFY_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
          },
          body: JSON.stringify({
            license_key: key,
            device_info: { plugin: "ps", os: "win", version: "1.0.0" }
          })
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || t("profile.refreshFailed"));
        }
        localStorage.setItem(TOKEN_KEY, data.token);
        localStorage.setItem(TOKEN_EXPIRY_KEY, data.expires_at);
        localStorage.setItem(BALANCE_KEY, String(data.balance || 0));
        setAuthState(
          (prev) => prev ? {
            ...prev,
            balance: parseFloat(String(data.balance || 0)),
            expiresAt: data.expires_at
          } : null
        );
        const results = {};
        for (const [, config] of ROUTE_ENTRIES) {
          results[config.name] = await testLatency(config.healthUrl);
        }
        setLatencies(results);
      } catch (err) {
        setError(err.message || t("profile.refreshError"));
      } finally {
        setIsVerifying(false);
      }
    }, [testLatency]);
    const maskLicenseKey = (key) => {
      if (key.length <= 12) return key;
      return key.slice(0, 6) + "..." + key.slice(-6);
    };
    const formatExpiry = (dateStr) => {
      try {
        return new Date(dateStr).toLocaleString(getLanguage() === "zh" ? "zh-CN" : "en-US");
      } catch {
        return dateStr;
      }
    };
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-center", children: !(authState == null ? void 0 : authState.isVerified) ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-auth-panel", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "profile-icon", children: "🔑" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "profile-title", children: t("profile.activateTitle") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "profile-desc", children: t("profile.activateDesc") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-input-wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-password-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          UxPTextfield,
          {
            type: showPassword ? "text" : "password",
            className: "profile-input",
            placeholder: t("profile.licensePlaceholder"),
            value: licenseInput,
            onChange: setLicenseInput,
            onKeyDown: (e) => {
              if (e.key === "Enter") handleVerify();
            },
            disabled: isVerifying
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          UxPActionButton$1,
          {
            quiet: true,
            className: "profile-eye-btn",
            onClick: () => setShowPassword((v) => !v),
            children: showPassword ? "🙈" : "👁"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        UxPActionButton$1,
        {
          className: "profile-btn-uxp profile-btn-uxp--primary",
          onClick: handleVerify,
          disabled: isVerifying,
          children: isVerifying ? t("profile.verifying") : t("profile.verifyActivate")
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-footer", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        UxPActionButton$1,
        {
          quiet: true,
          className: "profile-link-btn",
          onClick: () => {
            openURL("https://www.thebigone.top");
          },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "icons/bird.png", width: "16", height: "16", style: { marginRight: 6, verticalAlign: "middle" } }),
            t("profile.visitWebsite")
          ]
        }
      ) }),
      error && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-error", children: error })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-main-panel", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "profile-icon", children: "✅" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "profile-title", children: t("profile.activated") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-section", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-section-header", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "profile-status-icon", children: "✅" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("profile.activated") })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-info-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { class: "profile-info-label", children: "License Key" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { children: maskLicenseKey(authState.licenseKey) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-info-row", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { class: "profile-info-label", children: t("profile.expiresAt") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { children: formatExpiry(authState.expiresAt) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-section", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-section-header", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("profile.balance") }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-balance-row", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("sp-body", { children: [
          "$",
          authState.balance.toFixed(2)
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-actions-row", children: /* @__PURE__ */ jsxRuntimeExports.jsx(UxPActionButton$1, { className: "profile-btn-uxp profile-btn-uxp--primary", onClick: handleRefreshBalance, disabled: isVerifying, children: isVerifying ? t("profile.refreshing") : t("profile.refreshBalance") }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-section", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-section-header", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("profile.routeSelect") }) }),
        ROUTE_ENTRIES.map(([key, config]) => {
          const latency = latencies[config.name] ?? 0;
          const isUnavailable = latency === 0;
          const isHighLatency = latency >= 3e3;
          const isSelected = selectedRoute === key;
          const dotStatus = isUnavailable || isHighLatency ? "red" : "green";
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: `profile-route-item ${isSelected ? "selected" : ""}`,
              onClick: () => {
                setSelectedRoute(key);
                setProxyRoute(key);
              },
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `profile-route-dot ${isSelected ? "filled" : "hollow"} ${dotStatus}` }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "profile-route-name", children: config.name }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `profile-route-latency ${dotStatus}`, children: isUnavailable ? t("profile.timeout") : `${latency}ms` }),
                isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "profile-route-badge", children: t("profile.current") })
              ]
            },
            key
          );
        })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "profile-section", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-section-header", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-label", { children: t("profile.language") }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: langPickerRef, children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-picker", { class: "gc-fullwidth", value: getLanguage(), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("sp-menu", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-menu-item", { value: "zh", selected: getLanguage() === "zh" ? true : void 0, children: t("profile.languageZh") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("sp-menu-item", { value: "en", selected: getLanguage() === "en" ? true : void 0, children: t("profile.languageEn") })
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-link-row", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(UxPActionButton$1, { quiet: true, className: "profile-link-btn", onClick: () => openURL("https://www.thebigone.top"), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "icons/bird.png", width: "16", height: "16", style: { marginRight: 6, verticalAlign: "middle" } }),
          t("profile.visitWebsite")
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "profile-actions-row", children: /* @__PURE__ */ jsxRuntimeExports.jsx(UxPActionButton$1, { className: "profile-btn-uxp profile-btn-uxp--secondary", onClick: handleLogout, children: t("profile.logout") }) })
      ] })
    ] }) });
  };
  const UxPActionButton = ({ onClick, disabled, quiet, selected, className, title, children }) => {
    const ref = reactExports.useRef(null);
    const onClickRef = reactExports.useRef(onClick);
    const disabledRef = reactExports.useRef(disabled);
    onClickRef.current = onClick;
    disabledRef.current = disabled;
    reactExports.useEffect(() => {
      var _a2;
      const btn = (_a2 = ref.current) == null ? void 0 : _a2.querySelector("sp-action-button");
      if (!btn) return;
      const handler = (e) => {
        var _a3, _b2, _c2;
        if (disabledRef.current) return;
        (_a3 = e.preventDefault) == null ? void 0 : _a3.call(e);
        (_b2 = e.stopPropagation) == null ? void 0 : _b2.call(e);
        (_c2 = onClickRef.current) == null ? void 0 : _c2.call(onClickRef);
      };
      btn.addEventListener("click", handler);
      return () => btn.removeEventListener("click", handler);
    }, []);
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref, style: { display: "inline-block" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "sp-action-button",
      {
        class: className || "",
        quiet,
        selected: selected ? true : void 0,
        disabled: disabled ? true : void 0,
        title,
        children
      }
    ) });
  };
  const showNotification = (message, type = "info") => {
    const notification = document.createElement("div");
    notification.textContent = message;
    const colors = {
      success: "#4CAF50",
      error: "#F44336",
      info: "#2196F3"
    };
    Object.assign(notification.style, {
      position: "fixed",
      top: "20px",
      right: "20px",
      padding: "12px 20px",
      borderRadius: "8px",
      color: "#fff",
      fontSize: "14px",
      fontWeight: "500",
      zIndex: "10000",
      backgroundColor: colors[type] || colors.info,
      maxWidth: "400px",
      wordWrap: "break-word"
    });
    document.body.appendChild(notification);
    setTimeout(() => {
      if (notification.parentNode) {
        document.body.removeChild(notification);
      }
    }, 3e3);
  };
  const generateId = () => `${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const HistoryView = ({ onImageClick, onAddToReference, isActive }) => {
    const [historyGroups, setHistoryGroups] = reactExports.useState([]);
    const [expandedGroups, setExpandedGroups] = reactExports.useState(/* @__PURE__ */ new Set());
    const allImages = reactExports.useMemo(() => historyGroups.flatMap((g) => g.images), [historyGroups]);
    const [isLoading, setIsLoading] = reactExports.useState(false);
    const [feedbackImageId, setFeedbackImageId] = reactExports.useState(null);
    const [refFeedbackImageId, setRefFeedbackImageId] = reactExports.useState(null);
    const [watchFolderName, setWatchFolderName] = reactExports.useState(null);
    const [isWatchFolderLoading, setIsWatchFolderLoading] = reactExports.useState(false);
    const [textFolderError, setTextFolderError] = reactExports.useState(null);
    const [isTextFolderLoading, setIsTextFolderLoading] = reactExports.useState(false);
    const [isSelectionMode, setIsSelectionMode] = reactExports.useState(false);
    const [selectedIds, setSelectedIds] = reactExports.useState(/* @__PURE__ */ new Set());
    const [isDeleting, setIsDeleting] = reactExports.useState(false);
    const [isAddingToRef, setIsAddingToRef] = reactExports.useState(false);
    const [previewScaleIndex, setPreviewScaleIndex] = reactExports.useState(0);
    const previewScales = [64, 96, 128];
    const imageSize = previewScales[previewScaleIndex];
    const cancelledRef = reactExports.useRef(false);
    const blobUrlsRef = reactExports.useRef(/* @__PURE__ */ new Set());
    reactExports.useEffect(() => {
      return () => {
        cancelledRef.current = true;
        blobUrlsRef.current.forEach((url) => {
          URL.revokeObjectURL(url);
        });
        blobUrlsRef.current.clear();
      };
    }, []);
    reactExports.useEffect(() => {
      if (!isActive) {
        cancelledRef.current = true;
        return;
      }
      cancelledRef.current = false;
      const init = async () => {
        try {
          await HistoryManager.initializeFolders();
        } catch (err) {
          console.error("[Gallery] Failed to initialize folders:", err);
        }
        setWatchFolderName(HistoryManager.getWatchFolderName());
        await loadHistory();
      };
      init();
    }, [isActive]);
    const setGroup = (group) => {
      setHistoryGroups((prev) => {
        const others = prev.filter((g) => g.id !== group.id);
        return group.id === "history" ? [group, ...others] : [...others, group];
      });
    };
    const loadHistory = async () => {
      console.log("[History] Loading history...");
      cancelledRef.current = false;
      setIsLoading(true);
      try {
        const historyFolders = await HistoryManager.getFolders();
        const metaPromises = historyFolders.map(async (f) => {
          const items = await HistoryManager.getItemsInFolderLite(f.id);
          return items.map((item) => ({
            id: item.id,
            url: "",
            prompt: item.prompt,
            savedPath: item.savedPath,
            folderName: f.id,
            source: "gallery",
            createdAt: item.createdAt
          }));
        });
        const metaResults = await Promise.all(metaPromises);
        let flatImages = metaResults.flat();
        flatImages.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        if (cancelledRef.current) return;
        setGroup({ id: "history", label: "History", images: flatImages });
        const BATCH_SIZE = 24;
        for (let i = 0; i < flatImages.length; i += BATCH_SIZE) {
          if (cancelledRef.current) return;
          const batch = flatImages.slice(i, i + BATCH_SIZE);
          const batchPromises = batch.map(async (img) => {
            try {
              const buffer = await HistoryManager.getItemBuffer(img.folderName, img.id);
              const format = detectImageFormat(buffer);
              const blob = new Blob([buffer], { type: `image/${format}` });
              const url = URL.createObjectURL(blob);
              blobUrlsRef.current.add(url);
              return { ...img, url };
            } catch (err) {
              console.error(`[History] Failed to load image ${img.id}:`, err);
              return null;
            }
          });
          const loaded = (await Promise.all(batchPromises)).filter((img) => img !== null);
          if (cancelledRef.current) return;
          setHistoryGroups((prev) => {
            const historyGroup = prev.find((g) => g.id === "history");
            if (!historyGroup) return prev;
            const newImages = [...historyGroup.images];
            loaded.forEach((loadedImg) => {
              const idx = newImages.findIndex((i2) => i2.id === loadedImg.id);
              if (idx !== -1) newImages[idx] = loadedImg;
            });
            const others = prev.filter((g) => g.id !== "history");
            return [{ ...historyGroup, images: newImages }, ...others];
          });
        }
        console.log("[History] Loaded", flatImages.length, "gallery images");
      } catch (err) {
        console.error("Failed to load history:", err);
      } finally {
        setIsLoading(false);
      }
    };
    const loadTextFolder = async () => {
      if (!isActive) return;
      setIsTextFolderLoading(true);
      try {
        const result = await HistoryManager.getTextFolderImages(watchFolderName ? "custom" : void 0);
        const textImages = (result.images || []).map((img) => ({
          id: img.id,
          url: img.url,
          prompt: img.name,
          savedPath: img.path,
          folderName: "text",
          source: "text",
          createdAt: Date.now()
        }));
        if (textImages.length > 0 || watchFolderName) {
          setGroup({
            id: "text",
            label: watchFolderName || "本地文件夹",
            images: textImages
          });
        } else {
          setHistoryGroups((prev) => prev.filter((g) => g.id !== "text"));
        }
        setTextFolderError(result.error || null);
      } catch (err) {
        console.error("Failed to load text folder:", err);
      } finally {
        setIsTextFolderLoading(false);
      }
    };
    reactExports.useEffect(() => {
      if (!isActive) return;
      loadTextFolder();
      const interval = setInterval(() => {
        loadTextFolder();
      }, 1e4);
      return () => clearInterval(interval);
    }, [watchFolderName, isActive]);
    const handleSelectWatchFolder = async () => {
      setIsWatchFolderLoading(true);
      try {
        const result = await HistoryManager.selectWatchFolder();
        if (result.success) {
          setWatchFolderName(result.path || null);
          console.log("[History] 文件夹已选择:", result.path);
          setTimeout(() => loadTextFolder(), 0);
        } else if (result.error) {
          console.log("Select folder cancelled or failed:", result.error);
        }
      } catch (err) {
        console.error("Failed to select folder:", err);
      } finally {
        setIsWatchFolderLoading(false);
      }
    };
    const handleClearWatchFolder = () => {
      HistoryManager.clearWatchFolder();
      setWatchFolderName(null);
      setHistoryGroups((prev) => prev.filter((g) => g.id !== "text"));
    };
    const handleHistoryImageClick = async (image) => {
      try {
        setFeedbackImageId(image.id);
        let fullUrl;
        if (image.source === "text") {
          fullUrl = image.url;
        } else {
          fullUrl = await HistoryManager.getItemDataUrl(image.folderName, image.id);
        }
        const galleryItem = {
          id: image.id,
          dataUrl: fullUrl,
          createdAt: image.createdAt || Date.now(),
          prompt: image.prompt,
          source: image.source === "text" ? "upload" : "generate",
          savedPath: image.savedPath
        };
        if (onImageClick) {
          await onImageClick(galleryItem);
        } else {
          await placeImageCentered(
            fullUrl,
            void 0,
            void 0,
            image.prompt ? `History: ${image.prompt.substring(0, 30)}` : `History Image ${image.id}`
          );
        }
        setTimeout(() => {
          setFeedbackImageId(null);
        }, 2e3);
      } catch (error) {
        console.error("Failed to place image:", error);
        setFeedbackImageId(null);
        showNotification("图片复制失败，请重试", "error");
      }
    };
    reactExports.useEffect(() => {
      return eventBus.on(GalleryEventType.IMAGE_GENERATED, (data) => {
        console.log("[History] IMAGE_GENERATED event received:", data);
        loadHistory();
      });
    }, []);
    const toggleSelectionMode = () => {
      setIsSelectionMode((prev) => !prev);
      setSelectedIds(/* @__PURE__ */ new Set());
    };
    const toggleImageSelection = (imageId) => {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        if (next.has(imageId)) {
          next.delete(imageId);
        } else {
          next.add(imageId);
        }
        return next;
      });
    };
    const handleAddToReference = async () => {
      if (selectedIds.size === 0 || !onAddToReference) return;
      setIsAddingToRef(true);
      const idsToAdd = new Set(selectedIds);
      const imagesToAdd = allImages.filter((img) => idsToAdd.has(img.id));
      try {
        await onAddToReference(imagesToAdd);
        showNotification(`已添加 ${imagesToAdd.length} 张图片到 Edit 参考图`, "success");
        setSelectedIds(/* @__PURE__ */ new Set());
        setIsSelectionMode(false);
      } catch (err) {
        console.error("Failed to add to reference:", err);
        showNotification("添加到参考图失败，请重试", "error");
      } finally {
        setIsAddingToRef(false);
      }
    };
    const cyclePreviewScale = () => {
      setPreviewScaleIndex((prev) => (prev + 1) % previewScales.length);
    };
    const handleDeleteSelected = async () => {
      if (selectedIds.size === 0) return;
      setIsDeleting(true);
      const idsToDelete = new Set(selectedIds);
      const imagesToDelete = allImages.filter((img) => idsToDelete.has(img.id) && img.source === "gallery");
      setHistoryGroups((prev) => prev.map((g) => ({
        ...g,
        images: g.images.filter((img) => !idsToDelete.has(img.id))
      })));
      setSelectedIds(/* @__PURE__ */ new Set());
      setIsSelectionMode(false);
      try {
        await Promise.all(
          imagesToDelete.map(
            (img) => HistoryManager.deleteItemFromFolder(img.id, img.folderName)
          )
        );
        showNotification(`已删除 ${imagesToDelete.length} 张图片`, "success");
      } catch (err) {
        console.error("Failed to delete images:", err);
        showNotification("删除失败，请重试", "error");
        await loadHistory();
      } finally {
        setIsDeleting(false);
      }
    };
    const galleryCount = allImages.filter((i) => i.source === "gallery").length;
    const textCount = allImages.filter((i) => i.source === "text").length;
    const toggleGroup = (groupId) => {
      setExpandedGroups((prev) => {
        const next = new Set(prev);
        if (next.has(groupId)) next.delete(groupId);
        else next.add(groupId);
        return next;
      });
    };
    const renderImageGrid = (images) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "history-images-grid", style: { "--image-size": `${imageSize}px` }, children: images.map((image) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: `history-image-item ${feedbackImageId === image.id ? "feedback-active" : ""} ${isSelectionMode ? "selection-mode" : ""} ${selectedIds.has(image.id) ? "selected" : ""} ${!image.url ? "loading" : ""}`,
        title: image.prompt,
        onClick: () => {
          if (isSelectionMode) {
            toggleImageSelection(image.id);
          } else {
            handleHistoryImageClick(image);
          }
        },
        children: [
          isSelectionMode && image.source === "gallery" && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `history-image-checkbox ${selectedIds.has(image.id) ? "checked" : ""}`,
              onClick: (e) => {
                e.stopPropagation();
                toggleImageSelection(image.id);
              },
              children: selectedIds.has(image.id) && /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { width: "12", height: "12", viewBox: "0 0 12 12", fill: "none", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M2 6L5 9L10 3", stroke: "white", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" }) })
            }
          ),
          image.url ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: image.url,
              alt: image.prompt || "",
              className: `history-image-img ${isSelectionMode && !selectedIds.has(image.id) ? "dimmed" : ""}`,
              draggable: false
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "history-image-placeholder", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "history-image-spinner" }) }),
          feedbackImageId === image.id && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "history-image-feedback", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "✓ 已添加到画布" }) })
        ]
      },
      image.id
    )) });
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "history-view", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "history-toolbar", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "history-toolbar-left", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            UxPActionButton,
            {
              className: "history-select-folder-btn",
              onClick: handleSelectWatchFolder,
              disabled: isWatchFolderLoading,
              children: isWatchFolderLoading ? "..." : watchFolderName ? "📁 已选择" : "📂 选择文件夹"
            }
          ),
          watchFolderName && /* @__PURE__ */ jsxRuntimeExports.jsx(UxPActionButton, { quiet: true, onClick: handleClearWatchFolder, title: watchFolderName, children: "✕" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("sp-body", { size: "XS", children: [
            galleryCount > 0 && `${galleryCount}张历史`,
            textCount > 0 && ` · ${textCount}张本地`
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "history-toolbar-right", children: [
          isSelectionMode && selectedIds.size > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(UxPActionButton, { quiet: true, onClick: handleAddToReference, disabled: isAddingToRef, children: isAddingToRef ? "添加中..." : `添加到参考图 (${selectedIds.size})` }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(UxPActionButton, { quiet: true, onClick: handleDeleteSelected, disabled: isDeleting, children: isDeleting ? "删除中..." : `删除 (${selectedIds.size})` })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(UxPActionButton, { quiet: true, onClick: cyclePreviewScale, title: `当前尺寸: ${imageSize}px`, children: [
            "🔍 ",
            imageSize,
            "px"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            UxPActionButton,
            {
              quiet: true,
              selected: isSelectionMode,
              onClick: toggleSelectionMode,
              children: isSelectionMode ? "完成" : "选择图片"
            }
          )
        ] })
      ] }),
      textFolderError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "history-error", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "S", children: textFolderError }) }),
      historyGroups.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "history-group", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          UxPActionButton,
          {
            quiet: true,
            className: "history-group-header",
            onClick: () => toggleGroup(group.id),
            children: [
              expandedGroups.has(group.id) ? "▼" : "▶",
              "  ",
              group.label,
              "  (",
              group.images.length,
              "张)"
            ]
          }
        ),
        expandedGroups.has(group.id) && group.images.length > 0 && renderImageGrid(group.images)
      ] }, group.id)),
      allImages.length === 0 && !isLoading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "history-empty", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "S", children: "暂无历史记录" }) }),
      isLoading && allImages.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "history-empty", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "S", children: "加载中..." }) })
    ] });
  };
  const Gallery = () => {
    const gen = useGeneration();
    const items = gen.generatedItems;
    const [activeTab, setActiveTab] = reactExports.useState("t2i");
    const [authState, setAuthState] = reactExports.useState(getAuthState);
    reactExports.useEffect(() => {
      if (!authState) {
        setActiveTab("profile");
      }
    }, []);
    const [otherModelIndex, setOtherModelIndex] = reactExports.useState(0);
    const otherModels = ["放大图片", "移除图片", "面部形象修复", "Klein4K清晰", "Z-image动漫放大"];
    const otherModeMap = [2, 3, 2, 2, 2];
    reactExports.useEffect(() => {
      const modeMap = {
        t2i: 4,
        edit: 1,
        other: otherModeMap[otherModelIndex]
      };
      if (modeMap[activeTab] !== void 0) {
        gen.setModeIndex(modeMap[activeTab]);
      }
    }, [activeTab, otherModelIndex]);
    const [temperature, setTemperature] = reactExports.useState(50);
    const [isLightActive, setIsLightActive] = reactExports.useState(false);
    const [previewIndex, setPreviewIndex] = reactExports.useState(0);
    const [img2ImgRunning, setImg2ImgRunning] = reactExports.useState(false);
    const [isCanvasHovered, setIsCanvasHovered] = reactExports.useState(false);
    const hoverTimeoutRef = reactExports.useRef(null);
    const liveTimeoutRef = reactExports.useRef(null);
    const isLightActiveRef = reactExports.useRef(false);
    const galleryContainerRef = reactExports.useRef(null);
    const autoCaptureRef = reactExports.useRef(false);
    reactExports.useEffect(() => {
      setPreviewIndex(0);
    }, [items.length]);
    reactExports.useEffect(() => {
      var _a2;
      if (activeTab === "edit") {
        if (gen.referenceImages.length === 0 && !autoCaptureRef.current && !gen.isGenerating) {
          autoCaptureRef.current = true;
          (_a2 = gen.captureCanvasAsReference) == null ? void 0 : _a2.call(gen);
        }
      } else {
        autoCaptureRef.current = false;
      }
    }, [activeTab, gen.referenceImages.length, gen.isGenerating, gen.captureCanvasAsReference]);
    const imageUploaderEl = reactExports.useMemo(() => activeTab === "edit" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
      ImageUploader,
      {
        images: gen.referenceImages,
        onAdd: gen.addReferenceImages,
        onRemove: gen.removeReferenceImage,
        disabled: gen.isGenerating
      }
    ) : void 0, [activeTab, gen.referenceImages, gen.addReferenceImages, gen.removeReferenceImage, gen.isGenerating]);
    const handleClearError = reactExports.useCallback(() => gen.setError(null), [gen.setError]);
    const handleClearSuccess = reactExports.useCallback(() => gen.setSuccess(null), [gen.setSuccess]);
    const handleSeedModeChange = reactExports.useCallback((v) => gen.setSeedMode(v), [gen.setSeedMode]);
    const previewEl = reactExports.useMemo(() => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "gallery-content gc-preview-area", children: items.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "gc-preview-wrapper", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "gallery-thumb gc-preview-thumb",
          onClick: () => handleImageClick(items[previewIndex]),
          style: {
            backgroundImage: `url(${items[previewIndex].dataUrl})`,
            backgroundSize: "contain",
            backgroundPosition: "center center",
            backgroundRepeat: "no-repeat"
          }
        }
      ) }),
      items.length > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gc-preview-nav", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { onClick: () => setPreviewIndex((i) => i > 0 ? i - 1 : items.length - 1), children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-action-button", { quiet: true, children: "‹" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("sp-body", { size: "S", children: [
          previewIndex + 1,
          " / ",
          items.length
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { onClick: () => setPreviewIndex((i) => i < items.length - 1 ? i + 1 : 0), children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-action-button", { quiet: true, children: "›" }) })
      ] })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "gallery-upload-container gc-preview-placeholder", children: /* @__PURE__ */ jsxRuntimeExports.jsx("sp-body", { size: "S", children: "Generated image will appear here" }) }) }), [items, previewIndex]);
    const [isGenerating, setIsGenerating] = reactExports.useState(false);
    const [generationProgress, setGenerationProgress] = reactExports.useState(0);
    reactExports.useRef(null);
    const progressTimerRef = reactExports.useRef(null);
    reactExports.useEffect(() => {
      if (isGenerating) {
        if (progressTimerRef.current) clearInterval(progressTimerRef.current);
        progressTimerRef.current = setInterval(() => {
          setGenerationProgress((prev) => {
            if (prev >= 90) return prev;
            return Math.min(90, prev + (1 + Math.random() * 2));
          });
        }, 200);
      } else {
        if (progressTimerRef.current) {
          clearInterval(progressTimerRef.current);
          progressTimerRef.current = null;
        }
      }
      return () => {
        if (progressTimerRef.current) clearInterval(progressTimerRef.current);
      };
    }, [isGenerating]);
    const [isTouchDevice, setIsTouchDevice] = reactExports.useState(false);
    reactExports.useEffect(() => {
      setIsTouchDevice("ontouchstart" in window || navigator.maxTouchPoints > 0);
    }, []);
    const handleCanvasHover = (hovered) => {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current);
      }
      hoverTimeoutRef.current = setTimeout(() => {
        setIsCanvasHovered(hovered);
      }, 50);
    };
    const isProcessingRef = reactExports.useRef(false);
    const itemsRef = reactExports.useRef(items);
    reactExports.useEffect(() => {
      itemsRef.current = items;
    }, [items]);
    reactExports.useEffect(() => {
      return () => {
        console.log("[Gallery] Component unmounted, cleaning all cache");
        pixelPreheatService.clearCache();
        tokenPreheatService.clearCache();
        if (itemsRef.current) {
          itemsRef.current.forEach((item) => {
            if (item.dataUrl && item.dataUrl.startsWith("blob:")) {
              URL.revokeObjectURL(item.dataUrl);
            }
          });
        }
      };
    }, []);
    reactExports.useEffect(() => {
      return eventBus.on(GalleryEventType.IMAGE_GENERATED, (detail) => {
        if (!(detail == null ? void 0 : detail.dataUrl)) return;
        const item = {
          id: detail.id || generateId(),
          dataUrl: detail.dataUrl,
          createdAt: detail.createdAt || Date.now(),
          prompt: detail.prompt || "",
          width: detail.width,
          height: detail.height,
          source: "generate",
          sessionToken: detail.sessionToken,
          savedPath: detail.savedPath,
          selectionBounds: detail.selectionBounds,
          isTokenReady: true,
          isPixelsReady: true
        };
        gen.addGeneratedItem(item);
      });
    }, []);
    const handleImageClick = async (item) => {
      if (isProcessingRef.current) {
        return;
      }
      try {
        isProcessingRef.current = true;
        console.log("[Gallery] ========== Click processing (Zero-Base64) ==========");
        console.log("[Gallery] Target item ID:", item.id);
        showNotification("🔄 Placing image...", "info");
        if (imagingConfig.enablePerformanceMonitoring) {
          PerformanceMonitor.start("Image Processing");
        }
        let activeSessionToken = item.sessionToken;
        if (!activeSessionToken && item.savedPath) {
          try {
            console.log("[Gallery] SessionToken missing, attempting to regenerate from savedPath:", item.savedPath);
            const fs2 = uxp.storage.localFileSystem;
            let pathUrl = item.savedPath;
            if (pathUrl.startsWith("file:")) {
              if (/^file:\/\/[^/]/i.test(pathUrl)) {
                pathUrl = pathUrl.replace(/^file:\/\//i, "file:///");
              }
            } else {
              pathUrl = pathUrl.replace(/\\/g, "/");
              if (/^[A-Za-z]:\//.test(pathUrl)) {
                pathUrl = `file:///${pathUrl}`;
              } else if (pathUrl.startsWith("/")) {
                pathUrl = `file://${pathUrl}`;
              } else {
                pathUrl = `file:///${pathUrl}`;
              }
            }
            console.log("[Gallery] Regenerating token from URL:", pathUrl);
            const entry = await fs2.getEntryWithUrl(pathUrl);
            activeSessionToken = await fs2.createSessionToken(entry);
            console.log("[Gallery] ✅ Session Token regenerated successfully");
          } catch (tokenErr) {
            console.error("[Gallery] ❌ Failed to regenerate session token:", tokenErr);
          }
        }
        if (!activeSessionToken) {
          try {
            const { createSessionTokenFromImageData: createSessionTokenFromImageData2 } = await __vitePreload(async () => {
              const { createSessionTokenFromImageData: createSessionTokenFromImageData3 } = await Promise.resolve().then(() => imagePlacement);
              return { createSessionTokenFromImageData: createSessionTokenFromImageData3 };
            }, false ? __VITE_PRELOAD__ : void 0, _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("assets/main.js", document.baseURI).href);
            activeSessionToken = await createSessionTokenFromImageData2(item.dataUrl);
            console.log("[Gallery] ✅ Session Token generated from image data");
          } catch (tokenErr) {
            console.error("[Gallery] ❌ Failed to generate session token from image data:", tokenErr);
          }
        }
        let selectionBounds = null;
        try {
          selectionBounds = await getSelectionBounds();
        } catch (e) {
        }
        if (activeSessionToken) {
          if (selectionBounds) {
            const { placeImageToSelection: placeImageToSelection2 } = await __vitePreload(async () => {
              const { placeImageToSelection: placeImageToSelection3 } = await Promise.resolve().then(() => imagePlacement);
              return { placeImageToSelection: placeImageToSelection3 };
            }, false ? __VITE_PRELOAD__ : void 0, _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("assets/main.js", document.baseURI).href);
            await placeImageToSelection2(activeSessionToken, selectionBounds, `Inpaint_${item.id}`);
          } else {
            const { placeImageUsingTokenNoScale: placeImageUsingTokenNoScale2 } = await __vitePreload(async () => {
              const { placeImageUsingTokenNoScale: placeImageUsingTokenNoScale3 } = await Promise.resolve().then(() => imagePlacement);
              return { placeImageUsingTokenNoScale: placeImageUsingTokenNoScale3 };
            }, false ? __VITE_PRELOAD__ : void 0, _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("assets/main.js", document.baseURI).href);
            await placeImageUsingTokenNoScale2(activeSessionToken, `Generate_${item.id}`);
          }
        } else {
          console.log("[Gallery] No Session Token, falling back to standard placement");
          await placeImageOnCanvasAsNewLayer(item.dataUrl, `Gallery_${item.id}`);
        }
        if (imagingConfig.enablePerformanceMonitoring) {
          PerformanceMonitor.end();
        }
        console.log("[Gallery] ✅ Image added successfully");
        showNotification("✅ Image successfully added to canvas", "success");
        console.log("[Gallery] ========== Flow complete ==========");
      } catch (err) {
        {
          PerformanceMonitor.end();
        }
        console.error("[Gallery] ========== Flow failed ==========");
        console.error("[Gallery] Error details:", err);
        const errorMessage = getUserFriendlyErrorMessage(err);
        showNotification(`❌ ${errorMessage}`, "error");
      } finally {
        isProcessingRef.current = false;
      }
    };
    const pollImg2ImgTask = async (requestId) => {
      const maxAttempts = 60;
      const interval = 2e3;
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        console.log(`[Gallery] 轮询任务状态 (${attempt}/${maxAttempts})...`);
        try {
          const response = await fetch(
            `${getProxyBaseURL()}/api/generate/proxy/result?request_id=${requestId}`,
            {
              method: "GET",
              headers: (() => {
                const h = {};
                try {
                  const token = localStorage.getItem("ps_plugin_token");
                  if (token) h["Authorization"] = `Bearer ${token}`;
                } catch {
                }
                return h;
              })()
            }
          );
          if (!response.ok) {
            const raw2 = await response.text().catch(() => "");
            console.error("[Gallery] 轮询失败:", response.status, raw2);
            await new Promise((resolve) => setTimeout(resolve, interval));
            continue;
          }
          const raw = await response.text();
          let result;
          try {
            result = JSON.parse(raw);
          } catch {
            result = raw;
          }
          console.log("[Gallery] 任务状态:", result == null ? void 0 : result.status);
          if (result.status === "Success" && result.outputs && result.outputs.length > 0) {
            const imageUrl = result.outputs[0].object_url;
            console.log("[Gallery] 任务完成，图片URL:", imageUrl);
            return { success: true, data: imageUrl };
          }
          if (result.status === "Failed") {
            return { success: false, error: result.error_msg || "任务失败" };
          }
          setGenerationProgress(Math.min(Math.floor(attempt / maxAttempts * 90), 90));
          await new Promise((resolve) => setTimeout(resolve, interval));
        } catch (error) {
          console.error("[Gallery] 轮询出错:", error);
          await new Promise((resolve) => setTimeout(resolve, interval));
        }
      }
      return { success: false, error: "任务超时" };
    };
    const startImg2ImgWorkflow = async () => {
      console.log("[Gallery] ⚡ 启动图生图工作流");
      console.log("[Gallery] Prompt:", gen.prompt || "(无提示词，使用默认)");
      console.log("[Gallery] Temperature:", temperature);
      showNotification("🚀 Live 模式启动...", "info");
      setImg2ImgRunning(true);
      setIsLightActive(true);
      isLightActiveRef.current = true;
      setIsGenerating(true);
      setGenerationProgress(5);
      try {
        const prompt = gen.prompt.trim() || "高质量、极具美感少女插画，画面分辨率高，细节丰富";
        const denoise = temperature / 100;
        console.log("[Gallery] 📸 步骤1: 捕获画布...");
        setGenerationProgress(10);
        const imageData = await captureCanvasUsingImagingAPI();
        console.log("[Gallery] 📸 画布捕获完成, 大小:", imageData.byteLength, "bytes");
        setGenerationProgress(30);
        console.log("[Gallery] ☁️ 步骤2: 上传到 BizyAir...");
        const imageUrl = await uploadImageToBizyAir(imageData);
        console.log("[Gallery] ☁️ 上传完成, 图片URL:", imageUrl);
        setGenerationProgress(50);
        console.log("[Gallery] 🎨 步骤3: 调用云端代理图生图 API...");
        const bizyAirUrl = "https://api.bizyair.cn/w/v1/webapp/task/openapi/create";
        const headers = {
          "Content-Type": "application/json",
          "Authorization": "Bearer ${BIZYAIR_API_KEY}"
        };
        const requestData = {
          web_app_id: 54800,
          suppress_preview_output: true,
          input_values: {
            "28:CR Text.text": prompt,
            "23:KSampler.denoise": denoise,
            "34:LoadImage.image": imageUrl
          }
        };
        console.log("[Gallery] 📤 发送请求到代理:", JSON.stringify(requestData, null, 2));
        const response = await fetch(`${getProxyBaseURL()}/api/generate/proxy`, {
          method: "POST",
          headers: (() => {
            const h = { "Content-Type": "application/json" };
            try {
              const token = localStorage.getItem("ps_plugin_token");
              if (token) h["Authorization"] = `Bearer ${token}`;
            } catch {
            }
            return h;
          })(),
          body: JSON.stringify({ url: bizyAirUrl, headers, data: requestData, model: "Anima Turbo" })
        });
        console.log("[Gallery] 📥 响应状态:", response.status, response.statusText);
        const raw = await response.text();
        let result;
        try {
          result = JSON.parse(raw);
        } catch {
          result = raw;
        }
        console.log("[Gallery] 📥 收到响应:", result);
        if (!response.ok) {
          throw new Error(`API 请求失败 (${response.status}): ${raw}`);
        }
        if (response.status === 202 && result && result.requestId) {
          console.log("[Gallery] 🔄 异步任务，开始轮询...");
          setGenerationProgress(60);
          const taskResult = await pollImg2ImgTask(result.requestId);
          if (taskResult.success && taskResult.data) {
            handleImg2ImgResult({
              success: true,
              preview_url: taskResult.data,
              prompt
            });
          } else {
            throw new Error(taskResult.error || "任务失败");
          }
        } else if (result && result.outputs && result.outputs.length > 0 && result.outputs[0].object_url) {
          handleImg2ImgResult({
            success: true,
            preview_url: result.outputs[0].object_url,
            prompt
          });
        } else {
          throw new Error("响应中没有图片数据");
        }
        if (isLightActiveRef.current) {
          console.log("[Gallery] 🔄 连续模式：安排下一次执行...");
          liveTimeoutRef.current = setTimeout(() => {
            startImg2ImgWorkflow();
          }, 800);
        }
      } catch (error) {
        console.error("[Gallery] 图生图异常:", error);
        showNotification(`❌ 图生图请求失败: ${error.message || error}`, "error");
        setIsLightActive(false);
        isLightActiveRef.current = false;
      } finally {
        setImg2ImgRunning(false);
        setIsGenerating(false);
        setGenerationProgress(0);
      }
    };
    const stopImg2ImgWorkflow = async () => {
      console.log("[Gallery] ⏹️ 停止图生图工作流");
      if (liveTimeoutRef.current) {
        clearTimeout(liveTimeoutRef.current);
        liveTimeoutRef.current = null;
      }
      try {
        await fetch(getLocalBackendApiUrl("/api/img2img/stop"), {
          method: "POST"
        });
      } catch (e) {
      }
      setImg2ImgRunning(false);
      setIsLightActive(false);
      isLightActiveRef.current = false;
      setIsGenerating(false);
      setGenerationProgress(0);
      showNotification("已停止图生图", "info");
    };
    const handleImg2ImgResult = (result) => {
      console.log("[Gallery] ✅ 图生图完成:", result);
      const id = generateId();
      const item = {
        id,
        dataUrl: result.preview_url,
        createdAt: Date.now(),
        prompt: gen.prompt || result.prompt || "图生图",
        source: "generate",
        isTokenReady: true,
        isPixelsReady: true
      };
      gen.addGeneratedItem(item);
      showNotification("✅ 图生图完成", "success");
    };
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        ref: galleryContainerRef,
        className: `gallery ${isCanvasHovered || isTouchDevice ? "canvas-hovered" : ""}`,
        onMouseEnter: () => handleCanvasHover(true),
        onMouseLeave: () => handleCanvasHover(false),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "gallery-progress-bar-container", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `gallery-progress-bar ${isGenerating ? "active" : ""}`,
              style: { width: `${generationProgress}%` }
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "gallery-nav", children: [
            { key: "t2i", label: "T2I" },
            { key: "edit", label: "Edit" },
            { key: "other", label: "Other" },
            { key: "live", label: "Live" },
            { key: "history", label: "History" },
            { key: "profile", label: "Profile" }
          ].map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `nav-item ${activeTab === tab.key ? "active" : ""}`,
              onClick: () => {
                setActiveTab(tab.key);
                const modeMap = {
                  t2i: 4,
                  edit: 1,
                  other: otherModeMap[otherModelIndex]
                };
                if (modeMap[tab.key] !== void 0) {
                  gen.setModeIndex(modeMap[tab.key]);
                }
              },
              children: tab.label
            },
            tab.key
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gallery-main-view", children: [
            ["t2i", "edit", "other"].includes(activeTab) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "view-generation active", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              GenerationControl,
              {
                modeIndex: activeTab === "other" ? otherModeMap[otherModelIndex] : gen.modeIndex,
                modelIndex: activeTab === "other" ? otherModelIndex : gen.modelIndex,
                modelLabel: activeTab === "other" ? otherModels[otherModelIndex] : gen.modelLabel,
                models: activeTab === "other" ? otherModels : gen.models,
                prompt: gen.prompt,
                isGenerating: gen.isGenerating,
                error: gen.error,
                success: gen.success,
                progress: gen.progress,
                isProgressVisible: gen.isProgressVisible,
                showParams: activeTab !== "other",
                showPrompt: activeTab !== "other",
                showAspectRatio: activeTab === "t2i" || activeTab === "edit",
                aspectRatio: gen.aspectRatio,
                onAspectRatioChange: gen.setAspectRatio,
                showSeedBatch: activeTab === "t2i",
                lora: gen.lora,
                onLoraChange: gen.setLora,
                seed: gen.seed,
                seedMode: gen.seedMode,
                onSeedModeChange: handleSeedModeChange,
                onSeedChange: gen.setSeed,
                onRandomizeSeed: () => {
                  gen.setSeedMode("fixed");
                  gen.setSeed(Math.floor(Math.random() * 1e12));
                },
                batchSize: gen.batchSize,
                onBatchSizeChange: gen.setBatchSize,
                onPromptChange: gen.setPrompt,
                onGenerate: () => {
                  if (!authState) {
                    gen.setError("请先前往 Profile 页面输入 License Key 激活插件");
                    setActiveTab("profile");
                    return;
                  }
                  gen.handleGenerate(activeTab === "other" ? otherModels[otherModelIndex] === "移除图片" ? "Universal" : otherModels[otherModelIndex] === "放大图片" ? "Seed Face 2K" : otherModels[otherModelIndex] : void 0);
                },
                onPrevModel: activeTab === "other" ? () => {
                  const newIndex = otherModelIndex > 0 ? otherModelIndex - 1 : otherModels.length - 1;
                  setOtherModelIndex(newIndex);
                  gen.setModeIndex(otherModeMap[newIndex]);
                } : gen.prevModel,
                onNextModel: activeTab === "other" ? () => {
                  const newIndex = otherModelIndex < otherModels.length - 1 ? otherModelIndex + 1 : 0;
                  setOtherModelIndex(newIndex);
                  gen.setModeIndex(otherModeMap[newIndex]);
                } : gen.nextModel,
                onModelIndexChange: activeTab === "other" ? (idx) => {
                  setOtherModelIndex(idx);
                  gen.setModeIndex(otherModeMap[idx]);
                } : gen.setModelIndex,
                onClearError: handleClearError,
                onClearSuccess: handleClearSuccess,
                imageUploader: imageUploaderEl,
                isTranslating: gen.isTranslating,
                onTranslate: gen.handleTranslate,
                promptHistory: gen.promptHistory,
                historyIndex: gen.historyIndex,
                onPrevPromptHistory: gen.prevPromptHistory,
                onNextPromptHistory: gen.nextPromptHistory,
                preview: previewEl
              }
            ) }),
            activeTab === "live" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "view-live active", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                GenerationControl,
                {
                  modeIndex: gen.modeIndex,
                  modelIndex: 0,
                  modelLabel: "Anima trubo",
                  models: ["Anima trubo"],
                  prompt: gen.prompt,
                  isGenerating: img2ImgRunning,
                  error: gen.error,
                  success: gen.success,
                  progress: generationProgress,
                  isProgressVisible: isGenerating,
                  showParams: false,
                  showAspectRatio: false,
                  buttonLabel: isLightActive ? "⏸" : "Live",
                  allowInterrupt: true,
                  temperature,
                  onTemperatureChange: setTemperature,
                  onPromptChange: gen.setPrompt,
                  onGenerate: () => {
                    if (!authState && !isLightActive) {
                      gen.setError("请先前往 Profile 页面输入 License Key 激活插件");
                      setActiveTab("profile");
                      return;
                    }
                    if (isLightActive) {
                      stopImg2ImgWorkflow();
                    } else {
                      startImg2ImgWorkflow();
                    }
                  },
                  onPrevModel: () => {
                  },
                  onNextModel: () => {
                  },
                  onClearError: handleClearError,
                  onClearSuccess: handleClearSuccess,
                  isTranslating: gen.isTranslating,
                  onTranslate: gen.handleTranslate,
                  promptHistory: gen.promptHistory,
                  historyIndex: gen.historyIndex,
                  onPrevPromptHistory: gen.prevPromptHistory,
                  onNextPromptHistory: gen.nextPromptHistory,
                  preview: previewEl
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorNotificationContainer, { position: "top", maxErrors: 3 })
            ] }),
            activeTab === "history" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "view-history active", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              HistoryView,
              {
                onImageClick: handleImageClick,
                onAddToReference: async (images) => {
                  const dataUrlToBuffer = (dataUrl) => {
                    const base64 = dataUrl.split(",")[1];
                    if (!base64) return new ArrayBuffer(0);
                    const binary = atob(base64);
                    const bytes = new Uint8Array(binary.length);
                    for (let i = 0; i < binary.length; i++) {
                      bytes[i] = binary.charCodeAt(i);
                    }
                    return bytes.buffer;
                  };
                  const uploadedImages = images.map((img, index) => ({
                    id: `${img.id}_${Date.now()}_${index}`,
                    dataUrl: img.url,
                    buffer: dataUrlToBuffer(img.url),
                    name: img.prompt ? img.prompt.slice(0, 20) : `ref_${index}`
                  }));
                  gen.addReferenceImages(uploadedImages);
                  setActiveTab("edit");
                },
                isActive: activeTab === "history"
              }
            ) }),
            activeTab === "profile" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "view-profile active", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ProfileCenter, { onAuthChange: setAuthState }) })
          ] })
        ]
      }
    );
  };
  (function initLogControl() {
    const DEBUG_KEY = "uxp-debug";
    let isDebug = false;
    try {
      isDebug = localStorage.getItem(DEBUG_KEY) === "true";
    } catch {
    }
    if (!isDebug) {
      console.log = () => {
      };
      console.debug = () => {
      };
      console.info = () => {
      };
    }
    if (typeof window !== "undefined") {
      window.enableUxpDebug = () => {
        try {
          localStorage.setItem(DEBUG_KEY, "true");
          console.warn("[Debug] 详细日志已开启，请刷新插件面板生效");
        } catch (e) {
          console.error("[Debug] 开启失败:", e);
        }
      };
      window.disableUxpDebug = () => {
        try {
          localStorage.removeItem(DEBUG_KEY);
          console.warn("[Debug] 详细日志已关闭，请刷新插件面板生效");
        } catch (e) {
          console.error("[Debug] 关闭失败:", e);
        }
      };
    }
  })();
  class ErrorBoundary extends React.Component {
    constructor() {
      super(...arguments);
      __publicField(this, "state", { hasError: false });
    }
    static getDerivedStateFromError(error) {
      return { hasError: true, error };
    }
    componentDidCatch(error, info) {
      console.error(`[${this.props.name}] Rendering error:`, error, info);
    }
    render() {
      var _a2;
      if (this.state.hasError) {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-boundary", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "error-boundary-title", children: [
            this.props.name,
            " 渲染失败"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "error-boundary-message", children: ((_a2 = this.state.error) == null ? void 0 : _a2.message) || "Unknown error" })
        ] });
      }
      return this.props.children;
    }
  }
  const renderRoot = (elementId, node) => {
    var _a2;
    const element = document.getElementById(elementId);
    if (!element) {
      console.error(`[Plugin] Mount target #${elementId} not found`);
      return;
    }
    const shouldUseShadowDom = globalThis.__USE_SHADOW_DOM__ === true;
    let mountTarget = element;
    if (shouldUseShadowDom) {
      const host = element;
      const shadowRoot = host.shadowRoot ?? ((_a2 = host.attachShadow) == null ? void 0 : _a2.call(host, { mode: "open" }));
      if (shadowRoot) {
        const existing = shadowRoot.querySelector("[data-shadow-mount='true']");
        if (existing) {
          mountTarget = existing;
        } else {
          const mount = document.createElement("div");
          mount.setAttribute("data-shadow-mount", "true");
          shadowRoot.appendChild(mount);
          mountTarget = mount;
        }
      }
    }
    try {
      ReactDOM.createRoot(mountTarget).render(node);
    } catch (err) {
      console.error(`[Plugin] Failed to render into #${elementId}:`, err);
    }
  };
  renderRoot("gallery-root", /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorBoundary, { name: "Gallery", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Gallery, {}) }));
  async function uploadFileToBizyAir(file, maxRetries = 3) {
    console.log("[FileUpload] ========== 开始上传文件 ==========");
    console.log("[FileUpload] 文件名:", file.name, "大小:", file.size, "类型:", file.type);
    if (isOverseasRoute()) {
      try {
        const buffer = await file.arrayBuffer();
        const { uploadImageToBizyAir: uploadImageToBizyAir2 } = await __vitePreload(async () => {
          const { uploadImageToBizyAir: uploadImageToBizyAir3 } = await Promise.resolve().then(() => imageUpload);
          return { uploadImageToBizyAir: uploadImageToBizyAir3 };
        }, false ? __VITE_PRELOAD__ : void 0, _documentCurrentScript && _documentCurrentScript.tagName.toUpperCase() === "SCRIPT" && _documentCurrentScript.src || new URL("assets/main.js", document.baseURI).href);
        const url = await uploadImageToBizyAir2(buffer);
        return { success: true, url };
      } catch (error) {
        console.error("[FileUpload] presign 上传失败:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "上传失败"
        };
      }
    }
    const uploadUrl = `${getProxyBaseURL()}/api/upload/bizyair`;
    let lastError = null;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`[FileUpload] 上传尝试 ${attempt}/${maxRetries}`);
        const formData = new FormData();
        formData.append("image", file);
        formData.append("fileName", file.name);
        const response = await fetch(uploadUrl, {
          method: "POST",
          body: formData
        });
        if (!response.ok) {
          const errorText = await response.text().catch(() => "");
          throw new Error(`HTTP ${response.status}: ${errorText || response.statusText}`);
        }
        const result = await response.json();
        console.log("[FileUpload] 上传成功:", result.url);
        return {
          success: true,
          url: result.url,
          objectKey: result.objectKey
        };
      } catch (error) {
        lastError = error;
        console.error(`[FileUpload] 上传失败 (尝试 ${attempt}/${maxRetries}):`, lastError.message);
        if (attempt >= maxRetries) break;
        const delay = Math.min(1e3 * Math.pow(2, attempt - 1), 5e3);
        console.log(`[FileUpload] 等待 ${delay}ms 后重试...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
    return {
      success: false,
      error: (lastError == null ? void 0 : lastError.message) || "上传失败（已达最大重试次数）"
    };
  }
  const fileUpload = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    uploadFileToBizyAir
  }, Symbol.toStringTag, { value: "Module" }));
})();
