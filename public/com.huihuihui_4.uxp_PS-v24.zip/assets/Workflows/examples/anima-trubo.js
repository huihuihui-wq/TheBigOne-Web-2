// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54755,
      "suppress_preview_output": true,
      "input_values": {
        "20:CR Text.text": "@bkub，1 名少女，站姿，白色连衣裙，红发，指尖停着一只蓝色蝴蝶，画面故障特效",
        "80:EmptyLatentImage.batch_size": 1,
        "78:Seed_.seed": 164647045803920,
        "82:孤海_kontext生图比例.选择尺寸": "9：16（752x1392）"
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);