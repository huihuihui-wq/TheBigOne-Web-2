// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54435,
      "suppress_preview_output": true,
      "input_values": {
        "31:BizyAirSiliconCloudLLMAPI.user_prompt": "小猫，梵高风格",
        "29:孤海_kontext生图比例.选择尺寸": "9：21（672x1568）",
        "30:EmptyLatentImage.batch_size": 1,
        "20:KSampler.seed": 871233576896110
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);