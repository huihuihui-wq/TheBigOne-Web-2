// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54472,
      "suppress_preview_output": true,
      "input_values": {
        "18:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260521/lldmYQZnHzItkQMC7an5rzTItQ96a6kJ.png",
        "17:BizyAir_NanoBanana2.aspect_ratio": "auto"
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);