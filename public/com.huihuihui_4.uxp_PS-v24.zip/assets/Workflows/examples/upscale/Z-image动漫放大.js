// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54499,
      "suppress_preview_output": true,
      "input_values": {
        "136:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260521/TT0mDvvMvJM0Etm00JAKkKmMf4JwjoxV.png"
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);