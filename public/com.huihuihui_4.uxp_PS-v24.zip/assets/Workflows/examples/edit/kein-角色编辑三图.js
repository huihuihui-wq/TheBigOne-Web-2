// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54481,
      "suppress_preview_output": true,
      "input_values": {
        "143:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260306/jkyEAAtbCoXp5EgjrrxFDMXO46nmxzkF.png",
        "142:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260306/g78D3O4ZEUmHKP15yiORJlIT7UTCZAx1.png",
        "136:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260306/0IQLDpGajzouYotPZojXRb3wRVj7gxTH.png",
        "144:孤海_kontext生图比例.选择尺寸": "16：9（1392x752）",
        "133:CLIPTextEncode.text": "女孩全身像，女孩站立在卧室，小猫坐在旁边，图像保持真实的光影"
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);