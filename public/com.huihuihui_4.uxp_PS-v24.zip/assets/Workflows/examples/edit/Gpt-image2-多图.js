// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54464,
      "suppress_preview_output": true,
      "input_values": {
        "19:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "21:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "22:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "23:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "24:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "20:BizyAir_GPT_IMAGE_2_I2I_API.prompt": "1",
        "20:BizyAir_GPT_IMAGE_2_I2I_API.aspect_ratio": "1:1"
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);