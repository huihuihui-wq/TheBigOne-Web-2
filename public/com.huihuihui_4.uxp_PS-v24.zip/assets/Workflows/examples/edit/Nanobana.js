// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54460,
      "suppress_preview_output": true,
      "input_values": {
        "19:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "17:BizyAir_NanoBanana2.prompt": "1",
        "17:BizyAir_NanoBanana2.inputcount": 5,
        "17:BizyAir_NanoBanana2.aspect_ratio": "auto",
        "21:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "22:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "23:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png",
        "24:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260520/d9poqaYJiWVWNRgcYjx4E8rq5APi4D5W.png"
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);