// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54396,
      "suppress_preview_output": true,
      "input_values": {
        "17:ttN text.text": "90retrostyle, 1girl, headphones, bow, phone, long hair, solo, hair bow, cellphone, fur trim, looking at viewer, red eyes, smartphone, coat, artist name, red hair, hair between eyes, upper body, holding phone, neon lights, holding\nNegative prompt: worst quality, low quality, score_1, score_2, score_3, artist name\nSteps: 24, CFG scale: 3.5, Sampler: Euler a, Seed: 730223082603870, Model: anima-base-v1.0, width: 1664, height: 2432, Version: ComfyUI, Model hash: bd43b7cffe"
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);