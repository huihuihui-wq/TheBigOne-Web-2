// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54402,
      "suppress_preview_output": true,
      "input_values": {
        "19:BizyAirSiliconCloudLLMAPI.user_prompt": "小猫，梵高风格",
        "17:BizyAir_GPT_IMAGE_2_T2I_API.aspect_ratio": "16:9"
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);