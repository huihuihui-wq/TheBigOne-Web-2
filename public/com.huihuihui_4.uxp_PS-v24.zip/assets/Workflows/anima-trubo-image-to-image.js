// JavaScript 示例代码
const response = await fetch('https://api.bizyair.cn/w/v1/webapp/task/openapi/create', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
      "web_app_id": 54800,
      "suppress_preview_output": true,
      "input_values": {
        "34:LoadImage.image": "https://bizyair-prod.oss-cn-shanghai.aliyuncs.com/inputs/20260526/22hT5jS2fVuEL4RbmPNnO5UfO1Tvbg3p.png",
        "28:CR Text.text": "@bkub，1 名少女，站姿，白色连衣裙，红发，指尖停着一只蓝色蝴蝶，画面故障特效",
        "23:KSampler.denoise": 1
      }
    })
});

const result = await response.json();
console.log('生成结果:', result);